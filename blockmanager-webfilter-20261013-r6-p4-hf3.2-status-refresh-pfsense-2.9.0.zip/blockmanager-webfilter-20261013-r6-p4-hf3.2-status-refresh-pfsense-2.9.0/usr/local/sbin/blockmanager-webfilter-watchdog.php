#!/usr/local/bin/php -q
<?php
require_once '/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php';
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
$settings=bmwf_settings();$cfg=(array)($settings['watchdog']??[]);$statusFile=BMWF_STATE_DIR.'/watchdog-status.json';$interval=max(60,min(3600,(int)($cfg['interval_seconds']??120)));$last=is_file($statusFile)?(int)filemtime($statusFile):0;$result=['ok'=>true,'action'=>'none','message'=>'Watchdog desabilitado.'];
if(!empty($cfg['enabled'])&&!empty($settings['enabled'])&&time()-$last<$interval){$result=['ok'=>true,'action'=>'throttled','message'=>'Intervalo do watchdog ainda não atingido.'];}
elseif(!empty($cfg['enabled'])&&!empty($settings['enabled'])){
    $engine=bmwf_exec(['/usr/local/bin/php','-q','/usr/local/sbin/blockmanager-webfilter-engine.php','status']);$activation=BMWF_STATE_DIR.'/activation.json';$httpPort=(int)($settings['activation']['http_port']??8080);$httpsPort=(int)($settings['activation']['https_port']??8443);$listeners=['http'=>false,'https'=>false];
    if(is_executable('/usr/bin/sockstat')){$sock=bmwf_exec(['/usr/bin/sockstat','-4','-6','-l']);foreach(preg_split('/\R/',(string)$sock['output'])as$line){if(stripos($line,'e2guardian')===false)continue;if(preg_match('/[:.]'.preg_quote((string)$httpPort,'/').'(?:\s|$)/',$line))$listeners['http']=true;if(preg_match('/[:.]'.preg_quote((string)$httpsPort,'/').'(?:\s|$)/',$line))$listeners['https']=true;}}
    $missing=[];if(!empty($settings['activation']['http_enabled'])&&!$listeners['http'])$missing[]=(string)$httpPort;if((string)($settings['activation']['https_profile']??'off')!=='off'&&!$listeners['https'])$missing[]=(string)$httpsPort;$unhealthy=!$engine['ok']||$missing;
    if($unhealthy&&is_file($activation)){$remove=bmwf_exec(['/usr/local/bin/php','-q','/usr/local/sbin/blockmanager-webfilter-traffic.php','remove']);@unlink($activation);$result=['ok'=>$remove['ok'],'action'=>'fail-open-remove','message'=>'Motor/listeners inválidos; redirecionamento removido.','missing_listeners'=>$missing];}
    else$result=['ok'=>true,'action'=>'observe','message'=>$engine['ok']&&!$missing?'Motor e listeners ativos.':'Motor/listeners inativos sem tráfego marcado como ativo.','missing_listeners'=>$missing];
}
bmwf_atomic_json($statusFile,array_merge($result,['updated_at'=>date(DATE_ATOM)]));echo json_encode($result,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)."\n";exit($result['ok']?0:1);
