#!/bin/sh
set -eu
ROOT=/;DRY_RUN=0;INSTALL_CRON=0;ALLOW_UNSUPPORTED=0
while [ $# -gt 0 ]; do case "$1" in --root) ROOT=$2;shift 2;;--dry-run) DRY_RUN=1;shift;;--install-cron) INSTALL_CRON=1;shift;;--allow-unsupported-version) ALLOW_UNSUPPORTED=1;shift;;*) echo "Opção inválida: $1" >&2;exit 64;;esac;done
ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/;SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")"&&pwd);TS=$(date +%Y%m%d-%H%M%S);BACKUP="$ROOT/var/backups/blockmanager/webfilter/preinstall-$TS";SUCCESS=0;STARTED=0
sha_cmd(){ if command -v sha256 >/dev/null 2>&1;then sha256 -q "$1";else sha256sum "$1"|awk '{print $1}';fi; }
if [ "$ALLOW_UNSUPPORTED" -ne 1 ]; then V=$(sed -n '1p' "$ROOT/etc/version" 2>/dev/null || true); case "$V" in 2.9.0*) : ;; *) echo "Pacote validado exclusivamente para pfSense 2.9.0; detectado: ${V:-desconhecido}." >&2; exit 65 ;; esac; fi
PAYLOAD="
usr/local/www/dnsmanager/includes/webfilter.php
usr/local/www/dnsmanager/pages/webfilter.php
usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php
usr/local/sbin/blockmanager-identity-catalog-worker.php
usr/local/sbin/blockmanager-webfilter-worker.php
usr/local/sbin/blockmanager-webfilter-engine.php
usr/local/sbin/blockmanager-webfilter-traffic.php
usr/local/sbin/blockmanager-webfilter-service.php
usr/local/sbin/blockmanager-webfilter-watchdog.php
usr/local/sbin/blockmanager-webfilter-webgui-ops.php
usr/local/etc/rc.d/blockmanager_webfilter
usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json
usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json
usr/local/etc/blockmanager/webfilter/policies/blockmanager-webfilter-policy.schema.json
usr/local/etc/blockmanager/webfilter/policies/blockmanager-webfilter-pilot.example.json
 usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.schema.json
 usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.example.json
usr/local/etc/blockmanager/webfilter/sources/blockmanager-webfilter-source.schema.json
usr/local/etc/blockmanager/webfilter/categories/blockmanager-webfilter-category-catalog.schema.json
usr/local/etc/blockmanager/webfilter/lists/blockmanager-webfilter-local-lists.schema.json
 usr/local/etc/blockmanager/webfilter/lists/blockmanager-webfilter-https-inspection-exceptions.schema.json
 usr/local/etc/blockmanager/webfilter/lists/https-inspection-exceptions.example.json
usr/local/share/blockmanager/webfilter/dependency-lock.json
"
UI="usr/local/www/block_manager.php usr/local/www/dnsmanager/templates/sidebar.php";OBSOLETE="usr/local/www/blockmanager_web_filter.php usr/local/www/blockmanager-webfilter/blockmanager-webfilter-menu.php"
[ -f "$ROOT/usr/local/www/block_manager.php" ]||{ echo "block_manager.php ausente." >&2;exit 66;};[ -f "$ROOT/usr/local/www/dnsmanager/templates/sidebar.php" ]||{ echo "sidebar.php ausente." >&2;exit 66;};for r in $PAYLOAD;do [ -f "$SELF_DIR/$r" ]||{ echo "Payload ausente: $r" >&2;exit 65;};done
# pfSense target gate: lint every delivered PHP before backup, migration or promotion.
if [ "$ROOT" = / ];then
 [ -x /usr/local/bin/php ]||{ echo "PHP CLI do pfSense ausente; instalação recusada." >&2;exit 69;}
 for f in $(find "$SELF_DIR/usr/local/www" "$SELF_DIR/usr/local/sbin" "$SELF_DIR/tools" -type f -name '*.php' 2>/dev/null);do
  /usr/local/bin/php -l "$f" >/dev/null||{ echo "Payload PHP inválido: $f" >&2;exit 65;}
 done
 echo "Preflight PHP: todos os arquivos do payload passaram em php -l."
fi
if [ "$DRY_RUN" -eq 1 ];then TMPD=${TMPDIR:-/tmp}/bmwf-dry.$$;trap 'rm -rf "$TMPD"' 0 1 2 15;mkdir -p "$TMPD/usr/local/www/dnsmanager/templates";cp "$ROOT/usr/local/www/block_manager.php" "$TMPD/usr/local/www/block_manager.php";cp "$ROOT/usr/local/www/dnsmanager/templates/sidebar.php" "$TMPD/usr/local/www/dnsmanager/templates/sidebar.php";if [ "$ROOT" = / ] && [ -x /usr/local/bin/php ];then /usr/local/bin/php -q "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.php" --root "$TMPD" >/dev/null;elif command -v python3 >/dev/null 2>&1;then python3 "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.py" --root "$TMPD" >/dev/null;else echo "PHP/Python indisponível para simular o patch." >&2;exit 69;fi;echo "Plano incremental r6-p4-hf3.2-status-refresh (patch estrutural simulado com sucesso):";for r in $PAYLOAD;do if [ -f "$ROOT/$r" ]&&[ "$(sha_cmd "$SELF_DIR/$r")" = "$(sha_cmd "$ROOT/$r")" ];then s=inalterado;elif [ -e "$ROOT/$r" ];then s=atualizar;else s=criar;fi;echo "  $s $r";done;for r in $UI;do echo "  patch estrutural validado $r";done;for r in $OBSOLETE;do [ -e "$ROOT/$r" ]&&echo "  remover rota/menu standalone legado $r"||true;done;[ -f "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" ]||echo "  criar configuração inicial desabilitada";[ "$INSTALL_CRON" -eq 1 ]&&echo "  instalar cron isolado --scheduled"||echo "  não instalar cron";echo "  não instalar mecanismo, não iniciar serviço/worker e não direcionar tráfego";exit 0;fi
rollback(){ c=$?;trap - 0 1 2 15;if [ "$SUCCESS" -eq 0 ]&&[ "$STARTED" -eq 1 ];then echo "Falha; rollback incremental automático." >&2;"$SELF_DIR/blockmanager-webfilter-rollback.sh" "$BACKUP" --root "$ROOT"||true;fi;exit "$c";};trap rollback 0 1 2 15
mkdir -p "$BACKUP/rootfs";MAN="$BACKUP/blockmanager-webfilter-install-manifest.tsv";:>"$MAN";STARTED=1
for r in $PAYLOAD $UI $OBSOLETE usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json var/db/blockmanager/webfilter/status.json;do grep -Fq "$r|" "$MAN" 2>/dev/null&&continue;if [ -e "$ROOT/$r" ];then echo "$r|1">>"$MAN";mkdir -p "$BACKUP/rootfs/$(dirname "$r")";cp -Rp "$ROOT/$r" "$BACKUP/rootfs/$r";else echo "$r|0">>"$MAN";fi;done
if [ "$ROOT" = / ];then if command -v crontab >/dev/null 2>&1;then if crontab -l >"$BACKUP/blockmanager-webfilter-crontab.before" 2>/dev/null;then echo present >"$BACKUP/blockmanager-webfilter-crontab.state";else :>"$BACKUP/blockmanager-webfilter-crontab.before";echo empty >"$BACKUP/blockmanager-webfilter-crontab.state";fi;else echo absent >"$BACKUP/blockmanager-webfilter-crontab.state";fi;else echo absent >"$BACKUP/blockmanager-webfilter-crontab.state";fi
for r in $PAYLOAD;do src="$SELF_DIR/$r";dst="$ROOT/$r";mkdir -p "$(dirname "$dst")";[ -f "$dst" ]&&[ "$(sha_cmd "$src")" = "$(sha_cmd "$dst")" ]&&continue;tmp="$dst.bmwf-new.$$";cp "$src" "$tmp";case "$r" in usr/local/sbin/*|usr/local/etc/rc.d/*)chmod 0750 "$tmp";;*)chmod 0640 "$tmp";;esac;mv -f "$tmp" "$dst";done
SET="$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json";if [ ! -f "$SET" ];then cp "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" "$SET.new.$$";chmod 0640 "$SET.new.$$";mv "$SET.new.$$" "$SET";fi
if [ "$ROOT" = / ] && [ -x /usr/local/bin/php ];then /usr/local/bin/php -q "$SELF_DIR/tools/blockmanager-webfilter-migrate.php" --root "$ROOT";/usr/local/bin/php -q "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.php" --root "$ROOT";elif command -v python3 >/dev/null 2>&1;then python3 "$SELF_DIR/tools/blockmanager-webfilter-migrate.py" --root "$ROOT";python3 "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.py" --root "$ROOT";else echo "PHP/Python indisponível para migração/patch estrutural." >&2;exit 69;fi
for r in $OBSOLETE;do rm -f "$ROOT/$r";done
if [ "$INSTALL_CRON" -eq 1 ];then [ "$ROOT" = / ]||{ echo "--install-cron exige --root /." >&2;exit 64;};command -v crontab >/dev/null 2>&1||{ echo "crontab indisponível." >&2;exit 69;};marker='# blockmanager-webfilter-worker';line='*/2 * * * * /usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-worker.php --scheduled >/dev/null 2>&1 # blockmanager-webfilter-worker';current=$(crontab -l 2>/dev/null||true);printf '%s\n' "$current"|grep -Fq "$marker"||printf '%s\n%s\n' "$current" "$line"|crontab -;fi
if [ "$ROOT" = / ];then /usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-webgui-ops.php status >/dev/null 2>&1||true;fi
"$SELF_DIR/blockmanager-webfilter-validate.sh" --root "$ROOT"
SUCCESS=1;trap - 0 1 2 15;echo "Instalação r6-p4-hf3.2-status-refresh concluída. Backup/rollback: $BACKUP";echo "Web Filter, E2Guardian, serviço, worker, cron e redirecionamento permanecem desativados por padrão.";echo "O motor nativo só é instalado após --verify-bundle e --install-offline explícitos."
