<?php
/**
 * Blockmanager Web Filter shared library.
 * Owns Web Filter configuration/runtime. Block Manager identities are consumed read-only.
 */
if (!defined('BMWF_ROOT')) define('BMWF_ROOT', rtrim((string)(getenv('BMWF_ROOT') ?: '/'), '/') ?: '/');
function bmwf_root_path(string $path): string { return BMWF_ROOT==='/'?$path:BMWF_ROOT.$path; }
if (!defined('BMWF_CONFIG_DIR')) define('BMWF_CONFIG_DIR', bmwf_root_path('/usr/local/etc/blockmanager/webfilter'));
if (!defined('BMWF_POLICIES_DIR')) define('BMWF_POLICIES_DIR', BMWF_CONFIG_DIR . '/policies');
if (!defined('BMWF_HTTPS_POLICIES_DIR')) define('BMWF_HTTPS_POLICIES_DIR', BMWF_CONFIG_DIR . '/https-policies');
if (!defined('BMWF_SOURCES_DIR')) define('BMWF_SOURCES_DIR', BMWF_CONFIG_DIR . '/sources');
if (!defined('BMWF_LISTS_DIR')) define('BMWF_LISTS_DIR', BMWF_CONFIG_DIR . '/lists');
if (!defined('BMWF_STATE_DIR')) define('BMWF_STATE_DIR', bmwf_root_path('/var/db/blockmanager/webfilter'));
if (!defined('BMWF_SOURCE_STATE_DIR')) define('BMWF_SOURCE_STATE_DIR', BMWF_STATE_DIR . '/sources');
if (!defined('BMWF_CATEGORY_STATE_DIR')) define('BMWF_CATEGORY_STATE_DIR', BMWF_STATE_DIR . '/categories');
if (!defined('BMWF_CATEGORY_CATALOG_FILE')) define('BMWF_CATEGORY_CATALOG_FILE', BMWF_CATEGORY_STATE_DIR . '/category-catalog.json');
if (!defined('BMWF_CURSOR_DIR')) define('BMWF_CURSOR_DIR', BMWF_STATE_DIR . '/cursors');
if (!defined('BMWF_CACHE_DIR')) define('BMWF_CACHE_DIR', bmwf_root_path('/var/cache/blockmanager/webfilter'));
if (!defined('BMWF_LOG_DIR')) define('BMWF_LOG_DIR', bmwf_root_path('/var/log/blockmanager/webfilter'));
if (!defined('BMWF_RUN_DIR')) define('BMWF_RUN_DIR', bmwf_root_path('/var/run/blockmanager-webfilter'));
if (!defined('BMWF_SETTINGS_FILE')) define('BMWF_SETTINGS_FILE', BMWF_CONFIG_DIR . '/blockmanager-webfilter-settings.json');
if (!defined('BMWF_SNAPSHOT_FILE')) define('BMWF_SNAPSHOT_FILE', BMWF_STATE_DIR . '/blockmanager-webfilter-identity-snapshot.json');
if (!defined('BMWF_STATUS_FILE')) define('BMWF_STATUS_FILE', BMWF_STATE_DIR . '/status.json');
if (!defined('BMWF_LEGACY_STATUS_FILE')) define('BMWF_LEGACY_STATUS_FILE', BMWF_STATE_DIR . '/blockmanager-webfilter-status.json');
if (!defined('BMWF_SERVICE_STATUS_FILE')) define('BMWF_SERVICE_STATUS_FILE', BMWF_STATE_DIR . '/service-status.json');
if (!defined('BMWF_HTTPS_VALIDATION_FILE')) define('BMWF_HTTPS_VALIDATION_FILE', BMWF_STATE_DIR . '/https-inspection-validation.json');
if (!defined('BMWF_GENERATED_FILE')) define('BMWF_GENERATED_FILE', BMWF_STATE_DIR . '/generated/blockmanager-webfilter-policy.json');
if (!defined('BMWF_CACHE_FILE')) define('BMWF_CACHE_FILE', BMWF_CACHE_DIR . '/blockmanager-webfilter-cache.json');
if (!defined('BMWF_ACCESS_LOG')) define('BMWF_ACCESS_LOG', BMWF_LOG_DIR . '/access.log');
if (!defined('BMWF_AUDIT_FILE')) define('BMWF_AUDIT_FILE', BMWF_LOG_DIR . '/audit.log');
if (!defined('BMWF_SOURCE_LOG')) define('BMWF_SOURCE_LOG', BMWF_LOG_DIR . '/sources.log');

function bmwf_defaults(): array {
    return [
        'version' => 4,
        'enabled' => false,
        'mode' => 'audit',
        'global_default_action' => 'allow',
        'source_adapter' => [
            'read_only' => true,
            'catalog_file' => '/var/db/blockmanager/shared/blockmanager-identity-catalog.json',
        ],
        'backend' => [
            'pid_file' => '/var/run/blockmanager-webfilter/e2guardian.pid',
            'start_argv' => [], 'stop_argv' => [], 'reload_argv' => [],
            'status_argv' => [], 'test_argv' => [],
        ],
        'activation' => [
            'pilot_group' => '', 'pilot_networks' => [], 'fail_open' => true,
            'http_enabled' => true, 'https_profile' => 'off',
            'interfaces' => [], 'http_port' => 8080, 'https_port' => 8443,
            'ca_cert' => '', 'ca_key' => '', 'cert_key' => '',
        ],
        'engine' => [
            'driver' => 'e2guardian',
            'binary' => '/usr/local/sbin/e2guardian',
            'config_file' => '/usr/local/etc/blockmanager/webfilter/generated/e2guardian.conf',
            'base_config_file' => '/usr/local/etc/e2guardian/e2guardian.conf',
            'base_group_config_file' => '/usr/local/etc/e2guardian/e2guardianf1.conf',
            'ssl_supported' => false,
            'minimum_version' => '5.3.4',
            'upstream' => ['enabled' => false, 'host' => '127.0.0.1', 'port' => 3128],
        ],
        'logging' => [
            'sources' => [
                ['id' => 'e2guardian_access', 'path' => '/var/log/e2guardian/access.log', 'enabled' => true, 'format' => 'e2guardian-tab-v6'],
            ],
            'initial_tail_lines' => 200,
            'max_lines_per_run' => 2000,
            'max_bytes_per_run' => 2097152,
            'access_log_rotate_bytes' => 5242880,
            'access_log_rotate_files' => 5,
            'webgui_lines' => 250,
        ],
        'http_workers' => [
            'management_mode' => 'proposal-only',
            'auto_adjust' => false,
            'override_enabled' => false,
            'proposed_workers' => 0,
            'proposal_status' => 'none',
            'proposal_note' => '',
            'proposed_at' => null,
            'proposed_by' => '',
            'configured_directives' => ['httpworkers','maxchildren'],
            'dstats_file' => '/var/log/e2guardian/dstats.log',
            'dstat_interval_seconds' => 300,
            'history_samples' => 288,
            'alerts' => ['busy_reaches_configured' => true, 'httpwq_consecutive_samples' => 2],
        ],
        'https_inspection' => [
            'implementation_state' => 'reserved',
            'enabled' => false,
            'activation_gate' => 'future-validated-release',
            'policy_mode' => 'separate',
            'default_action' => 'bypass',
            'policies_dir' => '/usr/local/etc/blockmanager/webfilter/https-policies',
            'exceptions_file' => '/usr/local/etc/blockmanager/webfilter/lists/https-inspection-exceptions.json',
            'ca' => [
                'provider' => 'internal', 'certificate_path' => '', 'private_key_path' => '',
                'certificate_key_path' => '', 'fingerprint_sha256' => '', 'key_file_mode' => '0600',
            ],
            'validation' => [
                'required' => true, 'status' => 'not_validated',
                'evidence_file' => '/var/db/blockmanager/webfilter/https-inspection-validation.json',
                'minimum_pilot_hours' => 24, 'require_ca_trust_test' => true,
                'require_exception_test' => true, 'require_pinned_application_test' => true,
                'require_fail_open_test' => true, 'require_rollback_test' => true,
            ],
        ],
        'blacklists' => [
            'max_download_bytes' => 52428800,
            'backup_generations' => 3,
            'allow_private_urls' => false,
        ],
        'generation_timeout_seconds' => 60,
    ];
}

function bmwf_ensure_dirs(): void {
    $dirs = [BMWF_CONFIG_DIR, BMWF_CONFIG_DIR . '/generated', BMWF_POLICIES_DIR, BMWF_HTTPS_POLICIES_DIR, BMWF_SOURCES_DIR, BMWF_LISTS_DIR,
        BMWF_STATE_DIR, dirname(BMWF_GENERATED_FILE), BMWF_SOURCE_STATE_DIR,
        BMWF_SOURCE_STATE_DIR . '/staging', BMWF_SOURCE_STATE_DIR . '/active', BMWF_SOURCE_STATE_DIR . '/backup',
        BMWF_CATEGORY_STATE_DIR, BMWF_CURSOR_DIR, BMWF_CACHE_DIR, BMWF_LOG_DIR, BMWF_RUN_DIR];
    foreach ($dirs as $dir) {
        if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) {
            throw new RuntimeException('Não foi possível criar diretório próprio: ' . $dir);
        }
    }
}

function bmwf_json_read(string $file, $default = []) {
    if (!is_file($file) || !is_readable($file)) return $default;
    $raw = @file_get_contents($file);
    if ($raw === false || trim($raw) === '') return $default;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : $default;
}

function bmwf_atomic_text(string $file, string $text, int $mode = 0640): void {
    $dir = dirname($file);
    if (!is_dir($dir) && !@mkdir($dir, 0750, true) && !is_dir($dir)) throw new RuntimeException('Diretório indisponível: ' . $dir);
    $tmp = $file . '.new.' . getmypid();
    if (@file_put_contents($tmp, $text, LOCK_EX) === false) throw new RuntimeException('Falha ao gravar staging: ' . $tmp);
    @chmod($tmp, $mode);
    if (!@rename($tmp, $file)) { @unlink($tmp); throw new RuntimeException('Falha ao promover arquivo: ' . $file); }
}

function bmwf_atomic_json(string $file, array $data, int $mode = 0640): void {
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    if ($json === false) throw new RuntimeException('Falha ao serializar JSON para ' . $file);
    bmwf_atomic_text($file, $json . "\n", $mode);
}

function bmwf_settings(): array {
    return array_replace_recursive(bmwf_defaults(), bmwf_json_read(BMWF_SETTINGS_FILE, []));
}
function bmwf_https_inspection_gate(array $settings):array {
    $future=(array)($settings['https_inspection']??[]);$profile=(string)($settings['activation']['https_profile']??'off');
    if(($future['implementation_state']??'reserved')!=='reserved'||!empty($future['enabled']))return ['ok'=>false,'reserved'=>true,'msg'=>'Estado HTTPS futuro incompatível com esta revisão; mantenha implementation_state=reserved e enabled=false.'];
    if($profile!=='decrypt')return ['ok'=>true,'reserved'=>true,'msg'=>'Inspeção profunda HTTPS não solicitada.'];
    return ['ok'=>false,'reserved'=>true,'msg'=>'Inspeção profunda HTTPS está reservada para uma etapa posterior validada; esta revisão não aceita decrypt, certificado interno ou políticas MITM.'];
}
function bmwf_http_workers_root_path(string $path):string {return BMWF_ROOT!=='/'&&str_starts_with($path,'/')?bmwf_root_path($path):$path;}
function bmwf_http_workers_configured(array $settings):array {
    $engine=(array)($settings['engine']??[]);$files=[];foreach([(string)($engine['config_file']??''),(string)($engine['base_config_file']??'')]as$file){$file=bmwf_http_workers_root_path($file);if($file!==''&&!in_array($file,$files,true))$files[]=$file;}
    foreach(['httpworkers','maxchildren']as$directive)foreach($files as$file){if(!is_file($file)||!is_readable($file))continue;$text=(string)file_get_contents($file);if(preg_match('/^[ \t]*'.preg_quote($directive,'/').'[ \t]*=[ \t]*([0-9]+)/mi',$text,$match))return ['value'=>(int)$match[1],'directive'=>$directive,'file'=>$file];}
    return ['value'=>0,'directive'=>'unknown','file'=>''];
}
function bmwf_http_workers_parse_dstat(string $line):?array {
    $parts=preg_split('/\s+/',trim($line));if(count($parts)<4||!ctype_digit((string)$parts[0]))return null;
    return ['time'=>(int)$parts[0],'httpw'=>(int)($parts[1]??0),'busy'=>(int)($parts[2]??0),'httpwQ'=>(int)($parts[3]??0),'logQ'=>(int)($parts[4]??0),'conx'=>(int)($parts[5]??0),'conx_s'=>(float)($parts[6]??0),'reqs'=>(int)($parts[7]??0),'reqs_s'=>(float)($parts[8]??0),'maxfd'=>(int)($parts[9]??0),'LCcnt'=>(int)($parts[10]??0)];
}
function bmwf_http_workers_samples(string $path,int $limit):array {
    $path=bmwf_http_workers_root_path($path);$limit=max(2,min(2016,$limit));if(!is_file($path)||!is_readable($path))return[];$file=new SplFileObject($path,'r');$file->seek(PHP_INT_MAX);$last=$file->key();$rows=[];for($i=max(0,$last-$limit-4);$i<=$last;$i++){$file->seek($i);$row=bmwf_http_workers_parse_dstat((string)$file->current());if($row)$rows[]=$row;}return array_reverse(array_slice($rows,-$limit));
}
function bmwf_http_workers_snapshot(?array $settings=null):array {
    $settings=$settings??bmwf_settings();$cfg=(array)($settings['http_workers']??[]);$configured=bmwf_http_workers_configured($settings);$samples=bmwf_http_workers_samples((string)($cfg['dstats_file']??'/var/log/e2guardian/dstats.log'),(int)($cfg['history_samples']??288));$latest=$samples[0]??[];$workers=(int)($configured['value']??0);$source=(string)($configured['directive']??'unknown');if($workers<1&&!empty($latest['httpw'])){$workers=(int)$latest['httpw'];$source='dstats.httpw';}
    $queueStreak=0;foreach($samples as$sample){if((int)($sample['httpwQ']??0)>0)$queueStreak++;else break;}$queueLimit=max(2,(int)($cfg['alerts']['httpwq_consecutive_samples']??2));$busy=(int)($latest['busy']??0);$queue=(int)($latest['httpwQ']??0);$busyAlert=$workers>0&&$busy>=$workers;$queueAlert=$queue>0&&$queueStreak>=$queueLimit;$alerts=[];if($busyAlert)$alerts[]='Busy atingiu o limite de workers configurados.';if($queueAlert)$alerts[]='httpwQ permaneceu acima de zero por '.$queueStreak.' amostras consecutivas.';$status=!$latest?'no_data':($alerts?'alert':($queue>0?'watch':'ok'));$message=$alerts?implode(' ',$alerts):($status==='no_data'?'Sem amostras válidas no dstats.log.':($status==='watch'?'httpwQ acima de zero em '.$queueStreak.' amostra(s); aguardando persistência configurada.':'Capacidade dentro dos critérios configurados.'));
    return ['status'=>$status,'message'=>$message,'configured_workers'=>$workers,'configured_source'=>$source,'configured_file'=>(string)($configured['file']??''),'busy'=>$busy,'httpwQ'=>$queue,'httpwQ_consecutive_samples'=>$queueStreak,'httpwQ_alert_after_samples'=>$queueLimit,'sample_time'=>(int)($latest['time']??0),'sample_age_seconds'=>!empty($latest['time'])?max(0,time()-(int)$latest['time']):null,'httpw_reported'=>(int)($latest['httpw']??0),'free'=>$workers>0?max(0,$workers-$busy):0,'alerts'=>$alerts,'management_mode'=>'proposal-only','auto_adjust'=>false,'override_enabled'=>false,'proposed_workers'=>(int)($cfg['proposed_workers']??0),'proposal_status'=>(string)($cfg['proposal_status']??'none'),'proposal_note'=>(string)($cfg['proposal_note']??''),'proposed_at'=>$cfg['proposed_at']??null,'proposed_by'=>(string)($cfg['proposed_by']??''),'samples_loaded'=>count($samples),'dstats_file'=>(string)($cfg['dstats_file']??'/var/log/e2guardian/dstats.log')];
}

function bmwf_valid_group(string $group): bool {
    return $group === '' || (bool)preg_match('/^[\pL\pN][\pL\pN_. @()\/-]{0,127}$/uD', $group);
}
function bmwf_valid_id(string $id): bool { return (bool)preg_match('/^[a-z0-9][a-z0-9_.-]{0,63}$/D', $id); }
function bmwf_h(string $value): string { return htmlspecialchars($value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function bmwf_actor(): string {
    if (function_exists('getUserEntry')) {
        try { $u = getUserEntry(); if (is_array($u) && !empty($u['name'])) return (string)$u['name']; } catch (Throwable $e) {}
    }
    return (string)($_SERVER['REMOTE_USER'] ?? 'webgui');
}

function bmwf_normalize_domains($value): array {
    $items = is_array($value) ? $value : preg_split('/\R+/', (string)$value);
    $out = [];
    foreach ($items as $item) {
        $item = strtolower(trim((string)$item));
        if ($item === '' || $item[0] === '#') continue;
        $item = preg_replace('#^https?://#i', '', $item);
        $item = trim((string)preg_replace('#[/:].*$#', '', $item), '.');
        if ($item === '' || strlen($item) > 253) continue;
        if (!preg_match('/^(?:\*\.)?[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?$/D', $item)) continue;
        $out[$item] = true;
    }
    ksort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return array_keys($out);
}

function bmwf_policy_file(string $group): string {
    if (!bmwf_valid_group($group) || $group === '') throw new InvalidArgumentException('Grupo inválido.');
    return BMWF_POLICIES_DIR . '/blockmanager-webfilter-policy-' . rawurlencode($group) . '.json';
}
function bmwf_category_ref(string $sourceId,string $category):string { return $sourceId.':'.substr(hash('sha256',$category),0,16); }
function bmwf_rebuild_category_catalog(array $groupBindings=[]):array {
    bmwf_ensure_dirs();$items=[];$sources=[];
    foreach((array)glob(BMWF_SOURCE_STATE_DIR.'/active/*.json')as$file){
        $active=bmwf_json_read($file,[]);$sourceId=(string)($active['source_id']??'');if(!bmwf_valid_id($sourceId))continue;$definition=bmwf_json_read(bmwf_source_file($sourceId),[]);$sourceName=(string)($definition['name']??$sourceId);$sourceItems=[];
        foreach((array)($active['categories']??[])as$category=>$domains){$category=trim((string)$category);if($category==='')continue;$ref=bmwf_category_ref($sourceId,$category);$entry=['ref'=>$ref,'source_id'=>$sourceId,'source_name'=>$sourceName,'category'=>$category,'label'=>$sourceName.' / '.$category,'domain_count'=>count(bmwf_normalize_domains($domains)),'active_sha256'=>(string)($active['normalized_sha256']??''),'active_at'=>$definition['last_applied_at']??$active['downloaded_at']??null];$items[$ref]=$entry;$sourceItems[]=$ref;}
        sort($sourceItems,SORT_STRING);$sources[$sourceId]=['id'=>$sourceId,'name'=>$sourceName,'active_sha256'=>(string)($active['normalized_sha256']??''),'category_refs'=>$sourceItems];
    }
    uasort($items,fn($a,$b)=>strnatcasecmp((string)$a['label'],(string)$b['label']));ksort($sources,SORT_NATURAL|SORT_FLAG_CASE);ksort($groupBindings,SORT_NATURAL|SORT_FLAG_CASE);
    $catalog=['version'=>1,'generated_at'=>date(DATE_ATOM),'source_contract'=>'webfilter-external-categories-v1','ownership'=>'webfilter-only','dns_category_reuse'=>false,'items'=>$items,'sources'=>$sources,'group_bindings'=>$groupBindings,'counts'=>['sources'=>count($sources),'categories'=>count($items)]];
    $catalog['catalog_sha256']=hash('sha256',json_encode([$catalog['items'],$catalog['sources'],$catalog['group_bindings']],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE));bmwf_atomic_json(BMWF_CATEGORY_CATALOG_FILE,$catalog);return$catalog;
}
function bmwf_category_catalog():array {
    $catalog=bmwf_json_read(BMWF_CATEGORY_CATALOG_FILE,[]);if(($catalog['source_contract']??'')!=='webfilter-external-categories-v1'||($catalog['dns_category_reuse']??null)!==false)$catalog=bmwf_rebuild_category_catalog();return array_replace(['version'=>1,'items'=>[],'sources'=>[],'group_bindings'=>[],'counts'=>['sources'=>0,'categories'=>0]],$catalog);
}
function bmwf_category_catalog_bind_groups(array $policies):array {
    $bindings=[];foreach($policies as$group=>$policy)$bindings[(string)$group]=['category_mode'=>(string)($policy['category_mode']??'default'),'category_refs'=>array_values((array)($policy['category_refs']??[])),'source_ids'=>array_values((array)($policy['source_ids']??[])),'updated_at'=>$policy['updated_at']??null];return bmwf_rebuild_category_catalog($bindings);
}
function bmwf_policy(string $group): array {
    $raw=bmwf_json_read(bmwf_policy_file($group),[]);$policy=array_replace([
        'version'=>3,'group'=>$group,'enabled'=>false,'default_action'=>'inherit','source_ids'=>[],
        'category_mode'=>'default','category_refs'=>[],'use_local_allow'=>true,'use_local_block'=>true,
        'use_ssl_exceptions'=>true,'use_log_only'=>true,'updated_at'=>null,'updated_by'=>'',
    ],$raw);
    if((int)($raw['version']??0)<3){$catalog=bmwf_category_catalog();$legacy=array_values(array_filter(array_map('strval',(array)($raw['source_categories']??[]))));$refs=[];foreach((array)$catalog['items']as$ref=>$item){if(!in_array((string)($item['source_id']??''),(array)$policy['source_ids'],true))continue;if(!$legacy||in_array((string)($item['category']??''),$legacy,true))$refs[]=(string)$ref;}$policy['category_mode']='deny';$policy['category_refs']=array_values(array_unique($refs));$policy['version']=3;}
    $policy['category_refs']=array_values(array_unique(array_map('strval',(array)$policy['category_refs'])));return$policy;
}
function bmwf_category_domain_plan(array $compiled,string $group):array {
    $policy=(array)($compiled['group_policies'][$group]??[]);$catalog=(array)($compiled['category_catalog']??[]);$sources=(array)($compiled['external_sources']??[]);$local=(array)($compiled['local_lists']??[]);$mode=(string)($policy['category_mode']??'default');if(!in_array($mode,['default','whitelist','allow','deny'],true))$mode='default';$default=(string)($policy['default_action']??'inherit');if($default==='inherit')$default=(string)($compiled['global_default']['action']??'allow');$selected=array_fill_keys(array_map('strval',(array)($policy['category_refs']??[])),true);$all=[];$chosen=[];
    foreach((array)($catalog['items']??[])as$ref=>$item){$sourceId=(string)($item['source_id']??'');$category=(string)($item['category']??'');if(!in_array($sourceId,(array)($policy['source_ids']??[]),true))continue;$domains=bmwf_normalize_domains($sources[$sourceId]['categories'][$category]??[]);foreach($domains as$domain)$all[$domain]=true;if(isset($selected[(string)$ref]))foreach($domains as$domain)$chosen[$domain]=true;}
    $allow=!empty($policy['use_local_allow'])?array_fill_keys((array)($local['allow']??[]),true):[];$block=!empty($policy['use_local_block'])?array_fill_keys((array)($local['block']??[]),true):[];
    if($mode==='whitelist'){foreach($chosen as$d=>$_)$allow[$d]=true;foreach(array_diff_key($all,$chosen)as$d=>$_)$block[$d]=true;}
    elseif($mode==='allow'){foreach($chosen as$d=>$_)$allow[$d]=true;if($default==='block')foreach(array_diff_key($all,$chosen)as$d=>$_)$block[$d]=true;}
    elseif($mode==='deny'){foreach($chosen as$d=>$_)$block[$d]=true;if($default==='block')foreach($all as$d=>$_)$block[$d]=true;}
    elseif($default==='block')foreach($all as$d=>$_)$block[$d]=true;
    foreach($allow as$d=>$_)unset($block[$d]);$allow=array_keys($allow);$block=array_keys($block);sort($allow,SORT_NATURAL|SORT_FLAG_CASE);sort($block,SORT_NATURAL|SORT_FLAG_CASE);return['mode'=>$mode,'effective_default'=>$default,'allow'=>$allow,'block'=>$block,'selected_refs'=>array_keys($selected)];
}
function bmwf_policies(): array {
    $out=[];
    foreach ((array)glob(BMWF_POLICIES_DIR . '/blockmanager-webfilter-policy-*.json') as $file) {
        $p=bmwf_json_read($file,[]); $g=(string)($p['group']??'');
        if ($g!=='' && bmwf_valid_group($g)) $out[$g]=bmwf_policy($g);
    }
    ksort($out,SORT_NATURAL|SORT_FLAG_CASE); return $out;
}
function bmwf_snapshot(): array {
    return array_replace(['version'=>2,'generated_at'=>null,'groups'=>[],'identities'=>[],'networks'=>[],'sessions'=>[],'connectors'=>[]], bmwf_json_read(BMWF_SNAPSHOT_FILE, []));
}
function bmwf_status(): array {
    $file=is_file(BMWF_STATUS_FILE)?BMWF_STATUS_FILE:BMWF_LEGACY_STATUS_FILE;
    return array_replace(['status'=>'never_run','updated_at'=>null,'message'=>'Worker ainda não executado.','status_file'=>BMWF_STATUS_FILE],bmwf_json_read($file,[]));
}

function bmwf_append_jsonl(string $file, array $row): void {
    bmwf_ensure_dirs();
    @file_put_contents($file, json_encode($row, JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND|LOCK_EX);
    @chmod($file,0640);
}
function bmwf_audit(string $action, array $context=[]): void { bmwf_append_jsonl(BMWF_AUDIT_FILE,['ts'=>date(DATE_ATOM),'action'=>$action,'context'=>$context]); }
function bmwf_source_log(string $level,string $message,array $context=[]):void { bmwf_append_jsonl(BMWF_SOURCE_LOG,['ts'=>date(DATE_ATOM),'level'=>$level,'message'=>$message,'context'=>$context]); }

function bmwf_save_settings(array $input,string $actor):array {
    $current=bmwf_settings();
    $mode=(string)($input['mode']??'audit'); $global=(string)($input['global_default_action']??'allow');
    if(!in_array($mode,['audit','enforce'],true) || !in_array($global,['allow','block'],true)) return ['ok'=>false,'msg'=>'Modo ou política global inválida.'];
    $current['enabled']=!empty($input['enabled']); $current['mode']=$mode; $current['global_default_action']=$global;
    $pilotGroup=trim((string)($input['pilot_group']??$current['activation']['pilot_group']??''));
    if($pilotGroup!==''&&(!bmwf_valid_group($pilotGroup)||!in_array($pilotGroup,(array)bmwf_snapshot()['groups'],true)))return ['ok'=>false,'msg'=>'Grupo piloto inválido ou ausente do catálogo atual.'];
    $pilotNetworks=[];foreach((array)($input['pilot_networks']??[])as$network){$network=trim((string)$network);if($network!=='')$pilotNetworks[$network]=true;}
    $httpsProfile=(string)($input['https_profile']??$current['activation']['https_profile']??'off');if($httpsProfile==='decrypt')return ['ok'=>false,'msg'=>'Inspeção profunda HTTPS está reservada para etapa posterior e não pode ser habilitada nesta versão.'];if(!in_array($httpsProfile,['off','sni'],true))return ['ok'=>false,'msg'=>'Perfil HTTPS inválido.'];
    $current['activation']['pilot_group']=$pilotGroup;$current['activation']['pilot_networks']=array_keys($pilotNetworks);$current['activation']['fail_open']=!empty($input['fail_open']);$current['activation']['http_enabled']=!empty($input['http_enabled']);$current['activation']['https_profile']=$httpsProfile;
    foreach(['initial_tail_lines','max_lines_per_run','webgui_lines'] as $key) if(isset($input[$key])) $current['logging'][$key]=max(1,min(10000,(int)$input[$key]));
    if(isset($input['access_log_rotate_mb'])) $current['logging']['access_log_rotate_bytes']=max(1048576,min(104857600,(int)$input['access_log_rotate_mb']*1048576));
    $current['updated_at']=date(DATE_ATOM);$current['updated_by']=$actor;bmwf_atomic_json(BMWF_SETTINGS_FILE,$current);
    bmwf_audit('SETTINGS_SAVED',['enabled'=>$current['enabled'],'mode'=>$mode,'global_default_action'=>$global,'actor'=>$actor]);
    return ['ok'=>true,'msg'=>'Configuração do Web Filter salva. Serviço e worker não são iniciados automaticamente.'];
}
function bmwf_save_http_workers_proposal(array $input,string $actor):array {
    $workers=(int)($input['proposed_workers']??0);if($workers<0||$workers>8192)return ['ok'=>false,'msg'=>'Proposta de HTTP Workers deve ficar entre 0 e 8192.'];$note=trim((string)($input['proposal_note']??''));if(strlen($note)>512)$note=substr($note,0,512);$settings=bmwf_settings();$settings['http_workers']['management_mode']='proposal-only';$settings['http_workers']['auto_adjust']=false;$settings['http_workers']['override_enabled']=false;$settings['http_workers']['proposed_workers']=$workers;$settings['http_workers']['proposal_status']=$workers>0?'pending_validation':'none';$settings['http_workers']['proposal_note']=$note;$settings['http_workers']['proposed_at']=$workers>0?date(DATE_ATOM):null;$settings['http_workers']['proposed_by']=$workers>0?$actor:'';bmwf_atomic_json(BMWF_SETTINGS_FILE,$settings);bmwf_audit('HTTP_WORKERS_PROPOSAL_SAVED',['proposed_workers'=>$workers,'actor'=>$actor,'applied'=>false]);return ['ok'=>true,'msg'=>$workers>0?'Proposta salva como pendente de validação. Nenhum worker foi alterado e nenhum reload foi executado.':'Proposta removida. Nenhum worker foi alterado.'];
}

function bmwf_list_file(string $kind):string {
    if(!in_array($kind,['allow','block','ssl-exception','log-only'],true)) throw new InvalidArgumentException('Tipo de lista local inválido.');
    return BMWF_LISTS_DIR.'/blockmanager-webfilter-'.$kind.'.txt';
}
function bmwf_local_list(string $kind):array { return bmwf_normalize_domains(is_file(bmwf_list_file($kind))?file_get_contents(bmwf_list_file($kind)):''); }
function bmwf_save_local_lists(array $input,string $actor):array {
    foreach(['allow','block','ssl-exception','log-only'] as $kind) bmwf_atomic_text(bmwf_list_file($kind),implode("\n",bmwf_normalize_domains($input[str_replace('-','_',$kind)]??''))."\n");
    bmwf_audit('LOCAL_LISTS_SAVED',['actor'=>$actor]); return ['ok'=>true,'msg'=>'Listas locais salvas.'];
}

function bmwf_save_policy(array $input,string $actor):array {
    $group=trim((string)($input['group']??''));if($group===''||!bmwf_valid_group($group))return['ok'=>false,'msg'=>'Grupo inválido.'];if(!in_array($group,(array)bmwf_snapshot()['groups'],true))return['ok'=>false,'msg'=>'O grupo não existe no catálogo atual do Block Manager.'];
    $action=(string)($input['default_action']??'inherit');if(!in_array($action,['inherit','allow','block'],true))return['ok'=>false,'msg'=>'Ação padrão inválida.'];$mode=(string)($input['category_mode']??'default');if(!in_array($mode,['default','whitelist','allow','deny'],true))return['ok'=>false,'msg'=>'Modo de categorias inválido.'];
    $sourceIds=[];foreach((array)($input['source_ids']??[])as$id){$id=(string)$id;if(bmwf_valid_id($id)&&is_file(BMWF_SOURCES_DIR.'/'.$id.'.json'))$sourceIds[$id]=true;}$catalog=bmwf_category_catalog();$refs=[];$invalid=[];foreach((array)($input['category_refs']??[])as$ref){$ref=(string)$ref;$item=$catalog['items'][$ref]??null;if(!is_array($item)||!isset($sourceIds[(string)($item['source_id']??'')]))$invalid[]=$ref;else$refs[$ref]=true;}if($invalid)return['ok'=>false,'msg'=>'A seleção contém referência de categoria inexistente ou não vinculada ao grupo. Atualize a fonte e tente novamente.'];
    $policy=['version'=>3,'group'=>$group,'enabled'=>!empty($input['policy_enabled']),'default_action'=>$action,'source_ids'=>array_keys($sourceIds),'category_mode'=>$mode,'category_refs'=>array_keys($refs),'use_local_allow'=>!empty($input['use_local_allow']),'use_local_block'=>!empty($input['use_local_block']),'use_ssl_exceptions'=>!empty($input['use_ssl_exceptions']),'use_log_only'=>!empty($input['use_log_only']),'updated_at'=>date(DATE_ATOM),'updated_by'=>$actor];
    bmwf_atomic_json(bmwf_policy_file($group),$policy);bmwf_audit('POLICY_SAVED',['group'=>$group,'category_mode'=>$mode,'category_refs'=>count($refs),'actor'=>$actor]);return['ok'=>true,'msg'=>'Política do grupo salva.'];
}

function bmwf_source_file(string $id):string { if(!bmwf_valid_id($id))throw new InvalidArgumentException('ID de fonte inválido.');return BMWF_SOURCES_DIR.'/'.$id.'.json'; }
function bmwf_sources():array {
    $out=[];foreach((array)glob(BMWF_SOURCES_DIR.'/*.json')as$file){$s=bmwf_json_read($file,[]);$id=(string)($s['id']??'');if(bmwf_valid_id($id))$out[$id]=$s;}ksort($out,SORT_NATURAL|SORT_FLAG_CASE);return $out;
}
function bmwf_source_valid_url(string $url,bool $allowPrivate=false):bool {
    $parts=parse_url($url);if(!is_array($parts)||!in_array(strtolower((string)($parts['scheme']??'')),['http','https'],true)||empty($parts['host'])||isset($parts['user'])||isset($parts['pass']))return false;
    if($allowPrivate)return true;$ips=@gethostbynamel((string)$parts['host']);if(!$ips)return false;
    foreach($ips as$ip)if(filter_var($ip,FILTER_VALIDATE_IP,FILTER_FLAG_NO_PRIV_RANGE|FILTER_FLAG_NO_RES_RANGE)===false)return false;return true;
}
function bmwf_save_source(array $input,string $actor):array {
    $id=strtolower(trim((string)($input['source_id']??'')));$name=trim((string)($input['source_name']??''));$url=trim((string)($input['source_url']??''));$format=(string)($input['source_format']??'domains');$schedule=(string)($input['source_schedule']??'manual');
    if(!bmwf_valid_id($id)||$name===''||strlen($name)>128)return ['ok'=>false,'msg'=>'ID ou nome da fonte inválido.'];
    if(!in_array($format,['domains','hosts','urls','json'],true)||!in_array($schedule,['manual','hourly','daily','weekly'],true))return ['ok'=>false,'msg'=>'Formato ou agenda inválida.'];
    if(!bmwf_source_valid_url($url,(bool)bmwf_settings()['blacklists']['allow_private_urls']))return ['ok'=>false,'msg'=>'URL inválida, não resolvida ou privada.'];
    $old=bmwf_json_read(bmwf_source_file($id),[]);$s=array_replace($old,['version'=>1,'id'=>$id,'name'=>$name,'description'=>trim((string)($input['source_description']??'')),'url'=>$url,'format'=>$format,'schedule'=>$schedule,'default_category'=>trim((string)($input['source_category']??'uncategorized'))?:'uncategorized','enabled'=>!empty($input['source_enabled']),'updated_at'=>date(DATE_ATOM),'updated_by'=>$actor]);
    bmwf_atomic_json(bmwf_source_file($id),$s);bmwf_source_log('info','Fonte salva.',['id'=>$id,'actor'=>$actor]);return ['ok'=>true,'msg'=>'Fonte externa salva.'];
}
function bmwf_delete_source(string $id,string $actor):array {
    if(!bmwf_valid_id($id))return ['ok'=>false,'msg'=>'Fonte inválida.'];$file=bmwf_source_file($id);if(!is_file($file))return ['ok'=>false,'msg'=>'Fonte não encontrada.'];
    @unlink($file);bmwf_source_log('info','Fonte removida; dados ativos preservados para rollback manual.',['id'=>$id,'actor'=>$actor]);return ['ok'=>true,'msg'=>'Definição da fonte removida.'];
}
function bmwf_parse_blacklist(string $raw,string $format,string $defaultCategory):array {
    $categories=[];$invalid=0;$decoded=$format==='json'?json_decode($raw,true):null;
    if($format==='json'&&!is_array($decoded))throw new RuntimeException('JSON da fonte inválido.');
    if($format==='json'){
        $sets=isset($decoded['categories'])&&is_array($decoded['categories'])?$decoded['categories']:[$defaultCategory=>$decoded];
        foreach($sets as$cat=>$items){$domains=bmwf_normalize_domains($items);$categories[(string)$cat]=$domains;$invalid+=max(0,count((array)$items)-count($domains));}
    }else{
        $items=[];foreach(preg_split('/\R/',$raw)as$line){$line=trim($line);if($line===''||$line[0]==='#')continue;if($format==='hosts'){$parts=preg_split('/\s+/',$line);$line=(string)end($parts);}elseif($format==='urls'){$line=(string)(parse_url($line,PHP_URL_HOST)?:'');}$items[]=$line;}
        $domains=bmwf_normalize_domains($items);$invalid=max(0,count($items)-count($domains));$categories[$defaultCategory]=$domains;
    }
    ksort($categories,SORT_NATURAL|SORT_FLAG_CASE);$count=0;foreach($categories as$v)$count+=count($v);return ['categories'=>$categories,'count'=>$count,'invalid'=>$invalid];
}
function bmwf_source_failure(string $id,string $message):array { bmwf_source_log('error','Falha na fonte; última lista válida mantida.',['id'=>$id,'message'=>$message]);return ['ok'=>false,'msg'=>$message.' Última lista válida mantida.']; }
function bmwf_fetch_source(string $id,bool $apply=false):array {
    $s=bmwf_json_read(bmwf_source_file($id),[]);if(!$s)return bmwf_source_failure($id,'Fonte não encontrada.');$settings=bmwf_settings();
    if(!bmwf_source_valid_url((string)$s['url'],(bool)$settings['blacklists']['allow_private_urls']))return bmwf_source_failure($id,'URL da fonte não passou na validação.');
    $max=(int)$settings['blacklists']['max_download_bytes'];$raw=false;$http=0;
    if(function_exists('curl_init')){$ch=curl_init((string)$s['url']);curl_setopt_array($ch,[CURLOPT_RETURNTRANSFER=>true,CURLOPT_FOLLOWLOCATION=>true,CURLOPT_MAXREDIRS=>3,CURLOPT_CONNECTTIMEOUT=>10,CURLOPT_TIMEOUT=>60,CURLOPT_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,CURLOPT_REDIR_PROTOCOLS=>CURLPROTO_HTTP|CURLPROTO_HTTPS,CURLOPT_USERAGENT=>'Blockmanager-WebFilter/1.0',CURLOPT_MAXFILESIZE=>$max]);$raw=curl_exec($ch);$http=(int)curl_getinfo($ch,CURLINFO_RESPONSE_CODE);$err=curl_error($ch);unset($ch);if($raw===false)return bmwf_source_failure($id,'Falha no download: '.$err);}
    else{$ctx=stream_context_create(['http'=>['timeout'=>60,'follow_location'=>1,'max_redirects'=>3,'user_agent'=>'Blockmanager-WebFilter/1.0']]);$raw=@file_get_contents((string)$s['url'],false,$ctx,0,$max+1);if($raw===false)return bmwf_source_failure($id,'Falha no download da fonte.');$http=200;}
    if($http<200||$http>=300||strlen($raw)>$max)return bmwf_source_failure($id,'Download rejeitado por status ou tamanho.');
    try{$parsed=bmwf_parse_blacklist($raw,(string)$s['format'],(string)$s['default_category']);}catch(Throwable$e){return bmwf_source_failure($id,$e->getMessage());}if($parsed['count']<1)return bmwf_source_failure($id,'Fonte sem entradas válidas.');
    $normalized=['version'=>1,'source_id'=>$id,'downloaded_at'=>date(DATE_ATOM),'url'=>$s['url'],'raw_sha256'=>hash('sha256',$raw),'normalized_sha256'=>hash('sha256',json_encode($parsed['categories'],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'entry_count'=>$parsed['count'],'invalid_count'=>$parsed['invalid'],'categories'=>$parsed['categories']];
    $activeFile=BMWF_SOURCE_STATE_DIR.'/active/'.$id.'.json';$old=bmwf_json_read($activeFile,[]);$oldSet=[];$newSet=[];foreach((array)($old['categories']??[])as$c=>$ds)foreach($ds as$d)$oldSet[$c."\0".$d]=true;foreach($normalized['categories']as$c=>$ds)foreach($ds as$d)$newSet[$c."\0".$d]=true;
    $normalized['diff']=['added'=>count(array_diff_key($newSet,$oldSet)),'removed'=>count(array_diff_key($oldSet,$newSet)),'unchanged'=>count(array_intersect_key($newSet,$oldSet))];
    $stage=BMWF_SOURCE_STATE_DIR.'/staging/'.$id.'.json';bmwf_atomic_json($stage,$normalized);
    $meta=array_replace($s,['last_checked_at'=>date(DATE_ATOM),'last_staging_sha256'=>$normalized['normalized_sha256'],'last_validation'=>['ok'=>true,'entries'=>$normalized['entry_count'],'invalid'=>$normalized['invalid_count'],'diff'=>$normalized['diff']]]);bmwf_atomic_json(bmwf_source_file($id),$meta);
    bmwf_source_log('info','Fonte baixada e validada.',['id'=>$id,'entries'=>$normalized['entry_count'],'diff'=>$normalized['diff']]);
    return $apply?bmwf_apply_source($id):['ok'=>true,'msg'=>'Download validado em staging. Lista ativa ainda não foi alterada.','data'=>$normalized];
}
function bmwf_apply_source(string $id):array {
    if(!bmwf_valid_id($id))return ['ok'=>false,'msg'=>'Fonte inválida.'];$stage=BMWF_SOURCE_STATE_DIR.'/staging/'.$id.'.json';$active=BMWF_SOURCE_STATE_DIR.'/active/'.$id.'.json';if(!is_file($stage))return ['ok'=>false,'msg'=>'Staging válido não encontrado.'];
    $candidate=bmwf_json_read($stage,[]);if(empty($candidate['entry_count'])||empty($candidate['normalized_sha256']))return ['ok'=>false,'msg'=>'Staging inválido; lista ativa anterior mantida.'];
    if(is_file($active)){@copy($active,BMWF_SOURCE_STATE_DIR.'/backup/'.$id.'-'.date('Ymd-His').'.json');}
    bmwf_atomic_json($active,$candidate);$s=bmwf_json_read(bmwf_source_file($id),[]);$s['last_applied_at']=date(DATE_ATOM);$s['active_sha256']=$candidate['normalized_sha256'];$s['active_entries']=$candidate['entry_count'];bmwf_atomic_json(bmwf_source_file($id),$s);
    $keep=max(1,(int)bmwf_settings()['blacklists']['backup_generations']);$backups=(array)glob(BMWF_SOURCE_STATE_DIR.'/backup/'.$id.'-*.json');rsort($backups,SORT_STRING);foreach(array_slice($backups,$keep)as$f)@unlink($f);
    $catalog=bmwf_rebuild_category_catalog();bmwf_source_log('info','Staging aplicado; geração anterior preservada em backup.',['id'=>$id,'sha256'=>$candidate['normalized_sha256'],'categories'=>$catalog['counts']['categories']]);return ['ok'=>true,'msg'=>'Fonte aplicada e catálogo próprio de categorias reconstruído. A última lista válida permanece disponível em active/.'];
}

function bmwf_rotate_access_log():void {
    $s=bmwf_settings()['logging'];$max=(int)$s['access_log_rotate_bytes'];$keep=max(1,(int)$s['access_log_rotate_files']);if(!is_file(BMWF_ACCESS_LOG)||filesize(BMWF_ACCESS_LOG)<$max)return;
    for($i=$keep;$i>=1;$i--){$from=BMWF_ACCESS_LOG.'.'.$i.'.gz';$to=BMWF_ACCESS_LOG.'.'.($i+1).'.gz';if(is_file($from)){if($i===$keep)@unlink($from);else@rename($from,$to);}}
    $rot=BMWF_ACCESS_LOG.'.rotate';@rename(BMWF_ACCESS_LOG,$rot);if(function_exists('gzopen')){$in=@fopen($rot,'rb');$out=@gzopen(BMWF_ACCESS_LOG.'.1.gz','wb6');if($in&&$out){while(!feof($in))gzwrite($out,(string)fread($in,65536));fclose($in);gzclose($out);@unlink($rot);}}else{@rename($rot,BMWF_ACCESS_LOG.'.1.gz');}
}
function bmwf_event_value($value,string $fallback=''):string {
    $value=trim((string)$value);return $value===''||$value==='-'?$fallback:$value;
}
function bmwf_normalize_e2guardian_event(string $line,string $source):?array {
    if(strpos($line,"\t")===false)return null;$fields=explode("\t",rtrim($line,"\r\n"));if(count($fields)<20||!is_numeric($fields[0]??null))return null;
    $urlIndex=null;for($i=3;$i<min(9,count($fields));$i++){if(preg_match('#^[a-z][a-z0-9+.-]*://#i',trim((string)$fields[$i]))){$urlIndex=$i;break;}}if($urlIndex===null)return null;
    $ip='';for($i=2;$i<$urlIndex;$i++){if(filter_var(trim((string)$fields[$i]),FILTER_VALIDATE_IP)){$ip=trim((string)$fields[$i]);break;}}
    $url=bmwf_event_value($fields[$urlIndex]??'');$domain=(string)(parse_url($url,PHP_URL_HOST)?:'');$response=(int)bmwf_event_value($fields[$urlIndex+2]??'','0');$messageNumber=(int)bmwf_event_value($fields[14]??'','0');$reason=bmwf_event_value($fields[15]??'');$blockType=(int)bmwf_event_value($fields[16]??'','0');
    $exception=preg_match('/exception|excepted|whitelist|allowed/i',$reason)===1;$blocked=!$exception&&($messageNumber!==0||$blockType!==0||$response===403||preg_match('/denied|blocked|banned|forbidden/i',$reason)===1);
    $timestamp=(float)$fields[0];$seconds=(int)$timestamp;
    return ['timestamp'=>date(DATE_ATOM,$seconds),'epoch'=>$timestamp,'ip'=>$ip,'identity'=>bmwf_event_value($fields[2]??''),'group'=>bmwf_event_value($fields[18]??''),'method'=>strtoupper(bmwf_event_value($fields[$urlIndex+1]??'')),'domain'=>strtolower($domain),'url'=>$url,'category'=>bmwf_event_value($fields[17]??'','uncategorized'),'action'=>$blocked?'BLOCK':'ALLOW','reason'=>$reason,'https_profile'=>strtolower((string)parse_url($url,PHP_URL_SCHEME))==='https'?'https':'off','inspection_level'=>'url','source'=>$source,'response_code'=>$response,'bytes'=>(int)bmwf_event_value($fields[$urlIndex+3]??'','0'),'mime_type'=>bmwf_event_value($fields[$urlIndex+4]??''),'duration_ms'=>(int)bmwf_event_value($fields[$urlIndex+7]??'','0'),'server'=>bmwf_event_value($fields[1]??'')];
}
function bmwf_normalize_event(string $line,string $source):?array {
    $line=rtrim($line,"\r\n");if(trim($line)==='')return null;$e2g=bmwf_normalize_e2guardian_event($line,$source);if($e2g!==null)return$e2g;$x=json_decode($line,true);if(!is_array($x)){$x=[];preg_match_all('/\b(ts|time|date|ip|client|user|identity|group|method|domain|url|category|action|reason|https_profile)=((?:"[^"]*")|[^\s]+)/i',$line,$m,PREG_SET_ORDER);foreach($m as$p)$x[strtolower($p[1])]=trim($p[2],'"');if(!$x)return null;}
    $url=(string)($x['url']??'');$domain=(string)($x['domain']??($url!==''?(parse_url($url,PHP_URL_HOST)?:'') : ''));
    $event=['timestamp'=>(string)($x['timestamp']??$x['ts']??$x['time']??$x['date']??date(DATE_ATOM)),'ip'=>(string)($x['ip']??$x['client']??''),'identity'=>(string)($x['identity']??$x['user']??$x['username']??''),'group'=>(string)($x['group']??''),'method'=>strtoupper((string)($x['method']??'')),'domain'=>strtolower($domain),'url'=>$url,'category'=>(string)($x['category']??'uncategorized'),'action'=>strtoupper((string)($x['action']??'LOG')),'reason'=>(string)($x['reason']??''),'https_profile'=>(string)($x['https_profile']??$x['ssl_profile']??'none'),'inspection_level'=>$url!==''?'url':'domain','source'=>$source];
    return $event;
}
function bmwf_collect_log_source(array $src,array $limits):array {
    $id=(string)($src['id']??'');$configuredPath=(string)($src['path']??'');$sourcePath=BMWF_ROOT!=='/'&&str_starts_with($configuredPath,'/')?bmwf_root_path($configuredPath):$configuredPath;$path=$sourcePath;if(!bmwf_valid_id($id)||$path===''||!is_file($path)||!is_readable($path))return ['source'=>$id,'read'=>0,'written'=>0,'skipped'=>true];
    $stat=@stat($path);$cursorFile=BMWF_CURSOR_DIR.'/'.$id.'.json';$cursor=bmwf_json_read($cursorFile,[]);$offset=(int)($cursor['offset']??0);$same=isset($cursor['dev'],$cursor['ino'])&&(int)$cursor['dev']===(int)$stat['dev']&&(int)$cursor['ino']===(int)$stat['ino'];
    if(!$same||$offset>(int)$stat['size']){$offset=0;if(empty($cursor)){$tail=max(0,(int)$limits['initial_tail_lines']);if($tail>0){$fh=fopen($path,'rb');fseek($fh,max(0,(int)$stat['size']-min((int)$stat['size'],1048576)));$buf=stream_get_contents($fh);fclose($fh);$lines=preg_split('/\R/',$buf);$slice=array_slice($lines,-$tail);$tmp=BMWF_STATE_DIR.'/.initial-'.$id.'.log';file_put_contents($tmp,implode("\n",$slice));$path=$tmp;$stat=stat($path);$offset=0;}}}
    $fh=fopen($path,'rb');fseek($fh,$offset);$read=0;$written=0;$bytes=0;$maxLines=(int)$limits['max_lines_per_run'];$maxBytes=(int)$limits['max_bytes_per_run'];
    while(!feof($fh)&&$read<$maxLines&&$bytes<$maxBytes){$line=fgets($fh);if($line===false)break;$read++;$bytes+=strlen($line);$ev=bmwf_normalize_event($line,$id);if($ev){bmwf_rotate_access_log();bmwf_append_jsonl(BMWF_ACCESS_LOG,$ev);$written++;}}
    $newOffset=ftell($fh);fclose($fh);if(strpos($path,BMWF_STATE_DIR.'/.initial-')===0){@unlink($path);$newOffset=(int)($cursor['offset']??$stat['size']);if(empty($cursor))$newOffset=(int)(@stat($sourcePath)['size']??0);$real=@stat($sourcePath);}else{$real=@stat($path);}
    if($real)bmwf_atomic_json($cursorFile,['version'=>1,'source'=>$id,'path'=>$configuredPath,'dev'=>$real['dev'],'ino'=>$real['ino'],'offset'=>$newOffset,'updated_at'=>date(DATE_ATOM)]);
    return ['source'=>$id,'read'=>$read,'written'=>$written,'offset'=>$newOffset];
}
function bmwf_collect_logs():array {
    bmwf_ensure_dirs();$lock=@fopen(BMWF_RUN_DIR.'/log-collector.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){if($lock)fclose($lock);return ['sources'=>0,'read'=>0,'written'=>0,'busy'=>true,'details'=>[]];}$settings=bmwf_settings();$tot=['sources'=>0,'read'=>0,'written'=>0,'busy'=>false,'details'=>[]];try{foreach((array)$settings['logging']['sources']as$src){if(!is_array($src)||empty($src['enabled']))continue;$r=bmwf_collect_log_source($src,$settings['logging']);$tot['sources']++;$tot['read']+=$r['read'];$tot['written']+=$r['written'];$tot['details'][]=$r;}return$tot;}finally{flock($lock,LOCK_UN);fclose($lock);}
}
function bmwf_collect_logs_throttled(int $minimumSeconds=2):array {
    bmwf_ensure_dirs();$minimumSeconds=max(1,min(60,$minimumSeconds));$stamp=BMWF_STATE_DIR.'/log-collector-last-run';$last=is_file($stamp)?(int)filemtime($stamp):0;if(time()-$last<$minimumSeconds)return ['sources'=>0,'read'=>0,'written'=>0,'throttled'=>true,'details'=>[]];@touch($stamp);$result=bmwf_collect_logs();$result['throttled']=false;return$result;
}
function bmwf_log_delta(int $cursor,int $limit=250):array {
    $limit=max(1,min(1000,$limit));if(!is_file(BMWF_ACCESS_LOG))return ['cursor'=>0,'reset'=>false,'events'=>[]];$size=filesize(BMWF_ACCESS_LOG);$reset=$cursor<0||$cursor>$size;if($reset)$cursor=0;$fh=fopen(BMWF_ACCESS_LOG,'rb');fseek($fh,$cursor);$events=[];while(!feof($fh)&&count($events)<$limit){$line=fgets($fh);if($line===false)break;$x=json_decode($line,true);if(is_array($x))$events[]=$x;}$next=ftell($fh);fclose($fh);return ['cursor'=>$next,'reset'=>$reset,'events'=>$events];
}
function bmwf_recent_access(int $limit=250):array {
    if(!is_file(BMWF_ACCESS_LOG))return [];$limit=max(1,min(1000,$limit));$f=new SplFileObject(BMWF_ACCESS_LOG,'r');$f->seek(PHP_INT_MAX);$last=$f->key();$out=[];for($i=max(0,$last-$limit);$i<=$last;$i++){$f->seek($i);$x=json_decode(trim((string)$f->current()),true);if(is_array($x))$out[]=$x;}return array_reverse($out);
}
function bmwf_exec(array $argv):array {if(!$argv)return ['ok'=>false,'exit_code'=>127,'output'=>'Comando não configurado.'];foreach($argv as$a)if(!is_scalar($a))return ['ok'=>false,'exit_code'=>126,'output'=>'Argumento inválido.'];$cmd=implode(' ',array_map('escapeshellarg',array_map('strval',$argv))).' 2>&1';$lines=[];$code=0;exec($cmd,$lines,$code);return ['ok'=>$code===0,'exit_code'=>$code,'output'=>implode("\n",array_slice($lines,-50))];}
