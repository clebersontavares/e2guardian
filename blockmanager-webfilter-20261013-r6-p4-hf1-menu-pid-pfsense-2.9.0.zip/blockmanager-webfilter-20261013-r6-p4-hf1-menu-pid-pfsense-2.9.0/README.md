# Hotfix mínimo r6-p4-hf1 — menu + PID

Baseline obrigatória: **r6-p4-categories**. Este hotfix altera somente:

1. `/usr/local/www/block_manager.php`: registra as sete rotas `webfilter*` no roteador integrado, prepara POSTs e renderiza a página sem retorno ao dashboard.
2. `/usr/local/sbin/blockmanager-webfilter-engine.php`: mantém `pidfilename` do E2Guardian e usa `/var/run/blockmanager-webfilter/e2guardian-daemon.pid` exclusivamente para o supervisor `daemon(8)` com `-P`.

## Garantias de escopo

O instalador não lê, grava, migra ou normaliza `blockmanager-webfilter-settings.json`; não altera `activation.interfaces`; não seleciona LAN; não altera grupo/redes piloto, políticas, perfil HTTPS, modo, fail-open, serviço, processo ou regras PF; não inicia E2Guardian e não redireciona tráfego.

A tela informada permanece sob responsabilidade do arquivo de configuração já existente: Web Filter desabilitado, Auditoria, política global Permitir, grupo piloto vazio, SNI, HTTP marcado, fail-open marcado e redes piloto desmarcadas.

## Uso

```sh
./install-r6p4-hf1.sh --dry-run
./install-r6p4-hf1.sh
./validate-r6p4-hf1.sh
```

Rollback:

```sh
./rollback-r6p4-hf1.sh /var/backups/blockmanager/webfilter/r6p4-hf1-menu-pid-AAAAMMDD-HHMMSS
```
