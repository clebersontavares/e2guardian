#!/bin/sh
set -eu
[ $# -ge 1 ]||{ echo "Uso: $0 BACKUP [--root DIR]" >&2;exit 64;};BACKUP=$1;shift;ROOT=/
while [ $# -gt 0 ];do case "$1" in --root) ROOT=$2;shift 2;;*) exit 64;;esac;done
ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/
for r in usr/local/www/block_manager.php usr/local/sbin/blockmanager-webfilter-engine.php;do [ -f "$BACKUP/rootfs/$r" ]||{ echo "Backup ausente: $r" >&2;exit 66;};install -m "$(case "$r" in usr/local/sbin/*)echo 0755;;*)echo 0644;;esac)" "$BACKUP/rootfs/$r" "$ROOT/$r";done
echo "Rollback r6-p4-hf1 concluído; configuração e tráfego não foram tocados."
