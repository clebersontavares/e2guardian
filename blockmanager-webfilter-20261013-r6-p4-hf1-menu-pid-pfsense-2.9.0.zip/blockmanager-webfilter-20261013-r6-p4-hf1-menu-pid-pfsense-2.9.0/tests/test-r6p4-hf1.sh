#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.."&&pwd)
P4=/home/oai/share/r6p4-baseline-check/blockmanager-webfilter-20261012-r6-p4-categories-pfsense-2.9.0
for f in "$BASE"/*.sh "$BASE/tests"/*.sh;do sh -n "$f";done
# The engine diff is limited to PID helpers/control; all other shipped r6-p4 runtime files are absent from hotfix by design.
grep -Fq "bmwf_engine_supervisor_pid" "$BASE/payload/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "[\$daemon,'-P',\$supervisorPid,'-f',\$binary,'-N','-c',\$config]" "$BASE/payload/usr/local/sbin/blockmanager-webfilter-engine.php"
! grep -Fq "[\$daemon,'-p',\$pid,'-f',\$binary" "$BASE/payload/usr/local/sbin/blockmanager-webfilter-engine.php"
# No interface selector and no settings/config payload.
! grep -RIn 'name="interfaces' "$BASE/payload" >/dev/null
[ ! -e "$BASE/payload/usr/local/etc" ]
[ ! -e "$BASE/payload/usr/local/sbin/blockmanager-webfilter-traffic.php" ]
[ ! -e "$BASE/payload/usr/local/sbin/blockmanager-webfilter-service.php" ]
# Menu transformation has exact attached source and known result.
[ "$(sha256sum /home/oai/share/r6p4-current-block_manager.php|awk '{print $1}')" = 9d3bf1e6f6b3aa95ed23d90eefb9979a50286bd179770a3fabcd060777c92600 ]
[ "$(sha256sum "$BASE/payload/usr/local/www/block_manager.php"|awk '{print $1}')" = 760d3b502a589db0ebcb747f098605d43349b171b988a92a662ded19b5756120 ]
# Fixture install proves settings byte preservation and no runtime state/traffic artifacts.
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/etc" "$TMP/usr/local/www" "$TMP/usr/local/sbin" "$TMP/usr/local/etc/blockmanager/webfilter"
printf '2.9.0-RELEASE\n' >"$TMP/etc/version"
cp /home/oai/share/r6p4-current-block_manager.php "$TMP/usr/local/www/block_manager.php"
cp "$P4/usr/local/sbin/blockmanager-webfilter-engine.php" "$TMP/usr/local/sbin/blockmanager-webfilter-engine.php"
cat >"$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'JSON'
{"version":4,"enabled":false,"mode":"audit","global_default_action":"allow","activation":{"pilot_group":"","pilot_networks":[],"fail_open":true,"http_enabled":true,"https_profile":"sni","interfaces":[]}}
JSON
S=$(sha256sum "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json")
"$BASE/install-r6p4-hf1.sh" --root "$TMP" --dry-run >/dev/null
[ "$S" = "$(sha256sum "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json")" ]
"$BASE/install-r6p4-hf1.sh" --root "$TMP" >/dev/null
[ "$S" = "$(sha256sum "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json")" ]
[ ! -e "$TMP/var/run/blockmanager-webfilter/e2guardian.pid" ]
[ ! -e "$TMP/var/db/blockmanager/webfilter/activation.json" ]
"$BASE/validate-r6p4-hf1.sh" --root "$TMP" >/dev/null
python3 - "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));a=x['activation']
assert x['enabled'] is False and x['mode']=='audit' and x['global_default_action']=='allow'
assert a['pilot_group']=='' and a['pilot_networks']==[] and a['https_profile']=='sni'
assert a['http_enabled'] is True and a['fail_open'] is True and a['interfaces']==[]
PY
echo 'OK: r6-p4 preservada; somente menu e PID alterados; nenhuma interface/ativação/tráfego introduzidos'
