<?php
/**
 * DNS Manager V15.0 Beta 3 - Captive integrado a Redes e Dispositivos
 * Features: users/groups/categories, Unbound apply, structured daily logs,
 * dashboard/reports/CSV, portable signed-by-hash backup bundle, local backups and audit.
 */
if(!isset($_GET['portal'])) require_once("auth.inc");
require_once("guiconfig.inc");
header('Content-Type: text/html; charset=UTF-8');
define('DNSM_VERSION', 'V15.0 Beta 3');
define('DNSM_V1462_BOOTSTRAPPED', true);
define('DNSM_V1451_BOOTSTRAPPED', true);
// Compatibilidade com modulos das V14.4.x e V14.5.5 ainda instalados.
foreach (['DNSM_V1450_BOOTSTRAPPED','DNSM_V1444_BOOTSTRAPPED','DNSM_V1443_BOOTSTRAPPED','DNSM_V1442_BOOTSTRAPPED','DNSM_V1441_BOOTSTRAPPED','DNSM_V144_BOOTSTRAPPED'] as $compatConstant) {
    if (!defined($compatConstant)) define($compatConstant, true);
}

// Limite exclusivamente visual da lista de acessos do relatorio.
// KPIs e agregacoes continuam considerando 100% dos eventos filtrados.
define('REPORT_DISPLAY_LIMIT', 500);
define('DNS_QUERY_DISPLAY_LIMIT', 500);
define('REPORT_CACHE_TTL', 300);

$base = "/var/unbound/lists";
$groups_dir = "$base/groups";
$users_dir = "$base/users";
$networks_dir = "$base/networks";
$bindings_dir = "$base/device-bindings";
$dhcp_leases_file = "/var/dhcpd/var/db/dhcpd.leases";
$converted_dir = "$base/converted";
$blocked_ips_file = "$base/blocked_ips.conf";
$central_file = "$base/groups_central.conf";
$global_forward_file = "$base/global_forward.conf";
$last_apply_file = "$base/last_apply.json";
$resolver_log_file = "/var/log/resolver.log";
$manager_log_file = "/var/log/dnsfilter-manager.log";
$log_dir = "/var/log/dnsfilter";
$log_cursor_file = "$base/log_cursor.json";
$monitor_cache_file = "$base/monitor_cache.json";
$online_cache_file = "$base/online_cache.json";
$session_cache_file = "$base/session_cache.json";
$presence_cache_file = "$base/device_report_cache.json";
$session_log_dir = "$log_dir/sessions";
$worker_status_file = "$base/worker_status.json";
$dashboard_cache_file = "$base/dashboard_cache.json";
$dashboard_cache_lock_file = "$base/dashboard_cache.lock";
$report_cache_dir = "$base/report-cache";
$presence_report_cache_dir = "$base/presence-report-cache";
$audit_file = "$base/audit.log";
$backup_dir = "/var/backups/dnsmanager";
$settings_file = "$base/settings.json";
$group_connectors_file = "$base/group-connectors.json";
$lock_file = "$base/manager.lock";
$collector_lock_file = "$base/log_collector.lock";
$group_policies_dir = "$base/group-policies";
$dns_infra_dir = "$base/dns-infra";
$dns_records_file = "$dns_infra_dir/records.json";
$dns_forwarders_file = "$dns_infra_dir/forwarders.json";
$safesearch_dir = "$base/safesearch";
$safesearch_records_file = "$safesearch_dir/records.json";
$safesearch_conf_file = "$base/safesearch.conf";
$safesearch_groups_dir = "$safesearch_dir/groups";
$dns_protection_dir = "$base/dns-protection";
$dns_protection_profiles_file = "$dns_protection_dir/profiles.json";
$dns_protection_active_file = "$dns_protection_dir/active.json";
$portal_dir = "$base/portal";
$portal_users_file = "$portal_dir/users.json";
$portal_sessions_file = "$portal_dir/sessions.json";
$portal_login_log_file = "$log_dir/portal-logins.csv";
define('DEVICE_SESSION_DISPLAY_LIMIT',500);
$infra_records_file = "$base/infra_dns_records.conf";
$infra_forwarders_file = "$base/infra_dns_forwarders.conf";

foreach ([$base,$groups_dir,$users_dir,$networks_dir,$bindings_dir,$converted_dir,$log_dir,$backup_dir,$group_policies_dir,$dns_infra_dir,$safesearch_dir,$safesearch_groups_dir,$dns_protection_dir,$portal_dir,$report_cache_dir,$presence_report_cache_dir,$session_log_dir] as $dir) {
    if (!is_dir($dir) && !mkdir($dir,0750,true) && !is_dir($dir)) die('Falha ao criar diretório: '.htmlspecialchars($dir));
}
foreach ([$blocked_ips_file,$global_forward_file,$audit_file,$infra_records_file,$infra_forwarders_file,$safesearch_conf_file] as $file) {
    if (!file_exists($file)) file_put_contents($file,"",LOCK_EX);
}



























function portal_render(){
 $s=portal_settings();$ip=$_SERVER['REMOTE_ADDR']??'';$mode=($_GET['portal']??'login')==='block'?'block':'login';$message='';$ok=false;
 if($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['portal_action']??'')==='login'){$r=portal_login(trim($_POST['username']??''),(string)($_POST['password']??''),$ip);$message=$r['msg'];$ok=$r['ok'];}
 elseif($_SERVER['REQUEST_METHOD']==='POST'&&($_POST['portal_action']??'')==='logout'){$r=portal_logout_ip($ip);$message=$r['ok']?'Sessão encerrada. O acesso voltou para a política padrão da rede.':$r['msg'];$ok=$r['ok'];}
 $sessions=portal_sessions();$activeSession=$sessions[$ip]??null;$identity=identity_for_ip($ip);$mac=portal_client_mac($ip);$ui=ui_preferences();$wlActive=($ui['saved_theme']??'auto')==='whitelabel';$b=$wlActive?dnsmanager_branding():dnsmanager_branding_defaults();$portalLogo=$wlActive?(($b['portal_logo']??'')?:($b['logo']??'')):'';
 header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');header('Pragma: no-cache');
 ?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($s['portal_title']??'DNS Manager')?></title><style>body{margin:0;background:#0b1220;color:#e6edf7;font:16px Arial;display:grid;place-items:center;min-height:100vh}.box{width:min(92vw,480px);background:#111a2c;border:1px solid #283750;border-radius:16px;padding:28px;box-shadow:0 20px 60px #0008}h1{margin-top:0;color:#7db2ff}.msg{padding:12px;border-radius:8px;background:<?= $ok?'#123c25':'#451b22' ?>;margin:12px 0}.session{background:#0b1423;border:1px solid #283750;border-left:4px solid #22c55e;border-radius:10px;padding:16px;margin:16px 0}.session div{display:flex;justify-content:space-between;gap:15px;padding:6px 0;border-bottom:1px solid #283750}.session div:last-child{border-bottom:0}.session span{color:#97a7bd}.logout{background:#b72d35}.registered{background:#123c25;border-radius:8px;padding:13px}.meta{font-size:13px;color:#97a7bd;line-height:1.7}label{display:block;margin:12px 0 5px;font-weight:bold}input{width:100%;box-sizing:border-box;padding:12px;background:#091322;color:white;border:1px solid #283750;border-radius:8px}button{width:100%;margin-top:16px;padding:12px;border:0;border-radius:8px;background:#2167c7;color:white;font-weight:bold;cursor:pointer}.blocked{color:#ff9da7}</style><?php if($wlActive):?><style>body{background:<?=e($b['background_color'])?>;color:<?=e($b['text_color'])?>}.box{background:<?=e($b['panel_color'])?>;border-color:<?=e($b['panel_secondary_color'])?>}h1{color:<?=e($b['primary_color'])?>}input,.session{background:<?=e($b['panel_secondary_color'])?>;color:<?=e($b['text_color'])?>}button{background:<?=e($b['primary_color'])?>}.meta,.session span{color:<?=e($b['muted_color'])?>}</style><?php endif;?></head><body><main class="box"><?php if($portalLogo):?><img src="<?=e($portalLogo)?>" alt="" style="display:block;max-width:220px;max-height:86px;margin:0 auto 16px"><?php endif;?><h1><?=e($mode==='block'?($s['block_title']??'Acesso bloqueado'):($s['portal_title']??'DNS Manager'))?></h1><?php if($message):?><div class="msg"><?=e($message)?></div><?php endif;?><?php if($mode==='block'):?><h2 class="blocked">Acesso bloqueado</h2><p><?=e($s['block_message']??($s['portal_block_message']??'Acesso bloqueado.'))?></p><p class="meta"><?php if(!empty($s['block_show_domain'])):?>Host solicitado: <?=e($_SERVER['HTTP_HOST']??'')?><br><?php endif;?><br>IP: <?=e($ip)?><?php if(!empty($s['portal_show_mac'])):?><br>MAC: <?=e($mac?:'não identificado')?><?php endif;?><?php if(!empty($s['block_show_group'])):?><br>Grupo: <?=e($identity['group']??'Sem grupo')?><?php endif;?></p><?php elseif($activeSession):?><h2>Sessão ativa</h2><p>O acesso está autenticado e a política do grupo está aplicada.</p><div class="session"><div><span>Usuário</span><b><?=e($activeSession['username'])?></b></div><?php if(!empty($s['portal_show_group'])):?><div><span>Grupo</span><b><?=e($activeSession['group'])?></b></div><?php endif;?><?php if(!empty($s['portal_show_ip'])):?><div><span>IP</span><b><?=e($ip)?></b></div><?php endif;?><?php if(!empty($s['portal_show_mac'])):?><div><span>MAC</span><b><?=e($activeSession['mac']?:($mac?:'não identificado'))?></b></div><?php endif;?><div><span>Login</span><b><?=e(date('d/m/Y H:i:s',(int)$activeSession['login_ts']))?></b></div><div><span>Expiração</span><b><?=e(date('d/m/Y H:i:s',(int)$activeSession['expires_ts']))?></b></div></div><form method="post" onsubmit="return confirm('Encerrar esta sessão e voltar para a política padrão da rede?')"><input type="hidden" name="portal_action" value="logout"><button class="logout">Encerrar sessão</button></form><?php else:?><p><?=e($s['portal_login_message']??'Faça login para continuar.')?></p><?php if(($identity['kind']??'unknown')==='device'):?><div class="registered">Dispositivo já cadastrado como <b><?=e($identity['device'])?></b> no grupo <b><?=e($identity['group'])?></b>. Nenhum login é necessário.</div><?php else:?><form method="post"><input type="hidden" name="portal_action" value="login"><label>Usuário</label><input name="username" autocomplete="username" required><label>Senha</label><input type="password" name="password" autocomplete="current-password" required><button>Entrar</button></form><?php endif;?><p class="meta"><?php if(!empty($s['portal_show_ip'])):?>IP: <?=e($ip)?><?php endif;?><?php if(!empty($s['portal_show_mac'])):?><br>MAC: <?=e($mac?:'não identificado')?><?php endif;?></p><?php endif;?></main></body></html><?php exit;
}






















































































/* Structured daily logs */































/* Portable backup bundle: JSON, allowlisted paths, SHA-256 per entry */




















require_once __DIR__.'/dnsmanager/includes/core.php';
require_once __DIR__.'/dnsmanager/includes/branding.php';
require_once __DIR__.'/dnsmanager/includes/settings.php';
require_once __DIR__.'/dnsmanager/includes/portal.php';
require_once __DIR__.'/dnsmanager/includes/identities.php';
require_once __DIR__.'/dnsmanager/includes/connectors.php';
require_once __DIR__.'/dnsmanager/includes/policies.php';
require_once __DIR__.'/dnsmanager/includes/dns.php';
require_once __DIR__.'/dnsmanager/includes/safesearch.php';
require_once __DIR__.'/dnsmanager/includes/protection.php';
require_once __DIR__.'/dnsmanager/includes/reports.php';
require_once __DIR__.'/dnsmanager/includes/backup.php';
require_once __DIR__.'/dnsmanager/includes/firewall.php';
require_once __DIR__.'/dnsmanager/includes/categories_native.php';

/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_BEGIN */
require_once __DIR__.'/dnsmanager/includes/webfilter.php';
/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_END */

if(isset($_GET['portal']))portal_render();
$tabs=['dashboard','dashboard_monitor','users','networks','groups','categories','infra','safesearch','protection','logs','monitor','online','presence','reports','backup','audit','connectors','config','firewall_dashboard','firewall_monitor','firewall_reports','firewall_states','firewall_connections','firewall_services','firewall_categories','firewall_destination_aliases','firewall_policies','firewall_status','firewall_settings','category_catalog','category_edit','category_search'];
/* BLOCKMANAGER_WEBFILTER_TABS_BEGIN */
$tabs=array_values(array_unique(array_merge($tabs,bmwf_tabs())));
/* BLOCKMANAGER_WEBFILTER_TABS_END */
$tab=$_GET['tab']??'dashboard';if(!in_array($tab,$tabs,true))$tab='dashboard';$message='';$message_type='info';$filters=event_filters();$events=[];$report_cache_generated_at='';$report_cache_hit=false;$printMode=in_array($tab,['reports','firewall_reports'],true)&&($_GET['print']??'')==='1';
if(dc_native_is_tab($tab)){ dc_native_prepare($tab); }
if(fm_firewall_is_tab($tab)){ fm_firewall_prepare($tab); }
/* BLOCKMANAGER_WEBFILTER_PREPARE_BEGIN */
if(bmwf_is_tab($tab)){ bmwf_prepare($tab); }
/* BLOCKMANAGER_WEBFILTER_PREPARE_END */
if($tab==='monitor'&&($_GET['ajax']??'')==='monitor'){ while(ob_get_level()>0)ob_end_clean(); header_remove('Content-Type'); header('Content-Type: application/json; charset=UTF-8'); header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0'); echo json_encode(monitor_payload(),JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); exit; }
$presenceFilters=presence_filters();
if(($_GET['download']??'')==='presence_csv'){output_presence_csv(scan_presence($presenceFilters,100000)['sessions']);}
if(($_GET['download']??'')==='backup')dnsfilter_output_backup();
if(($_GET['download']??'')==='branding')dnsmanager_branding_export();
if(($_GET['download']??'')==='csv'){ $events=read_events($filters,100000);output_csv($events); }
if($_SERVER['REQUEST_METHOD']==='POST'&&fm_firewall_is_tab($tab)){
 $firewallAction=trim((string)($_POST['action']??''));
 $fmResult=fm_firewall_handle_post($tab,$firewallAction,$_POST);
 $message=$fmResult['msg'];$message_type=$fmResult['ok']?'success':'error';
 if($fmResult['ok'])fm_firewall_prepare($tab);
}
if($_SERVER['REQUEST_METHOD']==='POST'&&!fm_firewall_is_tab($tab)&&!dc_native_is_tab($tab)&&!bmwf_is_tab($tab)){
 $action=$_POST['action']??'';$result=['ok'=>false,'msg'=>'Ação inválida.'];
 $result=locked(function()use($action){global $users_dir,$groups_dir;
  if($action==='save_user')return save_user_record(trim($_POST['original_username']??''),trim($_POST['username']??''),trim($_POST['identification_mode']??'ip'),trim($_POST['ip']??''),trim($_POST['macs']??($_POST['mac']??'')),$_POST['allowed_networks']??[],trim($_POST['group']??''),trim($_POST['source']??'manual'),(string)($_POST['login_password']??''),isset($_POST['login_enabled']));
  if($action==='delete_user'){$n=trim($_POST['username']??'');if(!valid_name($n)||!is_file("$users_dir/$n.json"))return ['ok'=>false,'msg'=>'Dispositivo inválido.'];$old=file_get_contents("$users_dir/$n.json");if(!unlink("$users_dir/$n.json"))return ['ok'=>false,'msg'=>'Falha ao remover dispositivo.'];$ap=apply_dns();if(!$ap['ok']){atomic_write("$users_dir/$n.json",$old);return $ap;}$bf=binding_file($n);if(is_file($bf))unlink($bf);audit('DELETE_DEVICE',$n);return ['ok'=>true,'msg'=>'Dispositivo removido.'];}
  if($action==='sync_mac_bindings'){$summary=sync_mac_bindings();$ap=apply_dns();if(!$ap['ok'])return $ap;audit('SYNC_MAC_BINDINGS',json_encode($summary));return ['ok'=>true,'msg'=>'Vínculos MAC atualizados. Ativos: '.$summary['active'].', fora do escopo: '.$summary['out_of_scope'].', não encontrados: '.$summary['not_found'].'.'];}
  if($action==='save_network')return save_network(trim($_POST['original_network']??''),trim($_POST['network_name']??''),trim($_POST['cidr']??''),trim($_POST['group']??''));
  if($action==='delete_network')return delete_network(trim($_POST['network_name']??''));
  if($action==='add_group'){$n=trim($_POST['group_name']??'');if(!valid_name($n))return ['ok'=>false,'msg'=>'Nome de grupo inválido.'];if(is_file("$groups_dir/$n.conf"))return ['ok'=>false,'msg'=>'Grupo já existe.'];if(!atomic_write("$groups_dir/$n.conf","# GROUP: $n\n"))return ['ok'=>false,'msg'=>'Falha ao criar grupo.'];$ap=apply_dns();if(!$ap['ok']){unlink("$groups_dir/$n.conf");return $ap;}audit('ADD_GROUP',$n);return ['ok'=>true,'msg'=>'Grupo criado.'];}
  if($action==='delete_group'){$n=trim($_POST['group_name']??'');foreach(users() as $u)if(($u['group']??($u['groups'][0]??''))===$n)return ['ok'=>false,'msg'=>'Troque os dispositivos deste grupo antes de removê-lo.'];foreach(networks() as $network)if($network['group']===$n)return ['ok'=>false,'msg'=>'Troque ou remova as redes deste grupo antes de removê-lo.'];if(!valid_name($n)||!is_file("$groups_dir/$n.conf"))return ['ok'=>false,'msg'=>'Grupo inválido.'];$old=file_get_contents("$groups_dir/$n.conf");unlink("$groups_dir/$n.conf");$ap=apply_dns();if(!$ap['ok']){atomic_write("$groups_dir/$n.conf",$old);return $ap;}fm_remove_group_automation_state($n);audit('DELETE_GROUP',$n);return ['ok'=>true,'msg'=>'Grupo removido.'];}
  if($action==='save_group_sync')return fm_save_group_sync($_POST);
  if($action==='save_group_firewall_policy')return fm_save_group_firewall_policy($_POST);
  if($action==='save_categories'){$group=trim($_POST['group']??'');$defaultAction=$_POST['default_action']??'allow';$states=$_POST['category_state']??[];return save_group_policy($group,$defaultAction,$states,($_POST['use_dns_infra']??'0')==='1',($_POST['deny_dns_resolution']??'0')==='1',$_POST['safesearch_rules']??[],isset($_POST['use_captive_portal']),isset($_POST['use_block_page']));}
  if($action==='save_dns_record')return save_dns_record(trim($_POST['record_id']??''),trim($_POST['host']??''),trim($_POST['record_ip']??''),($_POST['enabled']??'0')==='1');
  if($action==='delete_dns_record')return delete_dns_record(trim($_POST['record_id']??''));
  if($action==='save_dns_forwarder')return save_dns_forwarder(trim($_POST['forwarder_id']??''),trim($_POST['zone']??''),trim($_POST['servers']??''),($_POST['enabled']??'0')==='1');
  if($action==='delete_dns_forwarder')return delete_dns_forwarder(trim($_POST['forwarder_id']??''));
  if($action==='test_dns_infra')return test_dns_name(trim($_POST['test_name']??''));
  if($action==='install_safesearch_templates')return install_safesearch_templates($_POST['template_ids']??[]);
  if($action==='save_safesearch_record')return save_safesearch_record(trim($_POST['safesearch_id']??''),trim($_POST['safesearch_name']??''),trim($_POST['safesearch_description']??''),trim($_POST['safesearch_hosts']??''),trim($_POST['safesearch_record_type']??'A'),trim($_POST['safesearch_target']??''),($_POST['enabled']??'0')==='1');
  if($action==='delete_safesearch_record')return delete_safesearch_record(trim($_POST['safesearch_id']??''));
  if($action==='install_dns_protection_templates')return install_dns_protection_templates($_POST['template_ids']??[]);
  if($action==='save_dns_protection_profile')return save_dns_protection_profile(trim($_POST['protection_id']??''),trim($_POST['protection_name']??''),trim($_POST['protection_description']??''),trim($_POST['protection_protocol']??'dns'),trim($_POST['protection_servers']??''),trim($_POST['protection_tls_auth_name']??''),($_POST['enabled']??'0')==='1');
  if($action==='activate_dns_protection')return activate_dns_protection(trim($_POST['profile_id']??''));
  if($action==='delete_dns_protection_profile')return delete_dns_protection_profile(trim($_POST['protection_id']??''));
  if($action==='save_captive_http_settings')return save_captive_http_settings(isset($_POST['portal_http_enabled']),trim($_POST['portal_http_bind']??'0.0.0.0'),(int)($_POST['portal_http_port']??80),isset($_POST['portal_http_autostart']),trim($_POST['portal_web_scheme']??'https'),(int)($_POST['portal_web_port']??443),trim($_POST['portal_manager_path']??'/dnsmanager_portal.php'));
  if($action==='captive_http_start')return captive_http_exec('start');
  if($action==='captive_http_stop')return captive_http_exec('stop');
  if($action==='captive_http_restart')return captive_http_exec('restart');
  if($action==='captive_http_test')return captive_http_exec('test');
  if($action==='save_captive_exceptions')return save_captive_exceptions(
      isset($_POST['captive_exceptions_enabled']),
      $_POST['captive_domain_exceptions']??'',
      $_POST['captive_device_exceptions']??''
  );
  if($action==='save_captive_settings')return save_captive_settings(isset($_POST['portal_enabled']),trim($_POST['portal_ip']??''),trim($_POST['portal_host']??''),trim($_POST['portal_title']??''),trim($_POST['portal_login_message']??''),(int)($_POST['portal_session_minutes']??480),isset($_POST['portal_show_ip']),isset($_POST['portal_show_mac']),isset($_POST['portal_show_group']),$_POST['portal_auth_connectors']??[]);
  if($action==='save_block_settings')return save_block_settings(isset($_POST['block_enabled']),trim($_POST['block_mode']??'local_ip'),trim($_POST['block_ip']??''),trim($_POST['block_host']??''),trim($_POST['block_cname']??''),trim($_POST['block_external_url']??''),trim($_POST['block_title']??''),trim($_POST['block_message']??''),isset($_POST['block_show_domain']),isset($_POST['block_show_group']),isset($_POST['block_show_reason']));
  if($action==='logout_portal_session')return portal_logout_ip(trim($_POST['session_ip']??''));
  if($action==='save_log_settings')return save_log_settings(isset($_POST['log_allowed_events']),isset($_POST['log_blocked_events']),isset($_POST['log_error_events']),isset($_POST['domain_exclusions_enabled']),$_POST['domain_exclusions']??'');
  if($action==='connector_test_auth')return dnsm_connector_test_auth(trim($_POST['connector_username']??''),(string)($_POST['connector_password']??''),trim($_POST['connector_server']??'local'));
  if($action==='save_group_connectors')return dnsm_save_group_connector_links(
      trim($_POST['dns_group']??''),
      $_POST['pfsense_users']??[],
      $_POST['pfsense_groups']??[],
      trim($_POST['ldap_server']??''),
      $_POST['ldap_containers']??[],
      $_POST['ldap_groups']??[]
  );
  if($action==='save_ui_settings')return save_ui_settings(trim($_POST['ui_theme']??'auto'),trim($_POST['ui_mode']??'dark'),trim($_POST['ui_language']??'pt_BR'));
  if($action==='save_whitelabel')return dnsmanager_branding_save_from_web();
  if($action==='import_whitelabel')return dnsmanager_branding_import_from_web();
  if($action==='refresh_logs')return collect_logs();
  if($action==='save_apply_settings')return save_apply_settings(isset($_POST['validate_dns_after_apply']));
  if($action==='apply')return apply_dns();
  if($action==='create_local_backup'){$n=save_local_backup();return $n?['ok'=>true,'msg'=>'Backup local criado: '.$n]:['ok'=>false,'msg'=>'Falha ao criar backup local.'];}
  if($action==='restore_upload'){if(!isset($_FILES['backup_file'])||$_FILES['backup_file']['error']!==UPLOAD_ERR_OK)return ['ok'=>false,'msg'=>'Selecione um arquivo de backup válido.'];$raw=file_get_contents($_FILES['backup_file']['tmp_name']);[$ok,$msg,$b]=dnsfilter_validate_backup((string)$raw);if(!$ok)return ['ok'=>false,'msg'=>$msg];return dnsfilter_restore_backup($b);}
  if($action==='restore_local'){global $backup_dir;$n=basename($_POST['backup_name']??'');if(!preg_match('/^[A-Za-z0-9_.-]+\.dnsbackup$/D',$n)||!is_file("$backup_dir/$n"))return ['ok'=>false,'msg'=>'Backup local inválido.'];[$ok,$msg,$b]=dnsfilter_validate_backup(file_get_contents("$backup_dir/$n"));if(!$ok)return ['ok'=>false,'msg'=>$msg];return dnsfilter_restore_backup($b);}
  return ['ok'=>false,'msg'=>'Ação inválida.'];
 });
 $message=$result['msg'];$message_type=$result['ok']?'success':'error';
 if(in_array($action,['save_user','delete_user','sync_mac_bindings'],true))$tab='users';
 elseif(in_array($action,['save_network','delete_network'],true))$tab='networks';
 elseif(in_array($action,['add_group','delete_group','save_group_sync'],true))$tab='groups';
 elseif(in_array($action,['save_group_firewall_policy','save_firewall_block_positions'],true))$tab='firewall_policies';
 elseif($action==='save_group_connectors'){
  $tab='connectors';
  $savedGroup=trim((string)($_POST['dns_group']??''));
  if(!empty($result['ok'])&&empty($result['has_links'])){
   $_GET['view']='overview';
   unset($_GET['dns_group'],$_GET['server']);
  }else{
   $_GET['view']='links';
   $_GET['dns_group']=$savedGroup;
   $savedServer=trim((string)($_POST['ldap_server']??''));
   if($savedServer!=='')$_GET['server']=$savedServer;else unset($_GET['server']);
  }
 }
 elseif($action==='connector_test_auth'){
  $tab='connectors';
  $_GET['view']='auth';
  $_GET['server']=trim((string)($_POST['connector_server']??'local'))?:'local';
 }
 elseif($action==='save_categories')$tab='categories';
 elseif(in_array($action,['save_safesearch_record','delete_safesearch_record','install_safesearch_templates'],true))$tab='safesearch';
 elseif(in_array($action,['save_dns_record','delete_dns_record','save_dns_forwarder','delete_dns_forwarder','test_dns_infra'],true))$tab='infra';
 elseif($action==='refresh_logs')$tab='logs';
 elseif(strpos($action,'backup')!==false||strpos($action,'restore')!==false)$tab='backup';
 else $tab='config';
}
$dnsRecords=dns_records();$dnsForwarders=dns_forwarders();$safeSearchRecords=safesearch_records();$dnsProtectionProfiles=dns_protection_profiles();$dnsProtectionActiveId=dns_protection_active_id();$editDnsProtection=null;foreach($dnsProtectionProfiles as $x)if($x['id']===trim($_GET['edit_protection']??''))$editDnsProtection=$x;$editSafeSearch=null;foreach($safeSearchRecords as $x)if($x['id']===trim($_GET['edit_safesearch']??''))$editSafeSearch=$x;$networks=networks();$edit_network_name=trim($_GET['edit_network']??'');$edit_network=isset($networks[$edit_network_name])?$networks[$edit_network_name]:null;$editRecord=null;foreach($dnsRecords as $x)if($x['id']==trim($_GET['edit_record']??''))$editRecord=$x;$editForwarder=null;foreach($dnsForwarders as $x)if($x['id']==trim($_GET['edit_forwarder']??''))$editForwarder=$x;$groups=groups();$cats=categories();$users=users();$counts=category_counts();$logSettings=app_settings();$ui=ui_preferences();$branding=dnsmanager_branding();$edit=trim($_GET['edit']??'');$edit_user=isset($users[$edit])?$users[$edit]:null;$edit_group=trim($_GET['group']??'');if(!isset($groups[$edit_group]))$edit_group='';$blocked=$edit_group?array_fill_keys(group_categories($edit_group),true):[];$groupPolicy=$edit_group?load_group_policy($edit_group):null;$policySummary=$groupPolicy?policy_summary($groupPolicy):['whitelist'=>0,'allow'=>0,'deny'=>0,'inherit'=>0];
if(in_array($tab,['dashboard','dashboard_monitor'],true)){[$report,$dashboard_cache_generated_at,$dashboard_cache_available]=dashboard_cache_read_only();}elseif($tab==='reports'){if($printMode){[$report,$events]=scan_report_events($filters,0,true);$report_cache_generated_at=date(DATE_ATOM);$report_cache_hit=false;}elseif(report_has_explicit_filters()){[$report,$events,$report_cache_generated_at,$report_cache_hit]=report_cached($filters,REPORT_DISPLAY_LIMIT,REPORT_CACHE_TTL);}else{[$report,$events,$report_cache_generated_at,$report_cache_hit]=report_default_cache_read_only();}}elseif($tab==='logs'){if(!$events)$events=read_recent_events($filters,DNS_QUERY_DISPLAY_LIMIT);$report=report_data($events);}else{$report=empty_report();}
$st=in_array($tab,['dashboard','config'],true)?status():['config'=>['ok'=>true,'text'=>''],'running'=>true,'service'=>'','last'=>''];
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title><?=e($branding['product_name'])?> V15.0 Beta 3</title>
<?php if(!empty($branding['favicon'])):?><link rel="icon" href="<?=e($branding['favicon'])?>"><?php endif;?>
<meta name="application-name" content="<?=e($branding['product_name'])?>">
<?php $brandColors=[];foreach(['background_color'=>'--wl-bg','menu_color'=>'--wl-menu','panel_color'=>'--wl-panel','panel_secondary_color'=>'--wl-panel2','primary_color'=>'--wl-primary','secondary_color'=>'--wl-secondary','accent_color'=>'--wl-accent','text_color'=>'--wl-text','muted_color'=>'--wl-muted'] as $bk=>$cssVar){$bv=(string)($branding[$bk]??'');if(preg_match('/^#[0-9A-Fa-f]{6}$/D',$bv))$brandColors[]=$cssVar.':'.$bv;} ?>
<style>:root{<?=e(implode(';',$brandColors))?>}</style>
<link rel="stylesheet" href="/dnsmanager/assets/css/dnsmanager.css?v=14.7.2">
<link rel="stylesheet" href="/dnsmanager/assets/css/whitelabel.css?v=14.7.2"></head><body class="theme-<?=e($ui['theme'])?> mode-<?=e($ui['mode'])?>" data-language="<?=e($ui['language'])?>"><div class="app"><?php require __DIR__.'/dnsmanager/templates/sidebar.php'; ?><main class="main"><div class="top"><h1><?=e(['dashboard'=>'Visão geral','dashboard_monitor'=>'Dashboard','users'=>'Dispositivos','networks'=>'Redes','groups'=>'Grupos','categories'=>'Políticas de categorias','infra'=>'Infraestrutura DNS','safesearch'=>'SafeSearch','protection'=>'Proteção DNS','logs'=>'Consultas DNS','monitor'=>'Monitor DNS','online'=>'Dispositivos online','presence'=>'Histórico de conexões','reports'=>'Relatórios de acesso','backup'=>'Backup e restore','audit'=>'Auditoria','connectors'=>'Conectores','category_catalog'=>'Categorias - Catálogo','category_edit'=>'Categorias - Nova Categoria','category_search'=>'Categorias - Pesquisa','firewall_dashboard'=>'Firewall - Visão geral','firewall_monitor'=>'Monitor Firewall','firewall_states'=>'Firewall - Estados Ativos','firewall_connections'=>'Firewall - Conexões','firewall_reports'=>'Firewall - Relatórios','firewall_services'=>'Firewall - Serviços','firewall_categories'=>'Firewall - Categorias','firewall_destination_aliases'=>'Firewall - Aliases de Destino','firewall_policies'=>'Políticas de Firewall','firewall_status'=>'Sistema - Status dos Workers','firewall_settings'=>'Sistema - Configuração do Firewall','config'=>'Configuração'/* BLOCKMANAGER_WEBFILTER_TITLES_BEGIN */,'webfilter'=>'Web Filter - Visão geral','webfilter_policies'=>'Web Filter - Políticas','webfilter_lists'=>'Web Filter - Listas locais','webfilter_sources'=>'Web Filter - Fontes externas','webfilter_logs'=>'Web Filter - Monitor em tempo real','webfilter_status'=>'Web Filter - Status','webfilter_settings'=>'Web Filter - Configuração'/* BLOCKMANAGER_WEBFILTER_TITLES_END */][$tab])?></h1><div class="top-tools"><?php if($ui['theme']==='classic'):?><button type="button" class="btn theme-toggle" onclick="toggleClassicMode()" data-i18n="toggle_theme">Claro / Escuro</button><?php endif;?><span class="muted"><?=date('d/m/Y H:i')?></span></div></div><?php if($message):?><div role="alert" class="msg <?=e($message_type)?>"><?=e($message)?></div><?php endif;?>
<?php if($tab==='dashboard') require __DIR__.'/dnsmanager/pages/dashboard.php'; ?>
<?php if($tab==='dashboard_monitor') require __DIR__.'/dnsmanager/pages/dashboard_monitor.php'; ?>
<?php if($tab==='users') require __DIR__.'/dnsmanager/pages/users.php'; ?>
<?php if($tab==='networks') require __DIR__.'/dnsmanager/pages/networks.php'; ?>
<?php if($tab==='groups') require __DIR__.'/dnsmanager/pages/groups.php'; ?>
<?php if($tab==='connectors') require __DIR__.'/dnsmanager/pages/connectors.php'; ?>
<?php if($tab==='firewall_dashboard') require __DIR__.'/dnsmanager/pages/firewall_dashboard.php'; ?>
<?php if($tab==='firewall_monitor') require __DIR__.'/dnsmanager/pages/firewall_monitor.php'; ?>
<?php if($tab==='firewall_reports') require __DIR__.'/dnsmanager/pages/firewall_reports.php'; ?>
<?php if($tab==='firewall_states') require __DIR__.'/dnsmanager/pages/firewall_states.php'; ?>
<?php if($tab==='firewall_connections') require __DIR__.'/dnsmanager/pages/firewall_connections.php'; ?>
<?php if($tab==='firewall_services') require __DIR__.'/dnsmanager/pages/firewall_services.php'; ?>
<?php if($tab==='firewall_categories') require __DIR__.'/dnsmanager/pages/firewall_categories.php'; ?>
<?php if($tab==='firewall_destination_aliases') require __DIR__.'/dnsmanager/pages/firewall_destination_aliases.php'; ?>
<?php if($tab==='firewall_policies') require __DIR__.'/dnsmanager/pages/firewall_policies.php'; ?>
<?php if($tab==='firewall_status') require __DIR__.'/dnsmanager/pages/firewall_status.php'; ?>
<?php if($tab==='firewall_settings') require __DIR__.'/dnsmanager/pages/firewall_settings.php'; ?>
<?php if($tab==='categories') require __DIR__.'/dnsmanager/pages/categories.php'; ?>
<?php if($tab==='category_catalog') require __DIR__.'/dnsmanager/pages/category_catalog.php'; ?>
<?php if($tab==='category_edit') require __DIR__.'/dnsmanager/pages/category_edit.php'; ?>
<?php if($tab==='category_search') require __DIR__.'/dnsmanager/pages/category_search.php'; ?>
<?php if($tab==='safesearch') require __DIR__.'/dnsmanager/pages/safesearch.php'; ?>
<?php if($tab==='protection') require __DIR__.'/dnsmanager/pages/protection.php'; ?>
<?php if($tab==='infra') require __DIR__.'/dnsmanager/pages/infra.php'; ?>

<?php if(in_array($tab,['logs','reports'],true)):?><div class="card"><form method="get" id="reportFilter"><input type="hidden" name="tab" value="<?=$tab?>"><div class="inline report-filters"><div><label>Data inicial</label><input type="date" name="from" value="<?=e($filters['from'])?>"></div><div><label>Hora inicial</label><input type="time" name="from_time" value="<?=e($filters['from_time'])?>"></div><div><label>Data final</label><input type="date" name="to" value="<?=e($filters['to'])?>"></div><div><label>Hora final</label><input type="time" name="to_time" value="<?=e($filters['to_time'])?>"></div><div><label>Grupo</label><select name="fgroup"><option value="">Todos</option><?php foreach($groups as $groupName=>$groupFile):?><option <?=$filters['group']===$groupName?'selected':''?>><?=e($groupName)?></option><?php endforeach;?></select></div><div><label>Dispositivo histórico</label><input name="device" placeholder="Nome gravado no evento" value="<?=e($filters['device'])?>"></div><div><label>IP histórico</label><input name="ip" placeholder="192.168.1.50" value="<?=e($filters['ip'])?>"></div><div><label>MAC histórico</label><input name="mac" placeholder="74:86:7A:FD:33:22" value="<?=e($filters['mac']??'')?>"></div><div><label>Domínio</label><input name="domain" value="<?=e($filters['domain'])?>"></div><div><label>Ação</label><select name="faction"><option value="">Todas</option><?php foreach(['ALLOWED','BLOCKED','NOT_FOUND','ERROR','UNKNOWN'] as $a):?><option <?=$filters['action']===$a?'selected':''?>><?=$a?></option><?php endforeach;?></select></div></div><p><button class="btn blue">Filtrar</button> <a class="btn" href="?<?=e(http_build_query(array_merge($_GET,['download'=>'csv'])))?>">Exportar CSV</a> <?php if($tab==='reports'):?><button type="button" class="btn orange" onclick="printReport()">Imprimir / Salvar PDF</button><?php endif;?></p></form><?php if($tab==='logs'):?><form method="post"><?=csrf_start()?><input type="hidden" name="action" value="refresh_logs"><button class="btn green">Coletar novas linhas do resolver.log</button></form><?php endif;?></div><?php if($tab==='reports'):?><?php
$dailyDnsCsvFiles=glob('/var/log/dnsfilter/access-*.csv')?:[];
$dailyDnsCsvFiles=array_values(array_filter($dailyDnsCsvFiles,static function($dailyFile){return preg_match('/^access-\d{4}-\d{2}-\d{2}\.csv$/D',basename($dailyFile))===1;}));
rsort($dailyDnsCsvFiles,SORT_STRING);
?>
<details class="card dns-daily-csv no-print"><summary style="cursor:pointer"><b>Arquivos CSV diários</b> <span class="muted">Download direto, sem processar o relatório histórico</span></summary><div class="tablewrap" style="margin-top:10px"><table><thead><tr><th>Data</th><th>Arquivo</th><th>Tamanho</th><th>Ação</th></tr></thead><tbody><?php foreach($dailyDnsCsvFiles as $dailyFile):$dailyName=basename($dailyFile);preg_match('/^access-(\d{4}-\d{2}-\d{2})\.csv$/D',$dailyName,$dailyMatch);$dailySize=@filesize($dailyFile);?><tr><td><?=e(date('d/m/Y',strtotime($dailyMatch[1])))?></td><td><code><?=e($dailyName)?></code></td><td><?=e($dailySize===false?'-':number_format($dailySize/1048576,2,',','.').' MB')?></td><td><a class="btn" href="/dnsmanager_csv_download.php?type=dns&amp;file=<?=rawurlencode($dailyName)?>">Baixar</a></td></tr><?php endforeach;?><?php if(!$dailyDnsCsvFiles):?><tr><td colspan="4">Nenhum CSV diário encontrado.</td></tr><?php endif;?></tbody></table></div></details>
<?php $historicalSubjects=['devices'=>[],'networks'=>[]];?><div class="card"><div class="row"><div><h2>Relatório avançado histórico</h2><p class="muted">Dispositivos e redes são carregados dos CSVs no período selecionado, inclusive registros removidos do cadastro. Sem seleção, os filtros básicos funcionam normalmente.</p></div><span class="badge ok"><?=count($filters['devices'])+count($filters['networks'])?> selecionado(s)</span></div><div class="device-picker"><input id="deviceSearch" placeholder="Pesquisar nome, IP, MAC ou grupo no histórico..." oninput="filterDevicePicker()"><div class="picker-actions"><button type="button" class="btn" onclick="toggleReportDevices(true)">Selecionar todos</button><button type="button" class="btn" onclick="toggleReportDevices(false)">Limpar seleção</button></div><div class="picker-list" id="devicePicker"><?php foreach($historicalSubjects['devices'] as $deviceName=>$deviceInfo):?><label data-device="<?=e(strtolower($deviceName.' '.$deviceInfo['ip'].' '.$deviceInfo['mac'].' '.$deviceInfo['group']))?>"><input form="reportFilter" type="checkbox" name="devices[]" value="<?=e($deviceName)?>" <?=in_array($deviceName,$filters['devices'],true)?'checked':''?>><span><b><?=e($deviceName)?></b><small><?=e(($deviceInfo['ip']?:'IP não gravado').' • '.($deviceInfo['mac']?:'MAC não gravado').' • '.$deviceInfo['group'])?></small></span></label><?php endforeach;?><?php foreach($historicalSubjects['networks'] as $networkLabel=>$networkInfo):?><label data-device="<?=e(strtolower($networkLabel.' '.$networkInfo['ip'].' '.$networkInfo['group']))?>"><input form="reportFilter" type="checkbox" name="networks[]" value="<?=e($networkLabel)?>" <?=in_array($networkLabel,$filters['networks'],true)?'checked':''?>><span><b><?=e($networkLabel)?></b><small><?=e(($networkInfo['ip']?:'IP não gravado').' • '.$networkInfo['group'])?></small></span></label><?php endforeach;?></div><input form="reportFilter" type="hidden" name="subject_filter" value="1"></div></div><div id="printReportArea"><div class="print-header"><h1>DNS Manager - Relatório de Navegação</h1><p>Período: <?=e($filters['from'].' '.$filters['from_time'])?> até <?=e($filters['to'].' '.$filters['to_time'])?></p><p>Gerado em <?=date('d/m/Y H:i:s')?> por <?=e(actor())?></p></div><div class="cards report-kpis"><div class="card metric"><b><?=number_format($report['total'],0,',','.')?></b><span>Total de consultas</span></div><div class="card metric"><b><?=number_format($report['ALLOWED'],0,',','.')?></b><span>Permitidas</span></div><div class="card metric"><b><?=number_format($report['BLOCKED'],0,',','.')?></b><span>Bloqueadas</span></div><div class="card metric"><b><?=$report['total']?number_format($report['BLOCKED']*100/$report['total'],1,',','.').'%' : '0%'?></b><span>Taxa de bloqueio</span></div><div class="card metric"><b><?=$report['unique_domains']?></b><span>Domínios únicos</span></div><div class="card metric"><b><?=$report['active_devices']?></b><span>Dispositivos ativos</span></div></div><div class="grid report-charts"><div class="card"><h3>Sites mais acessados</h3><?php $topAllowed=array_slice($report['allowed_domains'],0,10,true);$allowedMax=$topAllowed?max($topAllowed):1;foreach($topAllowed as $domainName=>$domainCount):?><div class="rank-row"><div class="rank-label"><span><a class="domain-link" href="categories_manager.php?view=search&domain=<?=urlencode($domainName)?>"><?=e($domainName)?></a></span><b><?=$domainCount?></b></div><div class="bar"><i class="allowed-bar" style="width:<?=max(2,100*$domainCount/max(1,$allowedMax))?>%"></i></div></div><?php endforeach;if(!$topAllowed):?><div class="empty">Nenhum acesso permitido no período.</div><?php endif;?></div><div class="card"><h3>Sites mais bloqueados</h3><?php $topBlocked=array_slice($report['blocked_domains'],0,10,true);$blockedMax=$topBlocked?max($topBlocked):1;foreach($topBlocked as $domainName=>$domainCount):?><div class="rank-row"><div class="rank-label"><span><a class="domain-link" href="categories_manager.php?view=search&domain=<?=urlencode($domainName)?>"><?=e($domainName)?></a></span><b><?=$domainCount?></b></div><div class="bar"><i class="blocked-bar" style="width:<?=max(2,100*$domainCount/max(1,$blockedMax))?>%"></i></div></div><?php endforeach;if(!$topBlocked):?><div class="empty">Nenhum bloqueio no período.</div><?php endif;?></div></div><div class="grid"><div class="card"><h3>Consultas por hora</h3><?php $hourMax=max(1,max($report['hours']));foreach($report['hours'] as $hour=>$hourCount):if($hourCount===0)continue;?><div class="rank-row"><div class="rank-label"><span><?=str_pad((string)$hour,2,'0',STR_PAD_LEFT)?>h</span><b><?=$hourCount?></b></div><div class="bar"><i style="width:<?=max(2,100*$hourCount/$hourMax)?>%"></i></div></div><?php endforeach;?></div><div class="card"><h3>Top dispositivos</h3><?php foreach(array_slice($report['devices'],0,10,true) as $deviceName=>$deviceCount):?><div class="rank-label"><span><?=e($deviceName)?></span><b><?=$deviceCount?></b></div><?php endforeach;?></div></div><div class="card tablewrap report-access-list"><div class="row"><h3>Lista de acessos</h3><span class="muted">Exibindo <?=number_format(count($events),0,',','.')?> de <?=number_format($report['total'],0,',','.')?> registros<?php if($report_cache_generated_at):?> • <?= $report_cache_hit?'cache':'atualizado' ?> <?=e(date('H:i:s',strtotime($report_cache_generated_at)))?><?php endif;?></span></div><table><thead><tr><th>Data/Hora</th><th>IP</th><th>MAC</th><th>Dispositivo</th><th>Grupo</th><th>Domínio</th><th>Ação</th><th>Tipo</th><th>Resposta</th></tr></thead><tbody><?php foreach($events as $x):?><tr><td><?=e($x[0])?></td><td><?=e($x[1])?></td><td><?=e($x[10]??'-')?></td><td><?=e($x[2])?></td><td><?=e($x[3])?></td><td><a class="domain-link" href="categories_manager.php?view=search&domain=<?=urlencode($x[4])?>" title="Pesquisar categoria deste domínio"><?=e($x[4])?></a></td><td><span class="badge <?=e($x[5])?>"><?=e($x[5])?></span></td><td><?=e($x[7])?></td><td><?=e($x[8])?></td></tr><?php endforeach;?></tbody></table><?php if(!$events):?><div class="empty">Nenhum evento encontrado para o período e filtros.</div><?php endif;?></div></div><?php else:?><div class="card"><div class="row"><span class="muted">Exibindo até <?=number_format(DNS_QUERY_DISPLAY_LIMIT,0,',','.')?> eventos mais recentes. Use Relatórios para análises históricas.</span><b><?=number_format(count($events),0,',','.')?> exibidos</b></div></div><div class="card tablewrap"><table><thead><tr><th>Data/Hora</th><th>IP</th><th>MAC</th><th>Dispositivo</th><th>Grupo</th><th>Domínio</th><th>Ação</th><th>Tipo</th><th>Resposta</th></tr></thead><tbody><?php foreach($events as $x):?><tr><td><?=e($x[0])?></td><td><?=e($x[1])?></td><td><?=e($x[10]??'-')?></td><td><?=e($x[2])?></td><td><?=e($x[3])?></td><td><a class="domain-link" href="categories_manager.php?view=search&domain=<?=urlencode($x[4])?>" title="Pesquisar categoria deste domínio"><?=e($x[4])?></a></td><td><span class="badge <?=e($x[5])?>"><?=e($x[5])?></span></td><td><?=e($x[7])?></td><td><?=e($x[8])?></td></tr><?php endforeach;?></tbody></table><?php if(!$events):?><div class="empty">Nenhum evento encontrado para os filtros.</div><?php endif;?></div><?php endif;?><?php endif;?>
<?php if($tab==='monitor') require __DIR__.'/dnsmanager/pages/monitor.php'; ?>
<?php if($tab==='online') require __DIR__.'/dnsmanager/pages/online.php'; ?>
<?php if($tab==='presence') require __DIR__.'/dnsmanager/pages/presence.php'; ?>
<?php if($tab==='backup') require __DIR__.'/dnsmanager/pages/backup.php'; ?>
<?php if($tab==='audit') require __DIR__.'/dnsmanager/pages/audit.php'; ?>
<?php if($tab==='config') require __DIR__.'/dnsmanager/pages/config.php'; ?>
<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->
<?php if(bmwf_is_tab($tab)) require __DIR__.'/dnsmanager/pages/webfilter.php'; ?>
<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->
</main></div><script><?php if($printMode): ?>
window.addEventListener('load',()=>{setTimeout(()=>window.print(),100)});
window.addEventListener('afterprint',()=>{const url=new URL(window.location.href);url.searchParams.delete('print');<?php if($tab==='firewall_reports'): ?>window.location.replace(url.toString())<?php else: ?>window.history.replaceState({},'',url.toString())<?php endif; ?>});
<?php endif; ?></script>
<script src="/dnsmanager/assets/js/app.js?v=14.7.2"></script></body></html>
