#!/bin/sh
set -eu
ROOT=/;DRY=0
while [ $# -gt 0 ];do case "$1" in --root) ROOT=$2;shift 2;;--dry-run) DRY=1;shift;;*) echo "Uso: $0 [--root DIR] [--dry-run]" >&2;exit 64;;esac;done
ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/
SELF=$(CDPATH= cd -- "$(dirname -- "$0")"&&pwd)
MAIN=usr/local/www/block_manager.php
ENGINE=usr/local/sbin/blockmanager-webfilter-engine.php
SETTINGS=usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json
sha(){ if command -v sha256 >/dev/null 2>&1;then sha256 -q "$1";else sha256sum "$1"|awk '{print $1}';fi; }
[ -f "$ROOT/$MAIN" ]||{ echo "Ausente: $ROOT/$MAIN" >&2;exit 66;}
[ -f "$ROOT/$ENGINE" ]||{ echo "Ausente: $ROOT/$ENGINE (baseline r6-p4 necessária)" >&2;exit 66;}
[ -f "$SELF/payload/$MAIN" ]&&[ -f "$SELF/payload/$ENGINE" ]||{ echo "Payload incompleto." >&2;exit 65;}
VERSION=$(sed -n '1p' "$ROOT/etc/version" 2>/dev/null||true);case "$VERSION" in 2.9.0*) :;;*) echo "Alvo exclusivo pfSense 2.9.0; detectado ${VERSION:-desconhecido}." >&2;exit 65;;esac
# Refuse semantic drift: target must be exact attached main or already patched; engine exact p4 or already patched.
MAIN_BEFORE=$(sha "$ROOT/$MAIN");ENGINE_BEFORE=$(sha "$ROOT/$ENGINE")
MAIN_SOURCE=9d3bf1e6f6b3aa95ed23d90eefb9979a50286bd179770a3fabcd060777c92600
MAIN_PATCHED=760d3b502a589db0ebcb747f098605d43349b171b988a92a662ded19b5756120
ENGINE_P4=e26623cc03d9d356410c0568b8e70c5dd5d49451bb0c24b8ed0b472777fd64f7
ENGINE_PATCHED=$(sha "$SELF/payload/$ENGINE")
case "$MAIN_BEFORE" in "$MAIN_SOURCE"|"$MAIN_PATCHED") :;;*) echo "block_manager.php difere do anexo/baseline esperado; recusando sobrescrever código não reconhecido." >&2;exit 65;;esac
case "$ENGINE_BEFORE" in "$ENGINE_P4"|"$ENGINE_PATCHED") :;;*) echo "engine.php não corresponde à r6-p4; recusando misturar versões." >&2;exit 65;;esac
SETTINGS_BEFORE=absent;[ ! -f "$ROOT/$SETTINGS" ]||SETTINGS_BEFORE=$(sha "$ROOT/$SETTINGS")
if [ "$DRY" -eq 1 ];then
 echo "Plano r6-p4-hf1: atualizar somente $MAIN e $ENGINE"
 echo "Configuração preservada: $SETTINGS_BEFORE"
 echo "Nenhuma interface será selecionada; nenhum serviço/processo/regra PF será alterado."
 exit 0
fi
TS=$(date +%Y%m%d-%H%M%S);BACKUP="$ROOT/var/backups/blockmanager/webfilter/r6p4-hf1-menu-pid-$TS";mkdir -p "$BACKUP/rootfs/usr/local/www" "$BACKUP/rootfs/usr/local/sbin"
cp -p "$ROOT/$MAIN" "$BACKUP/rootfs/$MAIN";cp -p "$ROOT/$ENGINE" "$BACKUP/rootfs/$ENGINE"
printf '%s\n' "$MAIN_BEFORE  $MAIN" "$ENGINE_BEFORE  $ENGINE" >"$BACKUP/before.sha256"
install -m 0644 "$SELF/payload/$MAIN" "$ROOT/$MAIN.new";mv -f "$ROOT/$MAIN.new" "$ROOT/$MAIN"
install -m 0755 "$SELF/payload/$ENGINE" "$ROOT/$ENGINE.new";mv -f "$ROOT/$ENGINE.new" "$ROOT/$ENGINE"
# Configuration must remain byte-for-byte unchanged or absent.
SETTINGS_AFTER=absent;[ ! -f "$ROOT/$SETTINGS" ]||SETTINGS_AFTER=$(sha "$ROOT/$SETTINGS")
if [ "$SETTINGS_BEFORE" != "$SETTINGS_AFTER" ];then
 cp -p "$BACKUP/rootfs/$MAIN" "$ROOT/$MAIN";cp -p "$BACKUP/rootfs/$ENGINE" "$ROOT/$ENGINE"
 echo "Configuração mudou inesperadamente; rollback automático executado." >&2;exit 1
fi
if [ "$ROOT" = / ]&&[ -x /usr/local/bin/php ];then /usr/local/bin/php -l "$ROOT/$MAIN" >/dev/null;/usr/local/bin/php -l "$ROOT/$ENGINE" >/dev/null;fi
"$SELF/validate-r6p4-hf1.sh" --root "$ROOT" >/dev/null
echo "Hotfix r6-p4-hf1 instalado. Backup: $BACKUP"
echo "Configuração, interfaces, serviço e tráfego não foram alterados."
