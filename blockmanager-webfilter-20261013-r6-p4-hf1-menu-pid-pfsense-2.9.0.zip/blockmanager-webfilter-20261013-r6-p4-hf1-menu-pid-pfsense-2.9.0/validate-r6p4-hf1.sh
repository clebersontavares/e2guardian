#!/bin/sh
set -eu
ROOT=/;[ "${1:-}" != --root ]||{ ROOT=$2;shift 2;};ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/
MAIN="$ROOT/usr/local/www/block_manager.php";ENGINE="$ROOT/usr/local/sbin/blockmanager-webfilter-engine.php";SETTINGS="$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json"
PASS=0;FAIL=0;p(){ PASS=$((PASS+1));echo "PASS: $*";};f(){ FAIL=$((FAIL+1));echo "FAIL: $*";}
for token in "require_once __DIR__.'/dnsmanager/includes/webfilter.php'" 'array_merge($tabs,bmwf_tabs())' 'if(bmwf_is_tab($tab)){ bmwf_prepare($tab); }' '!dc_native_is_tab($tab)&&!bmwf_is_tab($tab)' "if(bmwf_is_tab(\$tab)) require __DIR__.'/dnsmanager/pages/webfilter.php'";do grep -Fq "$token" "$MAIN"&&p "menu: $token"||f "menu ausente: $token";done
grep -Fq "bmwf_engine_supervisor_pid" "$ENGINE"&&p 'PID supervisor separado'||f 'função de PID supervisor ausente'
grep -Fq "[\$daemon,'-P',\$supervisorPid,'-f',\$binary,'-N','-c',\$config]" "$ENGINE"&&p 'daemon usa -P dedicado'||f 'daemon -P dedicado ausente'
! grep -Fq "[\$daemon,'-p',\$pid,'-f',\$binary" "$ENGINE"&&p 'PID do motor não é usado pelo daemon'||f 'conflito daemon -p ainda presente'
# Explicit negative guards: no UI/selection/interface or activation changes in the hotfix engine/main.
! grep -Fq 'name="interfaces' "$MAIN"&&p 'nenhum seletor de interfaces introduzido'||f 'seletor de interfaces introduzido'
if [ -f "$SETTINGS" ];then p "settings existente e deixado sob controle da r6-p4: $SETTINGS";else p 'settings permaneceu ausente';fi
if [ "$ROOT" = / ]&&[ -x /usr/local/bin/php ];then /usr/local/bin/php -l "$MAIN" >/dev/null&&p 'PHP main válido'||f 'PHP main inválido';/usr/local/bin/php -l "$ENGINE" >/dev/null&&p 'PHP engine válido'||f 'PHP engine inválido';fi
echo "PASS=$PASS FAIL=$FAIL";[ "$FAIL" -eq 0 ]
