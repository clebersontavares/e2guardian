# r6-p4-hf3 — fluxo operacional integral pela WebGUI

## Operação normal

Toda operação fica em **Web Filter > Status**:

1. Salvar configuração sem aplicar tráfego.
2. Compilar catálogo/políticas, gerar E2Guardian, validar sintaxe/dependências e testar PF com `pfctl -n`.
3. Iniciar, parar ou reiniciar o E2Guardian. Reiniciar remove o anchor e não o reaplica.
4. Ver PIDs separados, watchdog e listeners 8080/8443.
5. Ativar o redirecionamento somente no botão **Ativar piloto**, após confirmação e preflight ligado ao hash da configuração atual.
6. Desativar ou executar rollback imediato.

## Teste controlado Jose

A tela oferece perfil pré-preenchido para `192.168.10.102`, grupo `Acesso_Bloqueado` e domínio HTTP `neverssl.com`.

**Preparar teste sem ativar**:

- valida que o IP está no grupo;
- valida a rede escolhida;
- exige interface interna e HTTPS desligado;
- gera bypass para todos os outros IPs do CIDR;
- habilita fail-open e HTTP;
- adiciona o domínio à lista local e habilita `use_local_block` no grupo;
- cria backup da configuração, política e lista;
- não inicia motor e não aplica tráfego.

A fase Auditoria espera `ALLOW`. Depois de aprovada e ativada, a fase Aplicação espera `BLOCK`. O botão **Verificar resultado nos logs** coleta e correlaciona IP, domínio, horário e ação.

**Encerrar teste e restaurar** remove o anchor, para o motor e restaura configuração/política/lista anteriores.

## Segurança

- O pacote instala tudo desabilitado.
- Salvar nunca chama serviço ou tráfego.
- Preflight gera arquivos, mas não aplica o anchor.
- Start e restart não aplicam o anchor.
- Restart remove qualquer anchor existente e deixa o tráfego livre.
- Toda exceção no orquestrador executa fail-open.
- O instalador executa `php -l` no payload antes de promover arquivos.
