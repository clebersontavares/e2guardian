#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.."&&pwd)
OPS="$BASE/usr/local/sbin/blockmanager-webfilter-webgui-ops.php"
PAGE="$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
CTRL="$BASE/usr/local/www/dnsmanager/includes/webfilter.php"
INSTALL="$BASE/blockmanager-webfilter-install.sh"
for f in "$BASE"/*.sh "$BASE/tests"/*.sh "$BASE/usr/local/etc/rc.d"/*;do sh -n "$f";done
python3 "$BASE/tests/php-delimiter-scan.py" "$BASE/usr/local/www" "$BASE/usr/local/sbin" "$BASE/tools"
grep -Fq 'usr/local/sbin/blockmanager-webfilter-webgui-ops.php' "$INSTALL"
grep -Fq "bmwf_ops_call('status')" "$CTRL"
grep -Fq "bmwf_ops_call('preflight')" "$CTRL"
grep -Fq "bmwf_ops_call('prepare-test'" "$CTRL"
for token in 'Compilar, gerar e validar' 'Iniciar sem redirecionar' 'Ativar piloto' 'Rollback imediato' 'PID E2Guardian' 'Listener 8080' 'Listener 8443' 'Teste controlado — Jose' '192.168.10.102' 'Acesso_Bloqueado' 'Verificar resultado nos logs' 'Encerrar teste e restaurar';do grep -Fq "$token" "$PAGE";done
grep -Fq "function bmwf_ops_preflight" "$OPS"
grep -Fq "function bmwf_ops_prepare_test" "$OPS"
grep -Fq "function bmwf_ops_restore_test" "$OPS"
grep -Fq "function bmwf_ops_test_result" "$OPS"
grep -Fq "settings_sha256" "$OPS"
grep -Fq "bmwf_ops_exclude_host" "$OPS"
grep -Fq "bmwf_ops_identity" "$OPS"
grep -Fq "serviceAction=is_file(BMWF_ACTIVATION_STATE)?'apply':'activate'" "$OPS"
# Saving settings and preflight/start/restart must not apply the anchor.
python3 - "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php" "$OPS" <<'PY'
import sys
lib,ops=map(lambda p:open(p).read(),sys.argv[1:])
a=lib.index('function bmwf_save_settings');b=lib.index('function bmwf_save_http_workers_proposal',a);save=lib[a:b]
assert 'traffic.php' not in save and 'service.php' not in save
p=ops.index('function bmwf_ops_preflight');q=ops.index('function bmwf_ops_require_preflight',p);pre=ops[p:q]
assert "['apply']" not in pre and "['activate']" not in pre
c=ops.index('function bmwf_ops_control');d=ops.index('function bmwf_ops_cidr_parts',c);control=ops[c:d]
start=control[control.index("if($action==='start')"):control.index("if($action==='stop')")]
assert "traffic.php',['apply']" not in start and "service.php',['activate']" not in start
restart=control[control.index("if($action==='restart')"):control.index("if($action==='activate')")]
assert "traffic.php',['remove']" in restart and "['apply']" not in restart and "['activate']" not in restart
activate=control[control.index("if($action==='activate')"):control.index("if($action==='deactivate')")]
assert "'apply':'activate'" in activate
PY
# Package defaults remain inert.
python3 - "$BASE/blockmanager-webfilter-release.json" "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" <<'PY'
import json,sys
r=json.load(open(sys.argv[1]));s=json.load(open(sys.argv[2]))
assert r['default_state']['enabled'] is False and r['default_state']['traffic_redirected'] is False
assert r['default_state']['service_started'] is False and r['default_state']['cron_installed'] is False
assert s['enabled'] is False and s['activation']['interfaces']==[] and s['watchdog']['enabled'] is False
PY
echo 'OK: hf3 WebGUI flow is complete and traffic activation remains explicit-only'
