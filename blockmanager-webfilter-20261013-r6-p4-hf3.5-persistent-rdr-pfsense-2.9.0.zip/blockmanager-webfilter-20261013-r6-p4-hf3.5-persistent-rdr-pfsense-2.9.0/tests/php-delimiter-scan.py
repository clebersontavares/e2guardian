#!/usr/bin/env python3
"""Conservative delimiter regression scan; target installation additionally requires php -l."""
from pathlib import Path
import sys

pairs={')':'(',']':'[','}':'{'}
opens=set(pairs.values())

def scan(path:Path):
    s=path.read_text(encoding='utf-8')
    stack=[];i=0;line=1;state='code';quote=''
    while i<len(s):
        c=s[i];n=s[i+1] if i+1<len(s) else ''
        if c=='\n': line+=1
        if state=='line':
            if c=='\n':state='code'
        elif state=='block':
            if c=='*' and n=='/':state='code';i+=1
        elif state=='string':
            if c=='\\':i+=1
            elif c==quote:state='code'
        else:
            if c in "'\"`":state='string';quote=c
            elif c=='/' and n=='/':state='line';i+=1
            elif c=='#':state='line'
            elif c=='/' and n=='*':state='block';i+=1
            elif c in opens:stack.append((c,line))
            elif c in pairs:
                if not stack or stack[-1][0]!=pairs[c]:
                    raise SyntaxError(f'{path}:{line}: unexpected {c}')
                stack.pop()
        i+=1
    if state in {'string','block'}:raise SyntaxError(f'{path}:{line}: unclosed {state}')
    if stack:
        c,l=stack[-1];raise SyntaxError(f'{path}:{l}: unclosed {c}')

files=[]
for arg in sys.argv[1:]:
    p=Path(arg)
    files.extend(p.rglob('*.php') if p.is_dir() else [p])
for p in files:scan(p)
print(f'OK: {len(files)} PHP files passed delimiter scan')
