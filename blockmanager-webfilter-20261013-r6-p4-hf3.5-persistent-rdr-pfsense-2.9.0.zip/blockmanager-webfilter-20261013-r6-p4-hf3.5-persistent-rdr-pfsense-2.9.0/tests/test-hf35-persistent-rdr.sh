#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/bmwf-hf35.$$
trap 'rm -rf "$TMP"' 0 1 2 15
mkdir -p "$TMP/etc/inc" "$TMP/tmp"
cat >"$TMP/etc/inc/filter.inc" <<'PHP'
<?php
function filter_rules_generate() {
    $rules = "set skip on lo0\n";
    $rules .= "rdr-anchor \"tftp-proxy/*\"\n";
    return $rules;
}
PHP
python3 "$BASE/tools/blockmanager-webfilter-pf-root.py" install --root "$TMP" >/dev/null
python3 "$BASE/tools/blockmanager-webfilter-pf-root.py" install --root "$TMP" >/dev/null
python3 "$BASE/tools/blockmanager-webfilter-pf-root.py" status --root "$TMP" >/dev/null
[ "$(grep -c 'BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN' "$TMP/etc/inc/filter.inc")" -eq 1 ]
[ "$(grep -c 'rdr-anchor.*blockmanager_webfilter' "$TMP/etc/inc/filter.inc")" -eq 1 ]
grep -Fq '$rules .= "rdr-anchor \"blockmanager_webfilter\"\n";' "$TMP/etc/inc/filter.inc"
python3 "$BASE/tools/blockmanager-webfilter-pf-root.py" remove --root "$TMP" >/dev/null
! grep -Fq 'BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN' "$TMP/etc/inc/filter.inc"
grep -Fq 'tftp-proxy/*' "$TMP/etc/inc/filter.inc"

# Persistent generator patch is installed, but the installer must never reload PF.
grep -Fq 'blockmanager-webfilter-pf-root.php" install' "$BASE/blockmanager-webfilter-install.sh"
! grep -Fq '/etc/rc.filter_configure' "$BASE/blockmanager-webfilter-install.sh"
grep -Fq ': ${blockmanager_webfilter_enable:="NO"}' "$BASE/usr/local/etc/rc.d/blockmanager_webfilter"

# Production scope, explicit activation, dynamic interface mapping and separate PIDs.
! grep -q 'pilot_group' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
! grep -q 'pilot_networks' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq 'production-all-compiled-networks' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq 'nome lógico → interface física → IPv4 atual' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq "value=\"<?=e(\$i['logical'])?>\"" "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'bmwf_traffic_production_cidrs' "$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php"
grep -Fq 'status --require-live' "$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php" || grep -Fq "'status','--require-live'" "$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php"
grep -Fq '/var/run/blockmanager-webfilter/e2guardian.pid' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq '/var/run/blockmanager-webfilter/e2guardian-daemon.pid' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Eq '"http_port"[[:space:]]*:[[:space:]]*8080' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Eq '"https_port"[[:space:]]*:[[:space:]]*8443' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Eq '"enabled"[[:space:]]*:[[:space:]]*false' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"

# Homologated evidence must be present verbatim and clearly identified.
for token in 'Evaluations: **315**' 'Packets: **189**' 'Bytes: **219640**' 'State Creations: **3**' '192.168.10.104' '/var/log/e2guardian/access.log'; do
    grep -Fq "$token" "$BASE/TAREFA-REBUILD-HF3.5.md"
done

echo 'PASS: hf3.5 persistent root RDR, production scope, interface portability and no automatic activation'
