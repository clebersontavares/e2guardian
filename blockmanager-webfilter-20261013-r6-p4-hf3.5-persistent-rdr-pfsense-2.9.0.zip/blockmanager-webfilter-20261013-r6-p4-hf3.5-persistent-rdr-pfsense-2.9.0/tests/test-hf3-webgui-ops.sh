#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.."&&pwd)
OPS="$BASE/usr/local/sbin/blockmanager-webfilter-webgui-ops.php"
ENGINE="$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
TRAFFIC="$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php"
PAGE="$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
CTRL="$BASE/usr/local/www/dnsmanager/includes/webfilter.php"
SCHEMA="$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json"
DEFAULTS="$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
for f in "$BASE"/*.sh "$BASE/tests"/*.sh "$BASE/usr/local/etc/rc.d"/*;do sh -n "$f";done
python3 "$BASE/tests/php-delimiter-scan.py" "$BASE/usr/local/www" "$BASE/usr/local/sbin" "$BASE/tools"
# Complete production WebGUI flow.
grep -Fq "bmwf_ops_call('status')" "$CTRL"
grep -Fq "bmwf_ops_call('refresh')" "$CTRL"
grep -Fq "bmwf_ops_call('preflight')" "$CTRL"
grep -Fq 'name="action" value="bmwf_ops_refresh">Verificar agora</button>' "$PAGE"
! grep -Fq 'value="bmwf_ops_refresh" disabled' "$PAGE"
grep -Fq 'function bmwf_ops_refresh():array' "$OPS"
grep -Fq "elseif(\$action==='refresh')\$result=bmwf_ops_refresh()" "$OPS"
grep -Fq "if(!empty(\$failOpen['triggered']))\$anchor=bmwf_ops_anchor()" "$OPS"
grep -Fq "'redirect_active'=>!empty(\$anchor['query_ok'])?(bool)\$anchor['active']:null" "$OPS"
grep -Fq 'function bmwf_ops_pf_nat_rules' "$OPS"
grep -Fq "count(\$parsed['rules'])>0" "$OPS"
grep -Fq 'function bmwf_traffic_anchor_query' "$TRAFFIC"
grep -Fq 'confirmed_inactive' "$TRAFFIC"
grep -Fq 'for ($i=1;$i<=3;$i++)' "$TRAFFIC"
grep -Fq 'Anchor raiz persistente' "$PAGE"
for token in 'Preparar anchor raiz' 'Compilar, gerar e validar' 'Iniciar sem redirecionar' 'Ativar produção' 'Rollback imediato' 'PID E2Guardian' 'bmwfListener8080' 'bmwfListener8443';do grep -Fq "$token" "$PAGE";done
# No test-specific production flow or fixture data.
! grep -REiq 'prepare-test|restore-test|test-result|controlled-test' "$BASE/usr/local"
# Backend is exclusively E2Guardian and operational code has no alternative backend.
grep -Fq "function bmwf_engine_driver(array \$settings): string { return 'e2guardian'; }" "$ENGINE"
grep -Fq "'/usr/local/sbin/e2guardian'" "$ENGINE"
! grep -Eiq 'squid' "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php" "$BASE/usr/local/sbin/blockmanager-webfilter-webgui-ops.php" "$DEFAULTS" "$SCHEMA"
python3 - "$DEFAULTS" "$SCHEMA" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]));s=json.load(open(sys.argv[2]))
assert d['activation']['http_port']==8080 and d['activation']['https_port']==8443
assert d['engine']['driver']=='e2guardian' and d['engine']['binary']=='/usr/local/sbin/e2guardian'
assert 'upstream' not in d['engine']
e=s['properties']['engine']['properties']
assert e['driver']['const']=='e2guardian' and e['binary']['const']=='/usr/local/sbin/e2guardian'
assert 'upstream' not in e
PY
# Saving/preflight/start/restart never activates traffic; activate remains explicit.
python3 - "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php" "$OPS" <<'PY'
import sys
lib,ops=map(lambda p:open(p).read(),sys.argv[1:])
a=lib.index('function bmwf_save_settings');b=lib.index('function bmwf_save_http_workers_proposal',a);save=lib[a:b]
assert 'traffic.php' not in save and 'service.php' not in save
p=ops.index('function bmwf_ops_preflight');q=ops.index('function bmwf_ops_require_preflight',p);pre=ops[p:q]
assert "['apply']" not in pre and "['activate']" not in pre
c=ops.index('function bmwf_ops_control');d=ops.index('function bmwf_ops_watchdog',c);control=ops[c:d]
start=control[control.index("if($action==='start')"):control.index("if($action==='stop')")]
assert "['apply']" not in start and "['activate']" not in start
restart=control[control.index("if($action==='restart')"):control.index("if($action==='activate')")]
assert "traffic.php',['remove']" in restart and "['apply']" not in restart and "['activate']" not in restart
assert "if($action==='activate')" in control
refresh=ops[ops.index('function bmwf_ops_refresh'):ops.index('function bmwf_ops_settings_hash')]
assert 'bmwf_ops_status()' in refresh and "['apply']" not in refresh and "['activate']" not in refresh
# Status reconciliation removes stale anchor for inactive motor or listeners.
assert 'function bmwf_ops_fail_open_reconcile' in ops
assert "traffic.php',['remove']" in ops[ops.index('function bmwf_ops_fail_open_reconcile'):ops.index('function bmwf_ops_status')]
assert "if($removed)@unlink(BMWF_ACTIVATION_STATE)" in ops
assert "count($parsed['rules'])>0" in ops
traffic=open(sys.argv[1].replace('usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php','usr/local/sbin/blockmanager-webfilter-traffic.php')).read()
assert "count($parsed['rules'])>0" in traffic
assert "confirmed_inactive" in traffic and "for ($i=1;$i<=3;$i++)" in traffic
assert "saved_state_advisory" in ops and "source'=>'pfctl-live'" in ops
PY
python3 - <<'PY'
import re
pat=re.compile(r'^(?:@\d+\s+)?(?:no\s+)?(?:rdr|nat|binat)\b',re.I)
warning='No ALTQ support in kernel\nALTQ related functions disabled'
assert not any(pat.search(x.strip()) for x in warning.splitlines())
rules='No ALTQ support in kernel\nrdr pass on hn1 inet proto tcp from 192.168.10.0/24 to any port 80 -> 127.0.0.1 port 8080\nno rdr on hn1 inet proto tcp from <bypass> to any port 80'
assert sum(bool(pat.search(x.strip())) for x in rules.splitlines())==2
print('OK: pfctl diagnostics do not count as active NAT/RDR rules')
PY
# Port migration: legacy ports are changed, valid custom ports remain.
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/usr/local/etc/blockmanager/webfilter" "$TMP/var/db/blockmanager/webfilter"
cp "$DEFAULTS" "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
cat >"$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'JSON'
{"version":4,"enabled":true,"mode":"audit","activation":{"http_port":3128,"https_port":3129,"interfaces":["hn1"]},"engine":{"driver":"squid-legacy","binary":"/usr/local/sbin/squid","config_file":"/tmp/squid.conf"},"backend":{}}
JSON
python3 "$BASE/tools/blockmanager-webfilter-migrate.py" --root "$TMP" >/dev/null
python3 - "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
assert x['enabled'] is True and x['activation']['interfaces']==['hn1']
assert x['activation']['http_port']==8080 and x['activation']['https_port']==8443
assert x['engine']['driver']=='e2guardian' and x['engine']['binary']=='/usr/local/sbin/e2guardian'
assert x['engine']['config_file']=='/usr/local/etc/blockmanager/webfilter/generated/e2guardian.conf'
assert 'upstream' not in x['engine']
assert x['backend']['pid_file']=='/var/run/blockmanager-webfilter/e2guardian.pid'
PY
cat >"$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'JSON'
{"version":4,"enabled":false,"activation":{"http_port":9080,"https_port":9443},"engine":{},"backend":{}}
JSON
python3 "$BASE/tools/blockmanager-webfilter-migrate.py" --root "$TMP" >/dev/null
python3 - "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));assert x['activation']['http_port']==9080 and x['activation']['https_port']==9443
PY
echo 'OK: production WebGUI, persistent root anchor, E2Guardian-only backend, port migration and fail-open reconciliation verified'
