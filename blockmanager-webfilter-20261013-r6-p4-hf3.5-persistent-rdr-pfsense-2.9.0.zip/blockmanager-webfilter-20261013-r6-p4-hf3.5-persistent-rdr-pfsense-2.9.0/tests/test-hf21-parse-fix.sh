#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.."&&pwd)
LIB="$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
sh -n "$BASE/blockmanager-webfilter-install.sh"
python3 "$BASE/tests/php-delimiter-scan.py" "$BASE/usr/local/www" "$BASE/usr/local/sbin" "$BASE/tools"
# Exact RCA regression: both max/min calls must close before the semicolon.
grep -Fq "max(1048576,min(104857600,(int)\$input['access_log_rotate_mb']*1048576));" "$LIB"
! grep -Fq "max(1048576,min(104857600,(int)\$input['access_log_rotate_mb']*1048576);" "$LIB"
# The target installer must lint before creating backup or promoting files.
LINT_LINE=$(grep -n "/usr/local/bin/php -l \"\$f\"" "$BASE/blockmanager-webfilter-install.sh" | cut -d: -f1)
BACKUP_LINE=$(grep -n 'mkdir -p "\$BACKUP/rootfs"' "$BASE/blockmanager-webfilter-install.sh" | cut -d: -f1)
[ -n "$LINT_LINE" ] && [ -n "$BACKUP_LINE" ] && [ "$LINT_LINE" -lt "$BACKUP_LINE" ]
# Validated behavior remains intact.
grep -Fq "bmwf_engine_supervisor_pid" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "[\$daemon,'-P',\$supervisorPid" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq 'Salvar sem ativar' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
python3 - "$LIB" <<'PY'
import sys
s=open(sys.argv[1]).read();a=s.index('function bmwf_save_settings');b=s.index('function bmwf_save_http_workers_proposal',a);x=s[a:b]
assert 'service.php' not in x and 'traffic.php' not in x
assert "'redirect_applied'=>false" in x
PY
echo 'OK: parse fix, preinstall php -l gate, menu/PID and no-auto-redirect verified'
