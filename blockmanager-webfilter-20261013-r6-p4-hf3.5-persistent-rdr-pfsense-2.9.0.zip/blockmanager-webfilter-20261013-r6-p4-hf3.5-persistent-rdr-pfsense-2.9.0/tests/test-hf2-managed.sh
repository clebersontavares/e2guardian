#!/bin/sh
set -eu
BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.."&&pwd)
for f in "$BASE"/*.sh "$BASE/tests"/*.sh "$BASE/usr/local/etc/rc.d"/*;do sh -n "$f";done
python3 -m json.tool "$BASE/blockmanager-webfilter-release.json" >/dev/null
python3 -m json.tool "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" >/dev/null
python3 -m json.tool "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json" >/dev/null
grep -Fq "bmwf_engine_supervisor_pid" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "[\$daemon,'-P',\$supervisorPid" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
! grep -Fq "[\$daemon,'-p',\$pid,'-f',\$binary" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq 'Interfaces internas do proxy transparente' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'Usar CA do pfSense' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'Bypass de origem e destino' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'Blacklist por URL' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq "'auth_mode'=>'ip'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq 'no rdr on' "$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php"
grep -Fq 'rfc1918_destinations' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'Watchdog desabilitado' "$BASE/usr/local/sbin/blockmanager-webfilter-watchdog.php"
# No save path may call service/traffic.
python3 - "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php" <<'PY'
import sys
s=open(sys.argv[1]).read();a=s.index('function bmwf_save_settings');b=s.index('function bmwf_save_http_workers_proposal',a);x=s[a:b]
assert 'service.php' not in x and 'traffic.php' not in x and "['apply']" not in x and "['activate']" not in x
assert "'redirect_applied'=>false" in x
PY
# Migration fixture: exact current screen state preserved; additions only.
TMP=$(mktemp -d);trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/usr/local/etc/blockmanager/webfilter" "$TMP/var/db/blockmanager/webfilter"
cp "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" "$TMP/usr/local/etc/blockmanager/webfilter/"
cat >"$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'JSON'
{"version":5,"enabled":false,"mode":"enforce","global_default_action":"allow","activation":{"scope":"production-all-compiled-networks","fail_open":true,"http_enabled":true,"https_profile":"sni","interfaces":[],"http_port":8080,"https_port":8443},"backend":{"pid_file":"/var/run/blockmanager-webfilter/e2guardian.pid","supervisor_pid_file":"/var/run/blockmanager-webfilter/e2guardian-daemon.pid"}}
JSON
python3 "$BASE/tools/blockmanager-webfilter-migrate.py" --root "$TMP" >/dev/null
python3 - "$TMP/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]));a=x['activation']
assert x['enabled'] is False and x['mode']=='enforce' and x['global_default_action']=='allow'
assert a['scope']=='production-all-compiled-networks' and 'pilot_group' not in a and 'pilot_networks' not in a and a['interfaces']==[]
assert a['https_profile']=='sni' and a['http_enabled'] is True and a['fail_open'] is True
assert x['watchdog']['enabled'] is False and x['bypass']['rfc1918_destinations'] is True
PY
[ ! -e "$TMP/var/db/blockmanager/webfilter/activation.json" ]
echo 'OK: hf3.5 preserva estado de produção, menu/PIDs separados e não ativa redirecionamento automaticamente'
