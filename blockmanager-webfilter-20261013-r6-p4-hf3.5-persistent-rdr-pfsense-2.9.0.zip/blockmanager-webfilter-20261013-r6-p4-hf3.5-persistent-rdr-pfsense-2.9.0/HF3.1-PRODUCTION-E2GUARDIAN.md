# r6-p4-hf3.1 — produção E2Guardian

## Backend

- Exclusivo: `/usr/local/sbin/e2guardian`.
- O runtime não possui detecção, geração nem controle de backend alternativo.
- A migração corrige `engine.driver`, `engine.binary`, `engine.config_file`, PID e comandos de start/stop/reload/status/test, preservando `enabled`, interfaces, grupos, redes, políticas, listas, CA e bypass.

## Portas

- HTTP padrão: `8080`.
- HTTPS transparente padrão: `8443`.
- Valores legados `3128/3129` são migrados para `8080/8443` na instalação, na leitura da configuração, no registro do backend e ao salvar pela WebGUI.
- Outras portas válidas entre 1024 e 65535 são preservadas.

## Fail-open

Ao abrir/atualizar Status, a WebGUI consulta o anchor real. Se ele estiver ativo e o PID do E2Guardian ou qualquer listener esperado estiver inativo, o sistema:

1. remove o anchor `blockmanager_webfilter`;
2. remove o estado de ativação;
3. grava a ocorrência no estado do watchdog e no histórico da WebGUI;
4. mantém o redirecionamento desativado.

O watchdog agendado executa a mesma verificação com as portas configuradas.

## WebGUI de produção

Não há dados ou fluxo de teste. A operação usa diretamente:

- interfaces protegidas;
- grupos e redes reais;
- políticas e listas reais;
- certificados/CA e bypass;
- modo Auditoria ou Aplicação;
- compilação e validação;
- ciclo do E2Guardian;
- ativação explícita;
- monitoramento, desativação e rollback.

Salvar, compilar, validar, iniciar e reiniciar não aplicam redirecionamento. Somente **Ativar piloto** pode aplicar o anchor.
