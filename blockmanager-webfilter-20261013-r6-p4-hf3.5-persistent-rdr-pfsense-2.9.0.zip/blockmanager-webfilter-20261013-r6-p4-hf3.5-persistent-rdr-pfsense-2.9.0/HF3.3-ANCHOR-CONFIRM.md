# r6-p4-hf3.3 — confirmação autoritativa do anchor PF

A atividade não é inferida de cache nem de qualquer saída textual não vazia. O sistema consulta `pfctl -a blockmanager_webfilter -sn` e considera ativo somente quando encontra regras reais iniciadas por `rdr`, `no rdr`, `nat`, `no nat`, `binat` ou `no binat`.

Avisos como `No ALTQ support in kernel` são classificados como diagnóstico e não tornam o anchor ativo.

O fail-open:

1. executa `pfctl -a blockmanager_webfilter -F all`;
2. aguarda e consulta novamente o anchor;
3. repete até três vezes se ainda houver regras;
4. marca inativo e remove o estado de ativação somente após consulta bem-sucedida e zero regras NAT/RDR;
5. se regras permanecerem, mantém o indicador ativo e exibe erro, sem alegar remoção.

Após fail-open confirmado, a WebGUI usa a nova consulta e mostra `Redirecionamento INATIVO` e `Anchor PF Inativo`. Em falha de consulta, mostra `DESCONHECIDO`, nunca um falso inativo.
