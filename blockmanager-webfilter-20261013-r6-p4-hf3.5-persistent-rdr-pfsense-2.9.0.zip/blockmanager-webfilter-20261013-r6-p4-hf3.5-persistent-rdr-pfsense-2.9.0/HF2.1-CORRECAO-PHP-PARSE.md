# r6-p4-hf2.1 — correção do PHP Parse error

A hf2 continha um parêntese de fechamento ausente na atribuição de `access_log_rotate_bytes` em `blockmanager-webfilter-lib.php`. O `;` era encontrado enquanto `max(...)` ainda aguardava `)`, produzindo `unexpected token ";", expecting ")"` na linha 318.

A hf2.1 corrige somente essa expressão, formata o bloco em linhas separadas e adiciona lint PHP obrigatório antes de qualquer arquivo ser promovido pelo instalador. A baseline r6-p4, o menu, a separação de PID e a política de não ativação automática permanecem iguais.
