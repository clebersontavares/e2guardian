# Adaptação para pfSense CE 2.9.0

A revisão r6-p4-hf3.1 preserva a baseline r6-p4, menu integrado e correção de PID. O backend operacional é exclusivamente E2Guardian 5.5.9r em `/usr/local/sbin/e2guardian`.

A instalação mantém serviço, cron e redirecionamento desativados. A WebGUI valida dependências, interface, CA, bypass, blacklists, configuração e listeners antes da ativação explícita.
