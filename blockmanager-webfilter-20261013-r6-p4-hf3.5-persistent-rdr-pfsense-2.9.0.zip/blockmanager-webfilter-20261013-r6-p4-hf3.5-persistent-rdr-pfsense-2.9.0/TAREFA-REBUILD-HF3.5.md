# Tarefa de reconstrução — r6-p4-hf3.5-persistent-rdr

## Objetivo

Reconstruir do zero, validar e publicar o pacote `blockmanager-webfilter-20261013-r6-p4-hf3.5-persistent-rdr-pfsense-2.9.0.zip` e seu arquivo externo `.zip.sha256`, sem depender dos artefatos não persistidos da execução anterior.

## Requisitos obrigatórios

- Integrar persistentemente `rdr-anchor "blockmanager_webfilter"` ao gerador do ruleset raiz do pfSense CE 2.9.0.
- Não editar apenas `/tmp/rules.debug`: a declaração deve sobreviver às regenerações normais do firewall.
- Não iniciar E2Guardian, não recarregar PF e não ativar redirecionamento durante instalação ou migração.
- Exigir ação administrativa explícita na WebGUI para regenerar o ruleset raiz e outra ação explícita para ativar produção.
- Selecionar interfaces dinamicamente na WebGUI e persistir o nome lógico; em cada firewall resolver nome lógico, interface física e IPv4 atual.
- Operar E2Guardian em HTTP 8080 e HTTPS transparente 8443 conforme a configuração.
- Aplicar o escopo de produção a todas as redes/CIDRs compiladas, sem perfil de teste controlado/piloto.
- Preservar fail-open, rollback incremental, rollback imediato, menus integrados e PIDs separados do E2Guardian e do supervisor.
- Gerar configuração multigrupo e `ipgroups` com precedência de identidade/IP e rede/CIDR.
- Manter estado inicial desabilitado e sem cron, serviço, worker ou tráfego iniciados automaticamente.

## Aceite estrutural

1. O instalador faz backup de `/etc/inc/filter.inc`, aplica um bloco idempotente com marcadores próprios e não executa `/etc/rc.filter_configure`.
2. O rollback restaura byte a byte o `filter.inc` anterior pelo manifesto de instalação.
3. O desinstalador remove somente o bloco do Block Manager e não recarrega PF automaticamente.
4. A ação WebGUI **Preparar anchor raiz** regenera explicitamente o ruleset e confirma a declaração no arquivo gerado e no PF carregado.
5. A ativação recusa prosseguir se o ruleset raiz não chamar `blockmanager_webfilter`.
6. A seleção de interface mostra `lógico → físico → IPv4` e as regras usam a interface física resolvida no firewall corrente.
7. Não existem campos de grupo/rede piloto no exemplo de configuração, schema ou WebGUI de produção.
8. Os valores padrão permanecem `enabled=false`, `service_started=false`, `worker_started=false`, `traffic_redirected=false`.

## Evidência homologada a preservar

Evidência de runtime fornecida como validação homologada para o cliente `192.168.10.104`:

- Evaluations: **315**
- Packets: **189**
- Bytes: **219640**
- State Creations: **3**
- Eventos reais em `/var/log/e2guardian/access.log`
- Eventos reais no Monitor em tempo real da WebGUI

Esses números são evidência homologada externa ao container de build. O build local valida estrutura, idempotência, rollback, sintaxe disponível e integridade; não inventa nem reexecuta counters de um firewall que não está conectado ao container.

## Entregáveis

- `blockmanager-webfilter-20261013-r6-p4-hf3.5-persistent-rdr-pfsense-2.9.0.zip`
- `blockmanager-webfilter-20261013-r6-p4-hf3.5-persistent-rdr-pfsense-2.9.0.zip.sha256`
- Relatório `blockmanager-webfilter-validation.txt` dentro do ZIP.
