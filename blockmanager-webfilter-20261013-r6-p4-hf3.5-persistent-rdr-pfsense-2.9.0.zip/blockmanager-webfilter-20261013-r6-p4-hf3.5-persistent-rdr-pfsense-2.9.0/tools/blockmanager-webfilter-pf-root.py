#!/usr/bin/env python3
"""Offline/fixture equivalent of the persistent pfSense root-anchor patcher.

It never reloads PF and never starts/activates Web Filter services.
"""
from __future__ import annotations
import argparse, json, os, re, sys, tempfile
from pathlib import Path

BEGIN = "/* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN */"
END = "/* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_END */"
RULE = '$rules .= "rdr-anchor \\"blockmanager_webfilter\\"\\n";'


def strip_block(text: str) -> str:
    return re.sub(r"\r?\n?[ \t]*" + re.escape(BEGIN) + r".*?" + re.escape(END) + r"[ \t]*(?:\r?\n|$)", "\n", text, flags=re.S)


def patch_text(text: str) -> str:
    text = strip_block(text)
    lines = text.splitlines()
    insertion = None
    for i, line in enumerate(lines):
        if "rdr-anchor" in line.lower() and "tftp-proxy" in line.lower():
            insertion = i + 1
    if insertion is None:
        for i, line in enumerate(lines):
            if "rdr-anchor" in line.lower():
                insertion = i + 1
    if insertion is None:
        raise RuntimeError("Ponto de geração de rdr-anchor não localizado em /etc/inc/filter.inc; nenhuma alteração foi aplicada.")
    lines[insertion:insertion] = [BEGIN, RULE, END]
    result = "\n".join(lines) + ("\n" if text.endswith(("\n", "\r")) else "")
    if result.count(BEGIN) != 1 or result.count(RULE) != 1:
        raise RuntimeError("Patch do anchor raiz não ficou idempotente.")
    return result


def atomic_write(path: Path, text: str) -> None:
    mode = path.stat().st_mode & 0o777
    fd, name = tempfile.mkstemp(prefix=path.name + ".bmwf-new.", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8", newline="") as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(name, mode)
        os.replace(name, path)
    except Exception:
        try: os.unlink(name)
        except OSError: pass
        raise


def status(path: Path) -> dict:
    if not path.is_file():
        return {"ok": False, "file": str(path), "message": "filter.inc ausente."}
    text = path.read_text(encoding="utf-8")
    counts = {"begin_count": text.count(BEGIN), "end_count": text.count(END), "rule_count": text.count(RULE)}
    ok = all(value == 1 for value in counts.values())
    return {"ok": ok, "file": str(path), **counts, "automatic_activation": False,
            "message": "Gerador persistente contém exatamente um rdr-anchor do Block Manager." if ok else "Gerador persistente não contém o anchor esperado exatamente uma vez."}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["install", "remove", "status"])
    parser.add_argument("--root", default="/")
    args = parser.parse_args()
    root = Path(args.root)
    path = root / "etc/inc/filter.inc"
    try:
        if args.action == "install":
            original = path.read_text(encoding="utf-8")
            patched = patch_text(original)
            if patched != original:
                atomic_write(path, patched)
            result = status(path)
            result["message"] += " PF não foi recarregado e o tráfego não foi ativado."
        elif args.action == "remove":
            original = path.read_text(encoding="utf-8")
            clean = strip_block(original)
            if clean != original:
                atomic_write(path, clean)
            result = {"ok": BEGIN not in path.read_text(encoding="utf-8"), "automatic_activation": False,
                      "message": "Declaração persistente removida do gerador; PF não foi recarregado automaticamente."}
        else:
            result = status(path)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result.get("ok") else 3
    except Exception as exc:
        print(str(exc), file=sys.stderr)
        return 78


if __name__ == "__main__":
    raise SystemExit(main())
