# r6-p4-hf3.1 — operação de produção pela WebGUI

A WebGUI opera diretamente sobre interfaces protegidas, grupos, redes, políticas, listas, certificados e bypass reais. Não existem perfis, domínios, IPs ou fases de teste pré-preenchidos.

## Fluxo

1. **Configuração**: salvar sem aplicar tráfego.
2. **Políticas/Listas/Fontes externas**: operar os dados reais.
3. **Status > Compilar, gerar e validar**: registrar E2Guardian, executar lint PHP, validar dependências, compilar, gerar e testar E2Guardian/PF sem aplicar anchor.
4. **Iniciar sem tráfego**: iniciar apenas o motor.
5. **Ativar piloto**: única ação que aplica redirecionamento, sempre explicitamente e com fail-open.
6. **Desativar** ou **Rollback imediato**: remover anchor; rollback também para o motor e limpa o estado de ativação.

O modo Auditoria permanece uma opção operacional real.
