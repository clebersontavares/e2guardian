# r6-p4-hf3.5 — anchor RDR persistente e escopo de produção

## Declaração persistente no ruleset raiz

O pacote passa a inserir no gerador `/etc/inc/filter.inc`, com marcadores idempotentes, a declaração:

```pf
rdr-anchor "blockmanager_webfilter"
```

O arquivo temporário `/tmp/rules.debug` não é tratado como fonte de persistência. O instalador guarda o `filter.inc` anterior no manifesto de rollback e altera o gerador de forma atômica. Instalação, migração, atualização e desinstalação **não** executam reload do PF.

A WebGUI oferece a ação explícita **Preparar anchor raiz**, que executa `/etc/rc.filter_configure` e confirma a declaração no ruleset gerado e no PF carregado. A ativação do tráfego é uma ação administrativa distinta e também explícita.

## Produção sem perfil de teste controlado

- Não há seleção de grupo piloto nem de redes piloto.
- O motor gera todos os grupos habilitados e o mapa `ipgroups`.
- O redirecionamento cobre todas as redes/CIDRs compiladas nas interfaces internas selecionadas.
- `enabled=false` continua sendo o estado inicial.
- Salvar configuração nunca inicia motor, worker, cron ou redirecionamento.

## Interfaces portáveis entre firewalls

A WebGUI persiste o **nome lógico** (`lan`, `optN` etc.). Em cada firewall, o runtime consulta a configuração corrente do pfSense e resolve:

1. nome lógico;
2. interface física atual;
3. IPv4 atual e prefixo, quando atribuídos.

As regras PF usam exclusivamente a interface física resolvida. Seletores físicos legados continuam aceitos durante migração e são normalizados para o nome lógico no próximo salvamento.

## E2Guardian e segurança operacional

- HTTP: porta **8080**.
- HTTPS transparente: porta **8443** quando o perfil HTTPS está habilitado.
- PID do motor: `/var/run/blockmanager-webfilter/e2guardian.pid`.
- PID do supervisor: `/var/run/blockmanager-webfilter/e2guardian-daemon.pid`.
- Fail-open remove e confirma as regras NAT/RDR do child anchor.
- Rollback imediato remove redirecionamento e para o motor.
- Rollback incremental restaura todos os arquivos, inclusive o gerador do ruleset raiz.

## Validação homologada

Evidência homologada fornecida para `192.168.10.104`:

| Métrica | Valor |
|---|---:|
| Evaluations | 315 |
| Packets | 189 |
| Bytes | 219640 |
| State Creations | 3 |

Também foram informados eventos reais em `/var/log/e2guardian/access.log` e no Monitor em tempo real da WebGUI. Essa evidência é preservada no relatório do pacote; o container de build não simula esses counters como se fossem uma nova execução em pfSense.
