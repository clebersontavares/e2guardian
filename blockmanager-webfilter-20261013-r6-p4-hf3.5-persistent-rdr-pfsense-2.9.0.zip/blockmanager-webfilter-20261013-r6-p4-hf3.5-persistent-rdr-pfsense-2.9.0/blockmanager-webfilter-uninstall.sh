#!/bin/sh
set -eu
ROOT=/;while [ $# -gt 0 ];do case "$1" in --root)ROOT=$2;shift 2;;*)echo "Opção inválida: $1" >&2;exit 64;;esac;done
ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/;SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")"&&pwd)
if [ "$ROOT" = / ]&&[ -x /usr/local/bin/php ]&&[ -f /usr/local/sbin/blockmanager-webfilter-service.php ];then /usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-service.php stop >/dev/null 2>&1||true;fi
# Remove only r3/r4/r5 markers from shared UI; preserve every unrelated byte.
if command -v python3 >/dev/null 2>&1;then python3 - "$ROOT" <<'PY'
from pathlib import Path
import re,sys
root=Path(sys.argv[1]);pairs=[('/* BLOCKMANAGER_WEBFILTER_SIDEBAR_BEGIN */','/* BLOCKMANAGER_WEBFILTER_SIDEBAR_END */')]
for rel,extra in [('usr/local/www/dnsmanager/templates/sidebar.php',pairs),('usr/local/www/block_manager.php',([(f'/* BLOCKMANAGER_WEBFILTER_{x}_BEGIN */',f'/* BLOCKMANAGER_WEBFILTER_{x}_END */') for x in ['BOOTSTRAP','TABS','PREPARE','TITLES']]+[('<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->','<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->'),('/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */','/* BLOCKMANAGER_WEBFILTER_PAGE_END */')]))]:
 p=root/rel
 if not p.is_file():continue
 t=p.read_text(encoding='utf-8')
 for a,b in extra:t=re.sub(r'\s*'+re.escape(a)+r'.*?'+re.escape(b),'',t,flags=re.S)
 t=t.replace('&&!dc_native_is_tab($tab)&&!bmwf_is_tab($tab))','&&!dc_native_is_tab($tab))')
 p.write_text(t,encoding='utf-8')
f=root/'etc/inc/filter.inc'
if f.is_file():
 t=f.read_text(encoding='utf-8')
 t=re.sub(r'\s*/\* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN \*/.*?/\* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_END \*/','',t,flags=re.S)
 f.write_text(t,encoding='utf-8')
PY
else echo "Python necessário para remoção seletiva; use o rollback do instalador." >&2;exit 69;fi
if [ "$ROOT" = / ]&&command -v crontab >/dev/null 2>&1;then crontab -l 2>/dev/null|grep -v '# blockmanager-webfilter-worker'|crontab - 2>/dev/null||true;fi
for r in usr/local/www/dnsmanager/includes/webfilter.php usr/local/www/dnsmanager/pages/webfilter.php usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php usr/local/sbin/blockmanager-identity-catalog-worker.php usr/local/sbin/blockmanager-webfilter-worker.php usr/local/sbin/blockmanager-webfilter-engine.php usr/local/sbin/blockmanager-webfilter-traffic.php usr/local/sbin/blockmanager-webfilter-service.php usr/local/sbin/blockmanager-webfilter-watchdog.php usr/local/sbin/blockmanager-webfilter-webgui-ops.php usr/local/sbin/blockmanager-webfilter-pf-root.php usr/local/etc/rc.d/blockmanager_webfilter usr/local/share/blockmanager/webfilter/dependency-lock.json;do rm -f "$ROOT/$r";done
echo "Integração executável e declaração persistente removidas; PF não foi recarregado automaticamente. Configuração, listas, estado e logs foram preservados."
