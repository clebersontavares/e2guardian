#!/usr/local/bin/php -q
<?php
/**
 * Manage the persistent root PF declaration required by the Web Filter.
 *
 * This patches the pfSense rules generator, not /tmp/rules.debug. The child
 * anchor remains empty until an administrator explicitly activates production
 * traffic. Installation never reloads PF and never starts E2Guardian.
 */
const BMWF_ROOT_BEGIN = '/* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN */';
const BMWF_ROOT_END = '/* BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_END */';
const BMWF_ROOT_RULE = '$rules .= "rdr-anchor \\"blockmanager_webfilter\\"\\n";';

function bmwf_root_parse(array $argv): array {
    $action = $argv[1] ?? 'status';
    $root = '/';
    $requireLive = false;
    for ($i = 2; $i < count($argv); $i++) {
        if ($argv[$i] === '--root' && isset($argv[$i + 1])) $root = $argv[++$i];
        elseif ($argv[$i] === '--require-live') $requireLive = true;
        else throw new InvalidArgumentException('Uso: blockmanager-webfilter-pf-root.php install|remove|status|reload [--root DIR] [--require-live]');
    }
    $root = rtrim($root, '/');
    if ($root === '') $root = '/';
    return [$action, $root, $requireLive];
}
function bmwf_root_path(string $root, string $path): string {
    return $root === '/' ? $path : $root . $path;
}
function bmwf_root_strip(string $text): string {
    $pattern = '/\R?[ \t]*' . preg_quote(BMWF_ROOT_BEGIN, '/') . '.*?' . preg_quote(BMWF_ROOT_END, '/') . '[ \t]*(?:\R|$)/s';
    return (string)preg_replace($pattern, "\n", $text);
}
function bmwf_root_patch_text(string $text): string {
    $text = bmwf_root_strip($text);
    $lines = preg_split('/\R/', $text);
    $insertAt = null;
    foreach ($lines as $index => $line) {
        if (stripos($line, 'rdr-anchor') !== false && stripos($line, 'tftp-proxy') !== false) $insertAt = $index + 1;
    }
    if ($insertAt === null) {
        foreach ($lines as $index => $line) if (stripos($line, 'rdr-anchor') !== false) $insertAt = $index + 1;
    }
    if ($insertAt === null) throw new RuntimeException('Ponto de geração de rdr-anchor não localizado em /etc/inc/filter.inc; nenhuma alteração foi aplicada.');
    $block = [BMWF_ROOT_BEGIN, BMWF_ROOT_RULE, BMWF_ROOT_END];
    array_splice($lines, $insertAt, 0, $block);
    $out = implode("\n", $lines);
    if (substr_count($out, BMWF_ROOT_BEGIN) !== 1 || substr_count($out, BMWF_ROOT_RULE) !== 1) throw new RuntimeException('Patch do anchor raiz não ficou idempotente.');
    return $out;
}
function bmwf_root_atomic(string $file, string $text): void {
    $mode = is_file($file) ? (fileperms($file) & 0777) : 0644;
    $tmp = $file . '.bmwf-new.' . getmypid();
    if (file_put_contents($tmp, $text, LOCK_EX) === false) throw new RuntimeException('Falha ao gravar staging de ' . $file);
    @chmod($tmp, $mode);
    if (!rename($tmp, $file)) { @unlink($tmp); throw new RuntimeException('Falha ao promover ' . $file); }
}
function bmwf_root_source_status(string $root): array {
    $file = bmwf_root_path($root, '/etc/inc/filter.inc');
    if (!is_file($file)) return ['ok' => false, 'file' => $file, 'message' => 'filter.inc ausente.'];
    $text = (string)file_get_contents($file);
    $begin = substr_count($text, BMWF_ROOT_BEGIN);
    $end = substr_count($text, BMWF_ROOT_END);
    $rule = substr_count($text, BMWF_ROOT_RULE);
    return ['ok' => $begin === 1 && $end === 1 && $rule === 1, 'file' => $file, 'begin_count' => $begin, 'end_count' => $end, 'rule_count' => $rule, 'message' => ($begin === 1 && $end === 1 && $rule === 1) ? 'Gerador persistente contém exatamente um rdr-anchor do Block Manager.' : 'Gerador persistente não contém o anchor esperado exatamente uma vez.'];
}
function bmwf_root_live_status(string $root): array {
    $rulesFile = bmwf_root_path($root, '/tmp/rules.debug');
    $text = is_file($rulesFile) ? (string)file_get_contents($rulesFile) : '';
    $generated = preg_match('/^[ \t]*rdr-anchor[ \t]+["\x27]blockmanager_webfilter["\x27](?:[ \t]+all)?[ \t]*$/m', $text) === 1;
    $pfctlChecked = false; $loaded = false; $raw = '';
    if ($root === '/' && is_executable('/sbin/pfctl')) {
        $pfctlChecked = true;
        exec('/sbin/pfctl -sn 2>&1', $lines, $code);
        $raw = implode("\n", $lines);
        $loaded = $code === 0 && preg_match('/^[ \t]*rdr-anchor[ \t]+["\x27]blockmanager_webfilter["\x27](?:[ \t]+all)?[ \t]*$/m', $raw) === 1;
    }
    return ['generated' => $generated, 'rules_file' => $rulesFile, 'pfctl_checked' => $pfctlChecked, 'loaded' => $loaded, 'raw' => $raw];
}
function bmwf_root_result(string $root): array {
    $source = bmwf_root_source_status($root);
    $live = bmwf_root_live_status($root);
    return ['ok' => $source['ok'] && ($root !== '/' || ($live['generated'] && (!$live['pfctl_checked'] || $live['loaded']))), 'source' => $source, 'live' => $live, 'automatic_activation' => false, 'message' => $source['message'] . ($root === '/' ? (' Ruleset gerado ' . ($live['generated'] ? 'OK' : 'pendente') . '; PF carregado ' . ($live['pfctl_checked'] ? ($live['loaded'] ? 'OK' : 'pendente') : 'não consultado') . '.') : '')];
}
function bmwf_root_main(array $argv): int {
    try { [$action, $root, $requireLive] = bmwf_root_parse($argv); }
    catch (Throwable $e) { fwrite(STDERR, $e->getMessage() . "\n"); return 64; }
    $file = bmwf_root_path($root, '/etc/inc/filter.inc');
    try {
        if ($action === 'install') {
            if (!is_file($file)) throw new RuntimeException('filter.inc ausente: ' . $file);
            $original = (string)file_get_contents($file);
            $patched = bmwf_root_patch_text($original);
            if ($patched !== $original) bmwf_root_atomic($file, $patched);
            $result = bmwf_root_source_status($root);
            $result['automatic_activation'] = false;
            $result['message'] .= ' PF não foi recarregado e o tráfego não foi ativado.';
        } elseif ($action === 'remove') {
            if (!is_file($file)) throw new RuntimeException('filter.inc ausente: ' . $file);
            $original = (string)file_get_contents($file);
            $clean = bmwf_root_strip($original);
            if ($clean !== $original) bmwf_root_atomic($file, $clean);
            $result = ['ok' => strpos((string)file_get_contents($file), BMWF_ROOT_BEGIN) === false, 'automatic_activation' => false, 'message' => 'Declaração persistente removida do gerador; PF não foi recarregado automaticamente.'];
        } elseif ($action === 'reload') {
            $source = bmwf_root_source_status($root);
            if (!$source['ok']) throw new RuntimeException($source['message']);
            if ($root !== '/') throw new RuntimeException('reload exige --root /.');
            if (!is_executable('/etc/rc.filter_configure')) throw new RuntimeException('/etc/rc.filter_configure indisponível.');
            exec('/etc/rc.filter_configure 2>&1', $lines, $code);
            if ($code !== 0) throw new RuntimeException('Falha ao regenerar ruleset: ' . implode("\n", $lines));
            $result = bmwf_root_result($root);
            $result['explicit_reload'] = true;
            $result['message'] = $result['ok'] ? 'Ruleset raiz regenerado explicitamente e rdr-anchor persistente confirmado.' : 'Reload concluído, mas o anchor raiz não pôde ser confirmado.';
        } elseif ($action === 'status') $result = bmwf_root_result($root);
        else throw new InvalidArgumentException('Ação inválida.');
        echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . "\n";
        $ok = !empty($result['ok']);
        if ($requireLive && $root === '/') $ok = $ok && !empty($result['live']['generated']) && (empty($result['live']['pfctl_checked']) || !empty($result['live']['loaded']));
        return $ok ? 0 : 3;
    } catch (Throwable $e) {
        fwrite(STDERR, $e->getMessage() . "\n");
        return $e instanceof InvalidArgumentException ? 64 : 78;
    }
}
if (PHP_SAPI !== 'cli') { http_response_code(403); exit; }
exit(bmwf_root_main($argv));
