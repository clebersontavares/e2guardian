#!/usr/local/bin/php -q
<?php
/** Explicit, reversible production redirection for all compiled internal networks. */
if (is_file('/etc/inc/config.inc')) require_once '/etc/inc/config.inc';
require_once '/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php';
const BMWF_TRAFFIC_RULES = BMWF_CONFIG_DIR . '/generated/traffic-anchor.conf';
const BMWF_TRAFFIC_STATE = BMWF_STATE_DIR . '/traffic-status.json';

function bmwf_traffic_exec(array $argv): array { return bmwf_exec($argv); }
function bmwf_pf_nat_rules(string $output): array {
    $rules=[]; $diagnostics=[];
    foreach (preg_split('/\R/', trim($output)) as $line) {
        $line=trim((string)$line); if ($line==='') continue;
        if (preg_match('/^(?:@\d+\s+)?(?:no\s+)?(?:rdr|nat|binat)\b/i',$line)) $rules[]=$line; else $diagnostics[]=$line;
    }
    return ['rules'=>$rules,'diagnostics'=>$diagnostics];
}
function bmwf_traffic_anchor_query(): array {
    $pfctl='/sbin/pfctl';
    if (!is_executable($pfctl)) return ['ok'=>false,'exit_code'=>69,'active'=>false,'rules'=>[],'diagnostics'=>[],'raw'=>'pfctl ausente'];
    $query=bmwf_traffic_exec([$pfctl,'-a','blockmanager_webfilter','-sn']);
    $parsed=bmwf_pf_nat_rules((string)($query['output']??''));
    return ['ok'=>!empty($query['ok']),'exit_code'=>(int)($query['exit_code']??1),'active'=>!empty($query['ok'])&&count($parsed['rules'])>0,'rules'=>$parsed['rules'],'diagnostics'=>$parsed['diagnostics'],'raw'=>(string)($query['output']??'')];
}
function bmwf_traffic_validate_name(string $value): bool { return preg_match('/^[A-Za-z0-9_.:-]{1,32}$/D',$value)===1; }
function bmwf_traffic_production_cidrs(array $compiled): array {
    $out=[];
    foreach ((array)($compiled['network_rules']??[]) as $rule) {
        $cidr=trim((string)($rule['cidr']??''));
        if ($cidr!=='' && bmwf_ipv4_cidr_valid($cidr)) $out[$cidr]=true;
    }
    $cidrs=array_keys($out); sort($cidrs,SORT_NATURAL); return $cidrs;
}
function bmwf_traffic_interfaces(array $activation): array {
    $catalog=bmwf_pfsense_interface_catalog(); $resolved=[];
    foreach ((array)($activation['interfaces']??[]) as $selector) {
        $selector=trim((string)$selector); if ($selector==='') continue;
        $row=$catalog[$selector]??null;
        if (!$row) foreach ($catalog as $candidate) if (($candidate['device']??'')===$selector) { $row=$candidate; break; }
        if (!$row) throw new RuntimeException('Interface lógica/física não atribuída neste firewall: '.$selector);
        $device=trim((string)($row['device']??''));
        if (!bmwf_traffic_validate_name($device)) throw new RuntimeException('Interface física de redirecionamento inválida: '.$device);
        $resolved[$device]=['logical'=>(string)$row['logical'],'device'=>$device,'ipv4'=>(string)($row['ipv4']??''),'address'=>(string)($row['address']??'')];
    }
    if (!$resolved) throw new RuntimeException('Nenhuma interface interna selecionada.');
    return $resolved;
}
function bmwf_traffic_root_gate(): array {
    $php=is_executable('/usr/local/bin/php')?'/usr/local/bin/php':PHP_BINARY;
    $script='/usr/local/sbin/blockmanager-webfilter-pf-root.php';
    if (!is_file($script)) return ['ok'=>false,'exit_code'=>69,'output'=>'Controlador do anchor raiz ausente.'];
    return bmwf_traffic_exec([$php,'-q',$script,'status','--require-live']);
}
function bmwf_traffic_generate(array $settings): array {
    if (!is_file(BMWF_GENERATED_FILE)) throw new RuntimeException('Políticas compiladas ausentes.');
    $compiled=bmwf_json_read(BMWF_GENERATED_FILE,[]); $activation=(array)($settings['activation']??[]);
    $httpsGate=bmwf_https_inspection_gate($settings); if (!$httpsGate['ok']) throw new RuntimeException($httpsGate['msg']);
    $interfaces=bmwf_traffic_interfaces($activation); $cidrs=bmwf_traffic_production_cidrs($compiled);
    if (!$cidrs) throw new RuntimeException('Nenhuma rede/CIDR de produção foi compilada.');
    $bypass=(array)($settings['bypass']??[]); $src=bmwf_resolve_endpoint_entries((array)($bypass['sources']??[]));
    $dstEntries=(array)($bypass['destinations']??[]); if (!empty($bypass['rfc1918_destinations'])) $dstEntries=array_merge($dstEntries,['10.0.0.0/8','172.16.0.0/12','192.168.0.0/16']);
    $dst=bmwf_resolve_endpoint_entries($dstEntries); $errors=array_merge(array_map(fn($x)=>'origem: '.$x,$src['errors']),array_map(fn($x)=>'destino: '.$x,$dst['errors']));
    if ($errors) throw new RuntimeException('Bypass não resolvido: '.implode(', ',$errors));
    $httpPort=max(1024,min(65535,(int)($activation['http_port']??8080))); $httpsPort=max(1024,min(65535,(int)($activation['https_port']??8443)));
    $https=(string)($activation['https_profile']??'off'); $ports=[]; if (!empty($activation['http_enabled'])) $ports[]=80; if ($https!=='off') $ports[]=443;
    if (!$ports) throw new RuntimeException('HTTP e HTTPS estão desativados; não há porta para redirecionar.');
    $portSet=count($ports)>1?'{ '.implode(' ',$ports).' }':(string)$ports[0];
    $lines=['# Generated production redirection. Explicit activation required.','# Persistent root call: rdr-anchor "blockmanager_webfilter"'];
    if ($src['addresses']) $lines[]='table <bmwf_bypass_src> const { '.implode(', ',$src['addresses']).' }';
    if ($dst['addresses']) $lines[]='table <bmwf_bypass_dst> const { '.implode(', ',$dst['addresses']).' }';
    foreach ($interfaces as $device=>$meta) {
        $lines[]='# '.$meta['logical'].' -> '.$device.($meta['address']!==''?' -> '.$meta['address']:'');
        if ($src['addresses']) $lines[]="no rdr on $device inet proto tcp from <bmwf_bypass_src> to any port $portSet";
        foreach ($cidrs as $cidr) {
            if ($dst['addresses']) $lines[]="no rdr on $device inet proto tcp from $cidr to <bmwf_bypass_dst> port $portSet";
            if (!empty($activation['http_enabled'])) $lines[]="rdr pass on $device inet proto tcp from $cidr to any port 80 -> 127.0.0.1 port $httpPort";
            if ($https!=='off') $lines[]="rdr pass on $device inet proto tcp from $cidr to any port 443 -> 127.0.0.1 port $httpsPort";
        }
    }
    bmwf_atomic_text(BMWF_TRAFFIC_RULES,implode("\n",$lines)."\n",0600);
    return ['rules_file'=>BMWF_TRAFFIC_RULES,'scope'=>'production-all-compiled-networks','interfaces'=>array_values($interfaces),'production_cidrs'=>$cidrs,'https_profile'=>$https,'http_port'=>$httpPort,'https_port'=>$httpsPort,'source_bypass'=>$src['addresses'],'destination_bypass'=>$dst['addresses'],'rule_count'=>count($lines)-2];
}
function bmwf_traffic_remove(): array {
    $pfctl='/sbin/pfctl'; if (!is_executable($pfctl)) return ['ok'=>false,'exit_code'=>69,'output'=>'Controlador de tráfego indisponível.'];
    $attempts=[]; $confirmed=null;
    for ($i=1;$i<=3;$i++) {
        $flush=bmwf_traffic_exec([$pfctl,'-a','blockmanager_webfilter','-F','all']); usleep(100000); $confirmed=bmwf_traffic_anchor_query();
        $attempts[]=['attempt'=>$i,'flush_ok'=>!empty($flush['ok']),'flush_output'=>(string)($flush['output']??''),'query_ok'=>!empty($confirmed['ok']),'active'=>!empty($confirmed['active']),'rules'=>$confirmed['rules']??[],'diagnostics'=>$confirmed['diagnostics']??[]];
        if (!empty($confirmed['ok'])&&empty($confirmed['active'])) break;
    }
    $ok=is_array($confirmed)&&!empty($confirmed['ok'])&&empty($confirmed['active']);
    $output=$ok?'Anchor PF removido e ausência de regras NAT/RDR confirmada pelo pfctl.':'Não foi possível confirmar a remoção real do anchor PF.';
    $state=['status'=>$ok?'inactive':'error','updated_at'=>date(DATE_ATOM),'action'=>'remove','confirmed_inactive'=>$ok,'active_after'=>is_array($confirmed)?(bool)($confirmed['active']??false):null,'rules_after'=>$confirmed['rules']??[],'diagnostics'=>$confirmed['diagnostics']??[],'attempts'=>$attempts,'message'=>$output];
    bmwf_atomic_json(BMWF_TRAFFIC_STATE,$state); return ['ok'=>$ok,'exit_code'=>$ok?0:1,'output'=>$output,'verification'=>$confirmed,'attempts'=>$attempts];
}
function bmwf_traffic_apply(array $settings): array {
    $pfctl='/sbin/pfctl'; if (!is_executable($pfctl)) return ['ok'=>false,'exit_code'=>69,'output'=>'Controlador de tráfego indisponível.'];
    $root=bmwf_traffic_root_gate(); if (empty($root['ok'])) return ['ok'=>false,'exit_code'=>78,'output'=>'O ruleset raiz ainda não chama rdr-anchor "blockmanager_webfilter". Use Status > Preparar anchor raiz antes de ativar. '.$root['output']];
    try {$meta=bmwf_traffic_generate($settings);} catch (Throwable $error) { return ['ok'=>false,'exit_code'=>78,'output'=>$error->getMessage()]; }
    $test=bmwf_traffic_exec([$pfctl,'-n','-f',BMWF_TRAFFIC_RULES]); if (!$test['ok']) return $test;
    $apply=bmwf_traffic_exec([$pfctl,'-a','blockmanager_webfilter','-f',BMWF_TRAFFIC_RULES]); $verify=bmwf_traffic_anchor_query();
    $ok=!empty($apply['ok'])&&!empty($verify['ok'])&&!empty($verify['active']); $output=$ok?'Anchor PF de produção aplicado e regras NAT/RDR confirmadas pelo pfctl.':'Aplicação não pôde ser confirmada pelo pfctl.';
    $state=['status'=>$ok?'active':'error','updated_at'=>date(DATE_ATOM),'action'=>'apply','confirmed_active'=>$ok,'message'=>$output,'apply_output'=>$apply['output'],'verification'=>$verify,'meta'=>$meta];
    bmwf_atomic_json(BMWF_TRAFFIC_STATE,$state); return ['ok'=>$ok,'exit_code'=>$ok?0:1,'output'=>$output,'verification'=>$verify,'meta'=>$meta];
}
function bmwf_traffic_main(array $argv): int {
    $action=$argv[1]??'status'; $settings=bmwf_settings();
    if ($action==='generate') { try {$meta=bmwf_traffic_generate($settings);echo json_encode(['ok'=>true,'meta'=>$meta],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";return 0;} catch(Throwable$error){fwrite(STDERR,$error->getMessage()."\n");return 78;} }
    if ($action==='test') { try {bmwf_traffic_generate($settings);$result=bmwf_traffic_exec(['/sbin/pfctl','-n','-f',BMWF_TRAFFIC_RULES]);} catch(Throwable$error){$result=['ok'=>false,'exit_code'=>78,'output'=>$error->getMessage()];} }
    elseif ($action==='apply') $result=bmwf_traffic_apply($settings);
    elseif (in_array($action,['remove','stop'],true)) $result=bmwf_traffic_remove();
    elseif ($action==='status') { $query=bmwf_traffic_anchor_query();$state=['status'=>!empty($query['active'])?'active':(!empty($query['ok'])?'inactive':'error'),'message'=>!empty($query['active'])?'Redirecionamento ativo confirmado pelo pfctl.':(!empty($query['ok'])?'Anchor sem regras NAT/RDR.':'Falha ao consultar o anchor.'),'source'=>'pfctl-live','query'=>$query,'saved_state'=>bmwf_json_read(BMWF_TRAFFIC_STATE,[])];echo json_encode($state,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";return!empty($query['active'])?0:3; }
    else $result=['ok'=>false,'exit_code'=>64,'output'=>'Ação inválida.'];
    echo json_encode($result,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n"; return $result['ok']?0:(int)$result['exit_code'];
}
if (PHP_SAPI!=='cli'){http_response_code(403);exit;} exit(bmwf_traffic_main($argv));
