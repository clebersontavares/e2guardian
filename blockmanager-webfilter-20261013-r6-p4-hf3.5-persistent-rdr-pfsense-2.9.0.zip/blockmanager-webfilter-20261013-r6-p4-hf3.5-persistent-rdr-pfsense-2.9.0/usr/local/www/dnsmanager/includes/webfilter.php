<?php
/** Integrated Web Filter controller for the existing Block Manager bootstrap. */
if (!defined('DNSM_V1462_BOOTSTRAPPED') && !defined('DNSM_V1452_BOOTSTRAPPED') && !defined('DNSM_V1451_BOOTSTRAPPED') && !defined('DNSM_V1450_BOOTSTRAPPED') && !defined('DNSM_V1444_BOOTSTRAPPED') && !defined('DNSM_V1443_BOOTSTRAPPED') && !defined('DNSM_V1442_BOOTSTRAPPED') && !defined('DNSM_V1441_BOOTSTRAPPED') && !defined('DNSM_V144_BOOTSTRAPPED')) { http_response_code(403); exit; }
require_once __DIR__ . '/../../blockmanager-webfilter/blockmanager-webfilter-lib.php';

function bmwf_tabs(): array { return ['webfilter','webfilter_policies','webfilter_lists','webfilter_sources','webfilter_logs','webfilter_status','webfilter_settings']; }
function bmwf_is_tab(string $tab): bool { return in_array($tab,bmwf_tabs(),true); }
function bmwf_titles(): array { return ['webfilter'=>'Web Filter - Visão geral','webfilter_policies'=>'Web Filter - Políticas','webfilter_lists'=>'Web Filter - Listas locais','webfilter_sources'=>'Web Filter - Fontes externas','webfilter_logs'=>'Web Filter - Monitor em tempo real','webfilter_status'=>'Web Filter - Status','webfilter_settings'=>'Web Filter - Configuração']; }
function bmwf_run_cli(string $script,array $args=[]):array {
    $php=is_executable('/usr/local/bin/php')?'/usr/local/bin/php':PHP_BINARY;
    return bmwf_exec(array_merge([$php,$script],$args));
}
function bmwf_result(array $r):array { return ['ok'=>!empty($r['ok']),'msg'=>(string)($r['msg']??$r['output']??'Ação concluída.')]; }
function bmwf_ops_call(string $action,array $arguments=[]):array {
    $argv=[$action];foreach($arguments as$key=>$value){$argv[]='--'.$key;$argv[]=(string)$value;}
    $run=bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-webgui-ops.php',$argv);$json=json_decode((string)($run['output']??''),true);
    if(!is_array($json))return['ok'=>false,'msg'=>'Operação não retornou JSON válido: '.(string)($run['output']??'sem saída'),'data'=>[]];
    return['ok'=>!empty($json['ok']),'msg'=>(string)($json['message']??'Operação concluída.'),'data'=>$json];
}

function bmwf_prepare(string $tab): void {
    global $message,$message_type;
    if(!bmwf_is_tab($tab))return;
    bmwf_ensure_dirs();
    if($tab==='webfilter_logs'&&($_GET['ajax']??'')==='tail'){
        while(ob_get_level()>0)ob_end_clean();header_remove('Content-Type');header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');
        $bmwfCollector=bmwf_collect_logs_throttled(2);$bmwfDelta=bmwf_log_delta((int)($_GET['cursor']??0),(int)($_GET['limit']??250));$bmwfDelta['collector']=$bmwfCollector;
        echo json_encode($bmwfDelta,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;
    }
    if($tab==='webfilter_status'&&($_GET['ajax']??'')==='workers'){
        while(ob_get_level()>0)ob_end_clean();header_remove('Content-Type');header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');
        echo json_encode(bmwf_http_workers_snapshot(),JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;
    }
    if($tab==='webfilter_status'&&($_GET['ajax']??'')==='operations'){
        while(ob_get_level()>0)ob_end_clean();header_remove('Content-Type');header('Content-Type: application/json; charset=UTF-8');header('Cache-Control: no-store');
        $bmwfOps=bmwf_ops_call('status');echo json_encode($bmwfOps['data']??['ok'=>false,'message'=>$bmwfOps['msg']],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE);exit;
    }
    if(($_SERVER['REQUEST_METHOD']??'GET')!=='POST')return;
    $action=(string)($_POST['action']??'');$actor=bmwf_actor();$r=['ok'=>false,'msg'=>'Ação Web Filter inválida.'];
    try{
        if($action==='bmwf_save_settings')$r=bmwf_save_settings($_POST,$actor);
        elseif($action==='bmwf_save_http_workers_proposal')$r=bmwf_save_http_workers_proposal($_POST,$actor);
        elseif($action==='bmwf_save_policy')$r=bmwf_save_policy($_POST,$actor);
        elseif($action==='bmwf_save_apply_policy'){
            $bmwfApplyGroup=trim((string)($_POST['group']??''));$bmwfApplyFile=bmwf_policy_file($bmwfApplyGroup);$bmwfHadPolicy=is_file($bmwfApplyFile);$bmwfBeforePolicy=$bmwfHadPolicy?bmwf_json_read($bmwfApplyFile,[]):[];$r=bmwf_save_policy($_POST,$actor);
            if($r['ok']){$bmwfApply=bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-service.php',['apply']);if(empty($bmwfApply['ok'])){if($bmwfHadPolicy)bmwf_atomic_json($bmwfApplyFile,$bmwfBeforePolicy);else@unlink($bmwfApplyFile);$bmwfRestore=bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-service.php',['apply']);bmwf_audit('POLICY_APPLY_ROLLBACK',['group'=>$bmwfApplyGroup,'actor'=>$actor,'apply_error'=>$bmwfApply['output']??'','restore_ok'=>!empty($bmwfRestore['ok'])]);$r=['ok'=>false,'msg'=>'Falha ao aplicar; a política anterior foi restaurada'.(!empty($bmwfRestore['ok'])?' e reaplicada.':'. Verifique o serviço antes de liberar tráfego.').' Detalhe: '.(string)($bmwfApply['output']??'erro desconhecido')];}else{$r=['ok'=>true,'msg'=>'Política salva, catálogo recompilado, configuração validada e aplicada.'];}}
        }
        elseif($action==='bmwf_save_lists')$r=bmwf_save_local_lists($_POST,$actor);
        elseif($action==='bmwf_save_source')$r=bmwf_save_source($_POST,$actor);
        elseif($action==='bmwf_delete_source')$r=bmwf_delete_source((string)($_POST['source_id']??''),$actor);
        elseif($action==='bmwf_download_source')$r=bmwf_fetch_source((string)($_POST['source_id']??''),false);
        elseif($action==='bmwf_apply_source')$r=bmwf_apply_source((string)($_POST['source_id']??''));
        elseif($action==='bmwf_download_apply_source')$r=bmwf_fetch_source((string)($_POST['source_id']??''),true);
        elseif($action==='bmwf_sync_identities'){
            $x=bmwf_run_cli('/usr/local/sbin/blockmanager-identity-catalog-worker.php');
            $r=!empty($x['ok'])?bmwf_result(bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-worker.php',['--sync-identities'])):bmwf_result($x);
        }
        elseif($action==='bmwf_collect_logs')$r=bmwf_result(bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-worker.php',['--collect-logs']));
        elseif($action==='bmwf_compile')$r=bmwf_result(bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-worker.php',['--compile']));
        elseif($action==='bmwf_ops_refresh')$r=bmwf_ops_call('refresh');
        elseif($action==='bmwf_ops_preflight')$r=bmwf_ops_call('preflight');
        elseif($action==='bmwf_ops_prepare_root')$r=bmwf_ops_call('prepare-root');
        elseif($action==='bmwf_ops_start')$r=bmwf_ops_call('start');
        elseif($action==='bmwf_ops_stop')$r=bmwf_ops_call('stop');
        elseif($action==='bmwf_ops_restart')$r=bmwf_ops_call('restart');
        elseif($action==='bmwf_ops_activate')$r=bmwf_ops_call('activate');
        elseif($action==='bmwf_ops_deactivate')$r=bmwf_ops_call('deactivate');
        elseif($action==='bmwf_ops_emergency')$r=bmwf_ops_call('emergency');
        elseif($action==='bmwf_ops_watchdog')$r=bmwf_ops_call('watchdog');
        elseif(in_array($action,['bmwf_service_test','bmwf_service_start','bmwf_service_stop','bmwf_service_reload','bmwf_service_activate','bmwf_service_deactivate','bmwf_service_apply'],true)){
            $serviceAction=['bmwf_service_test'=>'test','bmwf_service_start'=>'start','bmwf_service_stop'=>'stop','bmwf_service_reload'=>'reload','bmwf_service_activate'=>'activate','bmwf_service_deactivate'=>'deactivate','bmwf_service_apply'=>'apply'][$action];
            $r=bmwf_result(bmwf_run_cli('/usr/local/sbin/blockmanager-webfilter-service.php',[$serviceAction]));
        }
    }catch(Throwable $e){$r=['ok'=>false,'msg'=>$e->getMessage()];}
    $message=$r['msg'];$message_type=$r['ok']?'success':'error';
}
