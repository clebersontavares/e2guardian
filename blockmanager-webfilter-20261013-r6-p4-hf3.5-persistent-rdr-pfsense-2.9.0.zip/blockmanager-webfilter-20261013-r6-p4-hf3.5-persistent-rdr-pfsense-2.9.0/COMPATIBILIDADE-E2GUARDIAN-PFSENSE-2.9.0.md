# Compatibilidade E2Guardian — pfSense CE 2.9.0

## Contrato operacional

- Backend exclusivo: `/usr/local/sbin/e2guardian`.
- HTTP: `filterports = 8080`.
- HTTPS transparente: `transparenthttpsport = 8443` quando o perfil HTTPS está ativo.
- A diretiva HTTPS é omitida quando HTTPS está desligado.
- PID do motor: `/var/run/blockmanager-webfilter/e2guardian.pid`.
- PID do supervisor: `/var/run/blockmanager-webfilter/e2guardian-daemon.pid`.
- Acesso direto; `proxyip` e `proxyport` são removidos da configuração gerada.
- Instalações com portas legadas 3128/3129 são migradas para 8080/8443. Outras portas válidas são preservadas.
- Redirecionamento somente por ação explícita na WebGUI.
- Fail-open remove o anchor se motor ou listeners esperados estiverem inativos.
