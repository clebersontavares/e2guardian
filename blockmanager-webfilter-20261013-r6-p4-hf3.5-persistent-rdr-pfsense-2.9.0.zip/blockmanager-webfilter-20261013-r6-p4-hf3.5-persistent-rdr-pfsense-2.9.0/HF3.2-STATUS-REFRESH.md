# r6-p4-hf3.2 — Verificar Status

O indicador visual `PENDÊNCIAS` permanece somente como badge. Ao lado há um botão ativo **Verificar agora**, enviado por POST com CSRF para a ação `bmwf_ops_refresh`.

A ação:

1. atualiza dependências, interface, CA, bypass e blacklists;
2. lê PID, supervisor e listeners;
3. consulta o anchor real com `pfctl -a blockmanager_webfilter -sn`;
4. executa fail-open se o anchor estiver ativo sem motor/listeners;
5. consulta novamente o anchor depois do fail-open;
6. mostra anchor e redirecionamento finais na mensagem e nos cartões;
7. mostra pendências acionáveis e link para Configuração.

Para o estado observado, o diagnóstico orienta selecionar uma interface interna e, com SNI ativo, selecionar uma CA do pfSense, informar arquivos legíveis ou desligar HTTPS. Bypass sem erros e ausência de fontes de blacklist permanecem válidos.

A verificação nunca ativa redirecionamento.
