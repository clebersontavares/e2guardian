#!/bin/sh
set -eu

ROOT=/
PREFLIGHT=0
WEBGUI_URL=
WEBGUI_PATH=
WEBGUI_PATH_SET=0
COOKIE_FILE=
COOKIE=
INSECURE=0
REQUIRE_CATALOG=0
REQUIRE_ENGINE=0

usage() {
    echo "Uso: $0 [--root DIR] [--preflight] [--require-catalog] [--require-engine] [--webgui-url URL [--webgui-path CAMINHO] (--cookie-file ARQ|--cookie COOKIE) [--insecure]]" >&2
}

while [ $# -gt 0 ]; do
    case "$1" in
        --root) ROOT=$2; shift 2 ;;
        --preflight) PREFLIGHT=1; shift ;;
        --webgui-url) WEBGUI_URL=$2; shift 2 ;;
        --webgui-path) WEBGUI_PATH=$2; WEBGUI_PATH_SET=1; shift 2 ;;
        --cookie-file) COOKIE_FILE=$2; shift 2 ;;
        --cookie) COOKIE=$2; shift 2 ;;
        --insecure) INSECURE=1; shift ;;
        --require-catalog) REQUIRE_CATALOG=1; shift ;;
        --require-engine) REQUIRE_ENGINE=1; shift ;;
        *) usage; exit 64 ;;
    esac
done

ROOT=${ROOT%/}
[ -n "$ROOT" ] || ROOT=/
SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
errors=0

ok() { echo "OK: $*"; }
fail() { echo "ERRO: $*" >&2; errors=$((errors+1)); }
sha_cmd() {
    if command -v sha256 >/dev/null 2>&1; then sha256 -q "$1"; else sha256sum "$1" | awk '{print $1}'; fi
}

if [ "$PREFLIGHT" -eq 1 ]; then
    OUT=${TMPDIR:-/tmp}/blockmanager-webfilter-preflight-$(date +%Y%m%d-%H%M%S).txt
    {
        echo "captured_at=$(date '+%Y-%m-%dT%H:%M:%S%z')"
        for f in \
            "$ROOT/usr/local/www/block_manager.php" \
            "$ROOT/usr/local/www/dnsmanager/templates/sidebar.php" \
            "$ROOT/var/unbound/lists/settings.json" \
            "$ROOT/var/unbound/lists/group-connectors.json"
        do
            [ -f "$f" ] && echo "$(sha_cmd "$f")  ${f#$ROOT/}"
        done
    } >"$OUT"
    echo "$OUT"
    exit 0
fi

[ ! -f "$ROOT/etc/version" ] || case "$(sed -n '1p' "$ROOT/etc/version")" in
    2.9.0*) ok "pfSense 2.9.0" ;;
    *) fail "versão alvo não é 2.9.0" ;;
esac

REQ="usr/local/www/dnsmanager/includes/webfilter.php usr/local/www/dnsmanager/pages/webfilter.php usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php usr/local/sbin/blockmanager-identity-catalog-worker.php usr/local/sbin/blockmanager-webfilter-worker.php usr/local/sbin/blockmanager-webfilter-engine.php usr/local/sbin/blockmanager-webfilter-traffic.php usr/local/sbin/blockmanager-webfilter-service.php usr/local/sbin/blockmanager-webfilter-watchdog.php usr/local/sbin/blockmanager-webfilter-webgui-ops.php usr/local/sbin/blockmanager-webfilter-pf-root.php usr/local/etc/rc.d/blockmanager_webfilter usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json usr/local/etc/blockmanager/webfilter/policies/blockmanager-webfilter-policy.schema.json usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.schema.json usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.example.json usr/local/etc/blockmanager/webfilter/lists/blockmanager-webfilter-https-inspection-exceptions.schema.json usr/local/etc/blockmanager/webfilter/lists/https-inspection-exceptions.example.json usr/local/etc/blockmanager/webfilter/sources/blockmanager-webfilter-source.schema.json usr/local/etc/blockmanager/webfilter/categories/blockmanager-webfilter-category-catalog.schema.json usr/local/share/blockmanager/webfilter/dependency-lock.json"
for r in $REQ; do
    [ -f "$ROOT/$r" ] && ok "$r" || fail "ausente: $r"
done

ENGINE_CTL="$ROOT/usr/local/sbin/blockmanager-webfilter-engine.php"
if [ -f "$ENGINE_CTL" ]; then
    grep -Fq "'e2guardian'" "$ENGINE_CTL" && ok "driver E2Guardian presente" || fail "driver E2Guardian ausente"
    grep -Fq "transparenthttpsport" "$ENGINE_CTL" && ok "tratamento HTTPS E2Guardian presente" || fail "tratamento HTTPS E2Guardian ausente"
    grep -Fq "'logfileformat','6'" "$ENGINE_CTL" && grep -Fq "'loglocation'" "$ENGINE_CTL" && ok "access.log E2Guardian formato 6 configurado" || fail "configuração do monitor E2Guardian ausente"
    grep -Fq "'dstatlocation'" "$ENGINE_CTL" && grep -Fq "'dstatinterval'" "$ENGINE_CTL" && ok "dstats de HTTP Workers configurado" || fail "monitor de HTTP Workers sem dstats"
    ! grep -Fq "bmwf_engine_set_directive(\$main,'httpworkers'" "$ENGINE_CTL" && ! grep -Fq "bmwf_engine_set_directive(\$main,'maxchildren'" "$ENGINE_CTL" && ok "capacidade de workers não é ajustada automaticamente" || fail "ajuste automático de HTTP Workers detectado"
    ! grep -Eiq 'squid' "$ROOT/usr/local/sbin/blockmanager-webfilter-engine.php" "$ROOT/usr/local/sbin/blockmanager-webfilter-webgui-ops.php" "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json" && ok "runtime exclusivo E2Guardian" || fail "referência operacional a backend alternativo encontrada"
    grep -Fq '"http_port": 8080' "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" && grep -Fq '"https_port": 8443' "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" && ok "portas E2Guardian 8080/8443" || fail "defaults de porta E2Guardian inválidos"
    grep -Fq '"scope": "production-all-compiled-networks"' "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" && ! grep -Eq '"pilot_(group|networks)"' "$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json" && ok "escopo de produção sem teste controlado" || fail "seletores piloto ainda presentes"
fi
FILTER_INC="$ROOT/etc/inc/filter.inc"
if [ -f "$FILTER_INC" ]; then
    [ "$(grep -c 'BLOCKMANAGER_WEBFILTER_RDR_ANCHOR_BEGIN' "$FILTER_INC")" -eq 1 ] && grep -Fq 'rdr-anchor \"blockmanager_webfilter\"' "$FILTER_INC" && ok "rdr-anchor raiz persistente e idempotente" || fail "rdr-anchor raiz persistente ausente ou duplicado"
else
    fail "filter.inc ausente"
fi
if [ "$REQUIRE_ENGINE" -eq 1 ]; then
    if [ "$ROOT" != / ]; then fail "--require-engine exige --root /";
    elif "$SELF_DIR/blockmanager-webfilter-engine-setup.sh" --check >/tmp/bmwf-engine-check.$$ 2>&1; then ok "E2Guardian e dependências nativas validados";
    else fail "E2Guardian/dependências inválidos: $(tail -n 5 /tmp/bmwf-engine-check.$$ | tr '\n' ' ')"; fi
    rm -f /tmp/bmwf-engine-check.$$
fi

[ ! -e "$ROOT/usr/local/www/blockmanager_web_filter.php" ] && ok "rota standalone ausente" || fail "rota standalone legada ainda existe"

PAGE="$ROOT/usr/local/www/dnsmanager/pages/webfilter.php"
if [ -f "$PAGE" ]; then
    grep -Fq 'data-bmwf-integrated="1"' "$PAGE" && ok "página integrada encontrada" || fail "marcador integrado ausente"
    if grep -Eiq '<!doctype|<html|<head|<body|<style|guiconfig\.inc|auth\.inc' "$PAGE"; then
        fail "página contém bootstrap/layout/CSS standalone"
    else
        ok "página reutiliza bootstrap, layout e CSS do Block Manager"
    fi
    grep -Fq "function bmwf_render_page_fragment" "$PAGE" && \
        ok "fragmento renderizado em escopo isolado" || fail "fragmento ainda executa no escopo global do pfSense"
    grep -Fq 'bmwfLogSearch' "$PAGE" && grep -Fq 'bmwfPause' "$PAGE" && grep -Fq 'bmwfExportCsv' "$PAGE" && \
        ok "controles do monitor de logs presentes" || fail "monitor de logs WebGUI incompleto"
    grep -Fq 'bmwfWorkersConfigured' "$PAGE" && grep -Fq 'bmwfWorkersBusy' "$PAGE" && grep -Fq 'bmwfWorkersQueue' "$PAGE" && \
        ok "WebGUI exibe workers configurados, Busy e httpwQ" || fail "monitor de HTTP Workers incompleto"
    grep -Fq 'Inspeção profunda com descriptografia — etapa posterior' "$PAGE" && grep -Fq 'option value="decrypt" disabled' "$PAGE" && \
        ok "inspeção profunda HTTPS visível somente como etapa posterior" || fail "WebGUI permite inspeção profunda nesta revisão"
    grep -Fq 'Lista branca' "$PAGE" && grep -Fq 'Permitir selecionadas' "$PAGE" && grep -Fq 'Negar selecionadas' "$PAGE" && grep -Fq 'Salvar e aplicar' "$PAGE" && \
        ok "modos de categoria e Salvar e aplicar presentes" || fail "frontend de categorias incompleto"
    if grep -Eq '\$g([^[:alnum:]_]|$)' "$PAGE"; then
        fail "variável reservada \$g ainda aparece no fragmento integrado"
    else
        ok "variável global reservada \$g não é sobrescrita"
    fi
fi

PATCHER="$SELF_DIR/tools/blockmanager-webfilter-patch-ui.php"
if [ "$ROOT" = / ] && [ -x /usr/local/bin/php ]; then
    /usr/local/bin/php -q "$PATCHER" --root "$ROOT" --check || errors=$((errors+1))
elif command -v python3 >/dev/null 2>&1; then
    python3 "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.py" --root "$ROOT" --check || errors=$((errors+1))
else
    fail "PHP/Python indisponível para validar sidebar/roteador"
fi

MAIN="$ROOT/usr/local/www/block_manager.php"
if [ -f "$MAIN" ]; then
    grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->' "$MAIN" && \
    grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->' "$MAIN" && \
        ok "marcadores de página HTML invisíveis" || fail "marcadores HTML da página ausentes"
    if grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */' "$MAIN" || \
       grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_END */' "$MAIN"; then
        fail "marcadores de página legados visíveis ainda presentes"
    fi
fi

for r in \
    usr/local/www/dnsmanager/includes/webfilter.php \
    usr/local/www/dnsmanager/pages/webfilter.php \
    usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php \
    usr/local/sbin/blockmanager-webfilter-worker.php \
    usr/local/sbin/blockmanager-webfilter-service.php \
    usr/local/sbin/blockmanager-webfilter-webgui-ops.php
do
    f="$ROOT/$r"
    [ -f "$f" ] || continue
    if grep -Eiq 'unbound-(control|checkconf)|dnsmanager-worker\.php|resolver\.log|/var/log/dnsfilter|/var/unbound/lists/(categories|category|auto-categor|groups/|blocked_ips|groups_central|worker)' "$f"; then
        fail "dependência operacional do Unbound em $r"
    fi
done

SET="$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json"
if [ -f "$SET" ]; then
    grep -Eq '"enabled"[[:space:]]*:[[:space:]]*false' "$SET" && ok "desabilitado por padrão" || echo "AVISO: configuração existente está habilitada"
fi
HTTPS_EXAMPLE="$ROOT/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
if [ -f "$HTTPS_EXAMPLE" ]; then
    grep -Fq '"implementation_state": "reserved"' "$HTTPS_EXAMPLE" && \
    grep -Fq '"activation_gate": "future-validated-release"' "$HTTPS_EXAMPLE" && \
    grep -Fq '"default_action": "bypass"' "$HTTPS_EXAMPLE" && \
        ok "arquitetura HTTPS futura reservada e fail-safe" || fail "defaults HTTPS futuros não estão reservados"
    grep -Fq '"management_mode": "proposal-only"' "$HTTPS_EXAMPLE" && \
    grep -Fq '"auto_adjust": false' "$HTTPS_EXAMPLE" && \
    grep -Fq '"override_enabled": false' "$HTTPS_EXAMPLE" && \
        ok "HTTP Workers usam gestão conservadora sem ajuste automático" || fail "defaults de HTTP Workers não são conservadores"
fi

LIB="$ROOT/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
if [ -f "$LIB" ]; then
    for field in timestamp ip identity group method domain url category action reason https_profile response_code bytes duration_ms source; do
        grep -Fq "'$field'" "$LIB" || fail "campo normalizado ausente: $field"
    done
    if grep -Fq 'BMWF_CURSOR_DIR' "$LIB" && grep -Fq 'max_lines_per_run' "$LIB"; then
        ok "coleta incremental limitada por cursor"
    else
        fail "coleta incremental incompleta"
    fi
    grep -Fq 'bmwf_normalize_e2guardian_event' "$LIB" && grep -Fq 'bmwf_collect_logs_throttled' "$LIB" && \
        ok "parser E2Guardian e coleta ao vivo protegida" || fail "implementação do monitor de logs incompleta"
    grep -Fq 'function bmwf_http_workers_snapshot' "$LIB" && grep -Fq 'function bmwf_save_http_workers_proposal' "$LIB" && \
        ok "monitor de HTTP Workers e gestão proposal-only presentes" || fail "gestão de HTTP Workers incompleta"
    grep -Fq 'function bmwf_https_inspection_gate' "$LIB" && grep -Fq "'implementation_state' => 'reserved'" "$LIB" && \
        ok "gate da inspeção HTTPS futura está reservado" || fail "gate da inspeção HTTPS futura ausente"
    grep -Fq 'webfilter-external-categories-v1' "$LIB" && grep -Fq "'dns_category_reuse'=>false" "$LIB" && grep -Fq 'function bmwf_category_domain_plan' "$LIB" && \
        ok "catálogo próprio de categorias e planos por grupo presentes" || fail "catálogo próprio de categorias incompleto"
    if grep -Fq 'last valid' "$LIB" 2>/dev/null || grep -Fq 'lista ativa anterior mantida' "$LIB"; then
        ok "falha preserva lista válida"
    else
        fail "fallback da última lista válida não identificado"
    fi
fi

PHP_BIN=
[ "$ROOT" = / ] && [ -x /usr/local/bin/php ] && PHP_BIN=/usr/local/bin/php
[ -z "$PHP_BIN" ] && command -v php >/dev/null 2>&1 && PHP_BIN=$(command -v php)
if [ -n "$PHP_BIN" ]; then
    if [ "$ROOT" = / ]; then
        PHP_VERSION_ID=$($PHP_BIN -r 'echo PHP_VERSION_ID;' 2>/dev/null || echo 0)
        [ "$PHP_VERSION_ID" -ge 80500 ] && ok "PHP 8.5+" || fail "pfSense 2.9.0 requer validação com PHP 8.5+"
    fi
    # Lista fechada: nunca varrer /usr/local/sbin ou outros diretórios globais do
    # firewall, pois pacotes externos podem conter código que não pertence a esta r6.
    PHP_INSTALLED_REL="
usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php
usr/local/www/dnsmanager/includes/webfilter.php
usr/local/www/dnsmanager/pages/webfilter.php
usr/local/sbin/blockmanager-identity-catalog-worker.php
usr/local/sbin/blockmanager-webfilter-worker.php
usr/local/sbin/blockmanager-webfilter-engine.php
usr/local/sbin/blockmanager-webfilter-traffic.php
usr/local/sbin/blockmanager-webfilter-service.php
usr/local/sbin/blockmanager-webfilter-watchdog.php
usr/local/sbin/blockmanager-webfilter-webgui-ops.php
"
    set --
    for rel in $PHP_INSTALLED_REL; do
        f="$ROOT/$rel"
        [ -f "$f" ] && set -- "$@" "$f"
    done
    for f in \
        "$SELF_DIR/tools/blockmanager-webfilter-migrate.php" \
        "$SELF_DIR/tools/blockmanager-webfilter-patch-ui.php" \
        "$SELF_DIR/tools/blockmanager-webfilter-validate-catalog.php"
    do
        [ -f "$f" ] && set -- "$@" "$f"
    done
    lint_failed=0
    for f in "$@"; do
        "$PHP_BIN" -l "$f" >/dev/null || lint_failed=1
    done
    [ "$lint_failed" -eq 0 ] && ok "sintaxe PHP nos arquivos do pacote" || fail "sintaxe PHP inválida no pacote"
    if "$PHP_BIN" -q "$SELF_DIR/tests/blockmanager-webfilter-category-catalog-test.php" >/tmp/bmwf-category-test.$$ 2>&1; then
        ok "catálogo externo isolado e quatro modos por grupo validados em PHP"
    else
        fail "teste PHP do catálogo de categorias falhou: $(tail -n 5 /tmp/bmwf-category-test.$$ | tr '\n' ' ')"
    fi
    rm -f /tmp/bmwf-category-test.$$

    PHP85_AUDITOR="$SELF_DIR/tools/blockmanager-webfilter-php85-audit.php"
    if [ ! -f "$PHP85_AUDITOR" ]; then
        fail "auditor PHP 8.5 do pacote ausente"
    elif "$PHP_BIN" -q "$PHP85_AUDITOR" "$@" >/dev/null; then
        ok "sem construções realmente depreciadas do PHP 8.5 no payload"
    else
        fail "construção realmente depreciada no PHP 8.5 encontrada no payload"
    fi
    CATALOG="$ROOT/var/db/blockmanager/shared/blockmanager-identity-catalog.json"
    if [ "$REQUIRE_CATALOG" -eq 1 ] && [ -f "$CATALOG" ]; then
        "$PHP_BIN" -q "$SELF_DIR/tools/blockmanager-webfilter-validate-catalog.php" --file "$CATALOG" >/tmp/bmwf-catalog-validation.$$ || errors=$((errors+1))
        if [ -s /tmp/bmwf-catalog-validation.$$ ]; then
            counts=$(tr -d '\n' </tmp/bmwf-catalog-validation.$$)
            ok "catálogo e counts validados: $counts"
        fi
        rm -f /tmp/bmwf-catalog-validation.$$
    elif [ "$REQUIRE_CATALOG" -eq 1 ]; then
        fail "catálogo compartilhado ausente; execute Atualizar catálogo antes da ativação"
    else
        echo "AVISO: validação de conteúdo/counts do catálogo não exigida; use --require-catalog após Atualizar catálogo"
    fi
    grep -Fq "BMWF_STATUS_FILE', BMWF_STATE_DIR . '/status.json'" "$ROOT/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php" && \
        ok "worker e WebGUI usam /var/db/blockmanager/webfilter/status.json" || fail "caminho de status não alinhado"
else
    echo "AVISO: PHP CLI ausente; lint deve ser repetido no pfSense."
fi

if [ "$WEBGUI_PATH_SET" -eq 1 ] && [ -z "$WEBGUI_URL" ]; then
    fail "--webgui-path exige --webgui-url"
fi

if [ -n "$WEBGUI_URL" ]; then
    if [ -z "$COOKIE_FILE" ] && [ -z "$COOKIE" ]; then
        fail "informe cookie autenticado"
    elif ! command -v curl >/dev/null 2>&1; then
        fail "curl ausente"
    else
        if [ "$WEBGUI_PATH_SET" -eq 1 ]; then
            case "$WEBGUI_PATH" in
                /*) WEBGUI_ENTRYPOINT="${WEBGUI_URL%/}${WEBGUI_PATH}" ;;
                *) WEBGUI_ENTRYPOINT="${WEBGUI_URL%/}/$WEBGUI_PATH" ;;
            esac
        else
            case "$WEBGUI_URL" in
                *block_manager.php*) WEBGUI_ENTRYPOINT="$WEBGUI_URL" ;;
                *) WEBGUI_ENTRYPOINT="${WEBGUI_URL%/}/block_manager.php" ;;
            esac
        fi
        WEBGUI_ENTRYPOINT=${WEBGUI_ENTRYPOINT%%\?*}
        TMPW=${TMPDIR:-/tmp}/bmwf-web.$$
        mkdir -p "$TMPW"
        for route in webfilter webfilter_policies webfilter_lists webfilter_sources webfilter_logs webfilter_status webfilter_settings; do
            PAGE_URL="${WEBGUI_ENTRYPOINT}?tab=${route}"
            : >"$TMPW/body.$route"
            : >"$TMPW/error.$route"
            set -- -sS -L --max-redirs 3 --connect-timeout 10 --max-time 30 -o "$TMPW/body.$route" -w '%{http_code}'
            [ "$INSECURE" -eq 1 ] && set -- "$@" -k
            [ -n "$COOKIE_FILE" ] && set -- "$@" --cookie "$COOKIE_FILE"
            [ -n "$COOKIE" ] && set -- "$@" --cookie "$COOKIE"

            curl_rc=0
            if code=$(curl "$@" "$PAGE_URL" 2>"$TMPW/error.$route"); then :; else curl_rc=$?; fi
            if [ "$curl_rc" -ne 0 ]; then
                detail=$(cat "$TMPW/error.$route"); [ -n "$detail" ] || detail="sem detalhe adicional"
                fail "falha de conexão WebGUI (curl $curl_rc, HTTP ${code:-000}) em $PAGE_URL: $detail"
                continue
            fi
            if [ "$code" != 200 ]; then
                detail=$(cat "$TMPW/error.$route"); [ -n "$detail" ] || detail="resposta recebida sem erro de transporte"
                fail "HTTP $code em $PAGE_URL: $detail"
                continue
            fi
            if [ ! -s "$TMPW/body.$route" ]; then
                fail "HTTP 200 com corpo vazio em $PAGE_URL"
                continue
            fi
            ok "HTTP 200 na rota $route"
            grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->' "$TMPW/body.$route" && \
            grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->' "$TMPW/body.$route" || fail "marcadores HTML ausentes na rota $route"
            grep -Fq "data-bmwf-route=\"$route\"" "$TMPW/body.$route" || fail "conteúdo da rota $route não foi renderizado"
            if grep -Eiq 'Fatal error|Uncaught TypeError|csrf-magic\.php' "$TMPW/body.$route"; then
                fail "erro PHP/CSRF na rota $route"
            else
                ok "rota $route sem erro PHP/CSRF"
            fi
        done
        rm -rf "$TMPW"
    fi
fi

[ "$errors" -eq 0 ] || exit 1
ok "r6-p4-categories para pfSense 2.9.0 integrada, isolada e validada"
