# Block Manager Web Filter — política por categoria (v4)

Atualização baseada nos cinco arquivos fornecidos. `policies.php` e `categories.php` foram usados como referência funcional do padrão do DNS Filter e permanecem inalterados em `reference-dns-filter/`.

## Arquivos alterados

- `usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php`
- `usr/local/sbin/blockmanager-webfilter-engine.php`
- `usr/local/www/dnsmanager/pages/webfilter.php`

## Comportamento implementado

- Política v4 com decisão exclusiva por categoria: `default`, `whitelist`, `allow` ou `deny`.
- Migração em leitura das políticas legadas v1–v3, preservando a semântica anterior.
- Fontes ativas vinculadas automaticamente pelo backend; a tela não solicita seleção de fonte nem referência estável.
- ID de novas fontes derivado da URL canônica; IDs legados são preservados quando a URL já existe.
- Aplicação de fonte sincroniza todas as políticas de grupo e inclui categorias novas em `default`.
- Múltiplas fontes/categorias e deduplicação de domínios com precedência: whitelist > deny > allow > default.
- Catálogo próprio `webfilter-only`, sem reutilização de categorias do DNS Filter.
- Listas E2Guardian separadas para bloqueio, whitelist e allow, com lista efetiva deduplicada.
- Geração E2Guardian em diretório de staging, validação, manifestos SHA-256, backup, promoção por rename e rollback.
- Aplicação de fonte com lock, backup transacional de active/catalog/policies/source, validação de hash e rollback.
- A tela de políticas oferece pesquisa, decisão por rádio, seleção em massa por coluna, `Limpar todos` e `Salvar e aplicar`.

## Instalação

Faça backup dos três destinos antes de copiar. Em seguida, preserve proprietário e permissões do pacote atual:

```sh
cp usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php /usr/local/www/blockmanager-webfilter/
cp usr/local/sbin/blockmanager-webfilter-engine.php /usr/local/sbin/
cp usr/local/www/dnsmanager/pages/webfilter.php /usr/local/www/dnsmanager/pages/
chmod 0755 /usr/local/sbin/blockmanager-webfilter-engine.php
```

A ação existente `bmwf_save_apply_policy` do controlador integrado é reutilizada; não é necessário alterar PF, NAT, anchor raiz, `filter.inc` ou o worker homologado de identidades.

## Validação no pfSense

```sh
php -l /usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php
php -l /usr/local/sbin/blockmanager-webfilter-engine.php
php -l /usr/local/www/dnsmanager/pages/webfilter.php
php -q tests/blockmanager-webfilter-policy-v4-test.php
```

Depois, execute pela WebGUI o preflight existente (“Compilar, gerar e validar”) antes de “Salvar e aplicar” em produção.
