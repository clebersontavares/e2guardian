<?php
/** Functional regression test for Web Filter per-category policies. */
$root=sys_get_temp_dir().'/bmwf-v4-test-'.getmypid();
putenv('BMWF_ROOT='.$root);
register_shutdown_function(function()use($root){if(is_dir($root))exec('rm -rf '.escapeshellarg($root));});
$library=__DIR__.'/../modified/blockmanager-webfilter-lib.php';
if(!is_file($library))$library=__DIR__.'/../usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php';
require $library;
function need($ok,string $message):void{if(!$ok){fwrite(STDERR,"FAIL: $message\n");exit(1);}}
function active_source(string $id,array $categories):array{
    ksort($categories,SORT_NATURAL|SORT_FLAG_CASE);$count=0;
    foreach($categories as$category=>$domains){$categories[$category]=bmwf_normalize_domains($domains);$count+=count($categories[$category]);}
    return ['version'=>2,'source_id'=>$id,'downloaded_at'=>date(DATE_ATOM),'normalized_sha256'=>hash('sha256',json_encode($categories,JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)),'entry_count'=>$count,'category_count'=>count($categories),'categories'=>$categories];
}
bmwf_ensure_dirs();
bmwf_atomic_json(BMWF_SNAPSHOT_FILE,['version'=>3,'groups'=>['Grupo_A','Grupo_B'],'identities'=>[],'networks'=>[],'sessions'=>[]]);
bmwf_atomic_json(bmwf_source_file('legacy-source'),['version'=>1,'id'=>'legacy-source','name'=>'Fonte Legada','url'=>'https://example.invalid/legacy.json','format'=>'json','schedule'=>'manual','default_category'=>'uncategorized','enabled'=>false]);
$oldActive=active_source('legacy-source',['Social'=>['social.example','shared.example'],'News'=>['news.example','shared.example']]);
bmwf_atomic_json(BMWF_SOURCE_STATE_DIR.'/active/legacy-source.json',$oldActive);
$catalog=bmwf_rebuild_category_catalog();
$refs=[];foreach($catalog['items']as$ref=>$item)$refs[$item['category']]=$ref;
bmwf_atomic_json(bmwf_policy_file('Grupo_A'),['version'=>3,'group'=>'Grupo_A','enabled'=>true,'default_action'=>'allow','source_ids'=>['legacy-source'],'category_mode'=>'whitelist','category_refs'=>[$refs['Social']],'use_local_allow'=>true,'use_local_block'=>true,'use_ssl_exceptions'=>true,'use_log_only'=>true]);
$migrated=bmwf_policy('Grupo_A',$catalog);
need($migrated['version']===4,'policy version migration');
need($migrated['category_states'][$refs['Social']]==='whitelist','legacy selected category preserved');
need($migrated['category_states'][$refs['News']]==='deny','legacy whitelist complement preserved');

$newId=bmwf_source_id_from_url('https://lists.example.invalid/categories.json');
need($newId===bmwf_source_id_from_url('HTTPS://LISTS.EXAMPLE.INVALID/categories.json'),'backend source id is canonical and stable');
bmwf_atomic_json(bmwf_source_file($newId),['version'=>2,'id'=>$newId,'id_strategy'=>'backend-url-sha256','name'=>'Fonte Nova','url'=>'https://lists.example.invalid/categories.json','format'=>'json','schedule'=>'manual','default_category'=>'uncategorized','enabled'=>false]);
$newActive=active_source($newId,['Safe'=>['shared.example','safe.example'],'Games'=>['games.example']]);
bmwf_atomic_json(BMWF_SOURCE_STATE_DIR.'/staging/'.$newId.'.json',$newActive);
$applied=bmwf_apply_source($newId);
need($applied['ok'],'source transaction applies');
$catalog=bmwf_category_catalog();
need($catalog['counts']['sources']===2&&$catalog['counts']['categories']===4,'multiple sources and categories catalogued');
foreach(['Grupo_A','Grupo_B']as$group){$policy=bmwf_json_read(bmwf_policy_file($group),[]);need($policy['version']===4,"$group persisted as v4");foreach($catalog['items']as$ref=>$item)need(isset($policy['category_states'][$ref]),"$group contains every category");}
$policyA=bmwf_policy('Grupo_A',$catalog);$policyB=bmwf_policy('Grupo_B',$catalog);
foreach($catalog['items']as$ref=>$item)if($item['source_id']===$newId)need($policyA['category_states'][$ref]==='default','new source categories default in existing group');
foreach($policyB['category_states']as$state)need($state==='default','new group starts with all categories default');

$refSafe='';$refNews='';foreach($catalog['items']as$ref=>$item){if($item['category']==='Safe')$refSafe=$ref;if($item['category']==='News')$refNews=$ref;}
$policyA['category_states'][$refNews]='deny';$policyA['category_states'][$refSafe]='whitelist';
$compiled=['mode'=>'enforce','global_default'=>['action'=>'allow'],'group_policies'=>['Grupo_A'=>$policyA],'external_sources'=>['legacy-source'=>['categories'=>$oldActive['categories']],$newId=>['categories'=>$newActive['categories']]],'category_catalog'=>$catalog,'local_lists'=>['allow'=>[],'block'=>[]]];
$plan=bmwf_category_domain_plan($compiled,'Grupo_A');
need(in_array('shared.example',$plan['whitelist'],true),'whitelist list generated');
need(in_array('shared.example',$plan['allow'],true),'whitelist wins duplicate-domain conflict');
need(!in_array('shared.example',$plan['block'],true),'whitelist removes duplicate from block list');
need(count(array_keys(array_filter($plan['allow'],fn($d)=>$d==='shared.example')))===1,'domains deduplicated in generated allow list');

$before=hash_file('sha256',BMWF_SOURCE_STATE_DIR.'/active/'.$newId.'.json');$invalid=$newActive;$invalid['normalized_sha256']=str_repeat('0',64);bmwf_atomic_json(BMWF_SOURCE_STATE_DIR.'/staging/'.$newId.'.json',$invalid);$rejected=bmwf_apply_source($newId);need(!$rejected['ok'],'invalid staging rejected');need(hash_file('sha256',BMWF_SOURCE_STATE_DIR.'/active/'.$newId.'.json')===$before,'active source unchanged after validation failure');
need(strpos(file_get_contents($library),'/var/unbound/lists/categories')===false,'DNS category catalog remains isolated');
echo "OK: policy v4 migration, automatic defaults, multi-source catalog, precedence, deduplication and staging validation\n";
