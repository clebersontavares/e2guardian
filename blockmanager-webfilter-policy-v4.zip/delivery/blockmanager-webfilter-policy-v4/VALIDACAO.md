# Relatório de validação

## Executado no ambiente de preparação

- Scanner de delimitadores PHP do pacote atual: **OK** nos três arquivos modificados e no teste funcional.
- Validação estática de escopo: **OK**.
- Comparação de regressão: funções homologadas de catálogo/integração de identidades e `ipgroups` permanecem byte a byte iguais.
- Verificação de ausência de integração nova com `/etc/inc/filter.inc`, `filter_configure`, `config_write`, `system_routing_configure` e `pfctl -f`: **OK**.
- Verificação de que `webfilter.php` mudou somente nos blocos de Políticas e Fontes: **OK**.
- Conferência dos recursos exigidos na UI, backend transacional e geração E2Guardian: **OK**.

## Teste funcional incluído

`tests/blockmanager-webfilter-policy-v4-test.php` cobre:

- migração v3 → v4;
- inclusão automática de novas categorias em Padrão para todos os grupos;
- múltiplas fontes e categorias;
- precedência e deduplicação de domínios;
- rejeição de staging com hash divergente sem alterar a fonte ativa;
- isolamento do catálogo do DNS Filter.

## Limitação do ambiente de preparação

O container de preparação não possui `php-cli`; por isso, o teste funcional e `php -l` não puderam ser executados aqui. O scanner de delimitadores e as validações estáticas passaram. Execute os quatro comandos do README no pfSense antes da implantação.
