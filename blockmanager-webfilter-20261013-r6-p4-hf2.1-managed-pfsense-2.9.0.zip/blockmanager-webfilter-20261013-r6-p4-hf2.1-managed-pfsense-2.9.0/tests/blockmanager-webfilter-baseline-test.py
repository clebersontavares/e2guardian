#!/usr/bin/env python3
"""Reject semantic drift away from the rc6 E2Guardian/pfSense 2.9.0 baseline."""
from pathlib import Path
import json
import re
import sys

base = Path(__file__).resolve().parent.parent
errors = []

def check(condition: bool, message: str) -> None:
    if not condition:
        errors.append(message)

release = json.loads((base / "blockmanager-webfilter-release.json").read_text())
defaults = json.loads((base / "usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json").read_text())
schema = json.loads((base / "usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.schema.json").read_text())
lib = (base / "usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php").read_text()
page = (base / "usr/local/www/dnsmanager/pages/webfilter.php").read_text()
controller = (base / "usr/local/www/dnsmanager/includes/webfilter.php").read_text()
engine = (base / "usr/local/sbin/blockmanager-webfilter-engine.php").read_text()
worker = (base / "usr/local/sbin/blockmanager-webfilter-worker.php").read_text()
service = (base / "usr/local/sbin/blockmanager-webfilter-service.php").read_text()
traffic = (base / "usr/local/sbin/blockmanager-webfilter-traffic.php").read_text()
migrate_py = (base / "tools/blockmanager-webfilter-migrate.py").read_text()
https_policy_schema = json.loads((base / "usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.schema.json").read_text())
https_exception_schema = json.loads((base / "usr/local/etc/blockmanager/webfilter/lists/blockmanager-webfilter-https-inspection-exceptions.schema.json").read_text())

check(release.get("version") == "1.0.0-rc6-p4-hf2.1", "release version must be 1.0.0-rc6-p3")
check(release.get("package_revision") == "r6-p4-hf2.1-managed", "package revision must be r6-p3-e2guardian")
check(release.get("target", {}).get("version") == "2.9.0", "target must remain pfSense 2.9.0")
check(release.get("engine", {}).get("default_driver") == "e2guardian", "release driver must remain e2guardian")
check(release.get("engine", {}).get("http_port") == 8080, "release HTTP port must remain 8080")
check(release.get("engine", {}).get("transparent_https_port") == 8443, "release HTTPS port must remain 8443")

check(defaults.get("version") == 4, "settings version must remain 4")
check(defaults.get("enabled") is False, "settings must stay disabled by default")
check(defaults.get("mode") == "audit", "settings mode must stay audit")
check(defaults.get("activation", {}).get("https_profile") == "off", "HTTPS profile must stay off by default")
check(defaults.get("activation", {}).get("http_port") == 8080, "settings HTTP port must remain 8080")
check(defaults.get("activation", {}).get("https_port") == 8443, "settings HTTPS port must remain 8443")
check(defaults.get("engine", {}).get("driver") == "e2guardian", "settings driver must remain e2guardian")
check(defaults.get("engine", {}).get("binary") == "/usr/local/sbin/e2guardian", "settings binary must remain E2Guardian")
check(defaults.get("engine", {}).get("minimum_version") == "5.3.4", "minimum E2Guardian version must remain 5.3.4")
log_sources = defaults.get("logging", {}).get("sources", [])
check(any(source.get("id") == "e2guardian_access" and source.get("path") == "/var/log/e2guardian/access.log" and source.get("enabled") is True for source in log_sources), "enabled E2Guardian access-log source must remain configured")
check(schema.get("properties", {}).get("version", {}).get("const") == 4, "schema version must remain 4")
check(schema.get("properties", {}).get("activation", {}).get("properties", {}).get("https_profile", {}).get("default") == "off", "schema HTTPS default must remain off")
future = defaults.get("https_inspection", {})
check(future.get("implementation_state") == "reserved", "future HTTPS inspection must remain reserved")
check(future.get("enabled") is False, "future HTTPS inspection must remain disabled")
check(future.get("policy_mode") == "separate" and future.get("default_action") == "bypass", "future HTTPS policies must be separate and default to bypass")
check(future.get("ca", {}).get("provider") == "internal" and future.get("ca", {}).get("key_file_mode") == "0600", "future internal CA contract is incomplete")
check(future.get("validation", {}).get("status") == "not_validated", "future HTTPS validation must not be pre-approved")
https_schema = schema.get("properties", {}).get("https_inspection", {}).get("properties", {})
check(https_schema.get("implementation_state", {}).get("const") == "reserved", "settings schema must lock HTTPS inspection to reserved")
check(https_schema.get("enabled", {}).get("const") is False, "settings schema must lock HTTPS inspection disabled")
check("decrypt" not in schema.get("properties", {}).get("activation", {}).get("properties", {}).get("https_profile", {}).get("enum", []), "current settings schema must not accept decrypt")
check(https_policy_schema.get("properties", {}).get("enabled", {}).get("const") is False and https_policy_schema.get("properties", {}).get("action", {}).get("const") == "bypass", "future HTTPS policy schema must be inert")
check(https_exception_schema.get("properties", {}).get("enabled", {}).get("const") is False, "future HTTPS exception schema must be inert")
workers = defaults.get("http_workers", {})
check(workers.get("management_mode") == "proposal-only", "HTTP Workers management must be proposal-only")
check(workers.get("auto_adjust") is False and workers.get("override_enabled") is False, "HTTP Workers automatic adjustment must remain disabled")
check(workers.get("dstats_file") == "/var/log/e2guardian/dstats.log" and workers.get("dstat_interval_seconds") == 300, "conservative dstats settings are invalid")
check(workers.get("alerts", {}).get("busy_reaches_configured") is True, "Busy limit alert must remain enabled")
check(workers.get("alerts", {}).get("httpwq_consecutive_samples", 0) >= 2, "httpwQ persistence alert must require consecutive samples")
workers_schema = schema.get("properties", {}).get("http_workers", {}).get("properties", {})
check(workers_schema.get("auto_adjust", {}).get("const") is False and workers_schema.get("override_enabled", {}).get("const") is False, "settings schema must forbid automatic worker adjustment")

required_lib = [
    "'version' => 4",
    "'pid_file' => '/var/run/blockmanager-webfilter/e2guardian.pid'",
    "'http_enabled' => true, 'https_profile' => 'off'",
    "'interfaces' => [], 'http_port' => 8080, 'https_port' => 8443",
    "'driver' => 'e2guardian'",
    "'binary' => '/usr/local/sbin/e2guardian'",
    "'minimum_version' => '5.3.4'",
]
for token in required_lib:
    check(token in lib, f"library baseline token missing: {token}")
check("'binary' => '/usr/local/sbin/squid'" not in lib, "Squid must not return as the default library binary")
check("$current['activation']['https_profile']??'off'" in lib, "save-settings HTTPS fallback must stay off")
check("($bmwfSettings['activation']['https_profile']??'off')==='sni'" in page, "WebGUI SNI option fallback must not become implicit SNI")
check("require_once __DIR__ . '/../../blockmanager-webfilter/blockmanager-webfilter-lib.php';" in controller, "controller must load the isolated library")
check("bmwf_collect_logs_throttled(2)" in controller, "live monitor must collect new source events with throttling")
check("bmwf_http_workers_snapshot()" in controller and "bmwf_save_http_workers_proposal" in controller, "HTTP Worker status endpoint or proposal action is missing")
check("'logfileformat','6'" in engine and "'loglocation'" in engine, "E2Guardian format 6 access logging must be generated")
check("['https_profile']??'off'" in worker and "['https_profile']??'sni'" not in worker, "compiled policy HTTPS fallback must stay off")
check("bmwf_normalize_e2guardian_event" in lib, "E2Guardian access-log parser must be present")
check("bmwfExportCsv" in page and "bmwfLogSearch" in page and "bmwfPause" in page, "monitor filters, pause and CSV export must be present")
check("function bmwf_https_inspection_gate" in lib and "etapa posterior" in lib, "runtime gate for future HTTPS inspection must be present")
check("option value=\"decrypt\" disabled" in page, "WebGUI must not allow deep inspection")
check("bmwf_https_inspection_gate($settings)" in engine, "engine must enforce the future HTTPS gate")
check("bmwf_https_inspection_gate($settings)" in service, "service must enforce the future HTTPS gate")
check("bmwf_https_inspection_gate($settings)" in traffic and "['https_profile']??'off'" in traffic, "traffic layer must block decrypt and default HTTPS off")
check("future['enabled'] = False" in migrate_py and "== 'decrypt'" in migrate_py, "migration must disable future HTTPS and convert decrypt to off")
check(not any(path.suffix.lower() in {'.pem','.key','.crt','.p12','.pfx'} for path in base.rglob('*') if path.is_file()), "package must not contain certificate or private-key material")
check("function bmwf_http_workers_snapshot" in lib and "function bmwf_http_workers_parse_dstat" in lib, "HTTP Worker monitor/parser must be present")
check("function bmwf_save_http_workers_proposal" in lib and "Nenhum worker foi alterado" in lib, "proposal-only worker management must be explicit")
check("bmwfWorkersConfigured" in page and "bmwfWorkersBusy" in page and "bmwfWorkersQueue" in page, "WebGUI must show configured workers, Busy and httpwQ")
check("dstatlocation" in engine and "dstatinterval" in engine, "engine must configure conservative dstats monitoring")
check("BMWF_CATEGORY_CATALOG_FILE" in lib and "webfilter-external-categories-v1" in lib, "isolated category catalog is missing")
check("category_mode" in page and "Lista branca" in page and "Salvar e aplicar" in page, "category modes or save/apply UI is missing")
check("bmwf_save_apply_policy" in controller and "POLICY_APPLY_ROLLBACK" in controller, "atomic save/apply rollback is missing")
check("function bmwf_service_apply" in service, "service apply orchestration is missing")
check("/var/unbound/lists/categories" not in lib and "/var/unbound/lists/categories" not in worker, "DNS categories must not be reused")
check("bmwf_engine_set_directive($main,'httpworkers'" not in engine and "bmwf_engine_set_directive($main,'maxchildren'" not in engine, "engine must not adjust worker capacity automatically")
check("workers['auto_adjust'] = False" in migrate_py and "workers['override_enabled'] = False" in migrate_py, "migration must hard-disable automatic worker changes")

if errors:
    for error in errors:
        print(f"ERROR: {error}", file=sys.stderr)
    raise SystemExit(1)
print("OK: E2Guardian baseline, log monitor, reserved HTTPS architecture and conservative HTTP Worker monitoring are coherent")
