#!/bin/sh
set -eu

ACTION=detect
VENDOR_ROOT=
SELF_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
PHP_BIN=/usr/local/bin/php
ENGINE_CTL=/usr/local/sbin/blockmanager-webfilter-engine.php

usage() {
    echo "Uso: $0 [--detect|--check|--verify-bundle|--vendorize DIR|--install-offline|--configure]" >&2
    exit 64
}

while [ $# -gt 0 ]; do
    case "$1" in
        --detect) ACTION=detect; shift ;;
        --check) ACTION=check; shift ;;
        --verify-bundle) ACTION=verify_bundle; shift ;;
        --vendorize) [ $# -ge 2 ] || usage; ACTION=vendorize; VENDOR_ROOT=$2; shift 2 ;;
        --install-offline) ACTION=install_offline; shift ;;
        --configure) ACTION=configure; shift ;;
        *) usage ;;
    esac
done

require_target() {
    version=$(sed -n '1p' /etc/version 2>/dev/null || true)
    case "$version" in 2.9.0*) : ;; *) echo "Exige pfSense 2.9.0; detectado: ${version:-desconhecido}." >&2; exit 65 ;; esac
    os=$(uname -s 2>/dev/null || true)
    major=$(uname -K 2>/dev/null | cut -c1-2 || true)
    [ "$os" = FreeBSD ] || { echo "Exige FreeBSD; detectado: ${os:-desconhecido}." >&2; exit 65; }
    [ -z "$major" ] || [ "$major" -ge 16 ] || { echo "Exige ABI FreeBSD 16 ou superior; detectado: $major." >&2; exit 65; }
}

arch_dir() {
    arch=$(uname -m)
    echo "${1%/}/freebsd-16-$arch"
}

sha_check() {
    dir=$1
    [ -f "$dir/SHA256SUMS" ] || { echo "SHA256SUMS ausente em $dir." >&2; return 1; }
    (cd "$dir" && if command -v sha256 >/dev/null 2>&1; then
        while read -r hash file; do [ -n "$hash" ] || continue; [ "$(sha256 -q "$file")" = "$hash" ] || exit 1; done <SHA256SUMS
    else sha256sum -c SHA256SUMS >/dev/null; fi)
}

verify_bundle() {
    dir=$(arch_dir "${VENDOR_ROOT:-$SELF_DIR/vendor}")
    [ -f "$dir/COMPLETE" ] || { echo "Bundle incompleto: marcador COMPLETE ausente em $dir." >&2; return 1; }
    [ -f "$dir/packages.tsv" ] || { echo "Bundle incompleto: packages.tsv ausente." >&2; return 1; }
    set -- "$dir"/*.pkg
    [ -f "$1" ] || { echo "Bundle incompleto: nenhum .pkg encontrado." >&2; return 1; }
    sha_check "$dir"
    grep -Eq '^e2guardian[[:space:]]' "$dir/packages.tsv" || { echo "Bundle não contém o pacote raiz e2guardian." >&2; return 1; }
    echo "OK: bundle offline íntegro em $dir"
}

check_runtime() {
    require_target
    command -v pkg >/dev/null 2>&1 || { echo "pkg ausente." >&2; return 1; }
    [ -x /usr/local/sbin/e2guardian ] || { echo "E2Guardian ausente em /usr/local/sbin/e2guardian." >&2; return 1; }
    pkg info -e e2guardian || { echo "Registro pkg do E2Guardian ausente." >&2; return 1; }
    pkg check -d e2guardian
    pkg audit -F || { echo "pkg audit encontrou vulnerabilidade ou não pôde concluir." >&2; return 1; }
    if command -v ldd >/dev/null 2>&1; then
        ! ldd /usr/local/sbin/e2guardian 2>&1 | grep -Eiq 'not found|not found required' || { echo "Biblioteca dinâmica ausente." >&2; return 1; }
    fi
    /usr/local/sbin/e2guardian -v
}

case "$ACTION" in
    detect)
        if [ -x /usr/local/sbin/e2guardian ]; then /usr/local/sbin/e2guardian -v; exit 0; fi
        echo "E2Guardian não detectado." >&2; exit 78
        ;;
    check) check_runtime ;;
    verify_bundle) verify_bundle ;;
    vendorize)
        require_target
        [ "$(id -u)" -eq 0 ] || { echo "--vendorize exige root." >&2; exit 77; }
        command -v pkg >/dev/null 2>&1 || { echo "pkg ausente." >&2; exit 69; }
        dir=$(arch_dir "$VENDOR_ROOT"); mkdir -p "$dir"; rm -f "$dir"/*.pkg "$dir/SHA256SUMS" "$dir/packages.tsv" "$dir/COMPLETE"
        pkg fetch -y -d -o "$dir" e2guardian
        set -- "$dir"/*.pkg; [ -f "$1" ] || { echo "Nenhum pacote foi obtido." >&2; exit 69; }
        : >"$dir/packages.tsv"
        for f in "$dir"/*.pkg; do
            name=$(pkg info -F "$f" -q '%n' 2>/dev/null || basename "$f" | sed 's/-[0-9].*$//')
            version=$(pkg info -F "$f" -q '%v' 2>/dev/null || echo unknown)
            abi=$(pkg info -F "$f" -q '%q' 2>/dev/null || echo unknown)
            hash=$(sha256 -q "$f")
            printf '%s\t%s\t%s\t%s\t%s\n' "$name" "$version" "$abi" "$hash" "$(basename "$f")" >>"$dir/packages.tsv"
        done
        (cd "$dir" && for f in *.pkg; do printf '%s  %s\n' "$(sha256 -q "$f")" "$f"; done >SHA256SUMS)
        touch "$dir/COMPLETE"
        verify_bundle
        ;;
    install_offline)
        require_target
        [ "$(id -u)" -eq 0 ] || { echo "--install-offline exige root." >&2; exit 77; }
        verify_bundle
        dir=$(arch_dir "$SELF_DIR/vendor")
        echo "Instalação offline explícita; nenhum serviço ou redirecionamento será ativado."
        pkg add -f "$dir"/*.pkg
        check_runtime
        ;;
    configure)
        require_target
        [ "$(id -u)" -eq 0 ] || { echo "--configure exige root." >&2; exit 77; }
        [ -x "$PHP_BIN" ] || { echo "PHP CLI do pfSense não encontrado." >&2; exit 69; }
        [ -f "$ENGINE_CTL" ] || { echo "Controlador do mecanismo não instalado." >&2; exit 66; }
        check_runtime
        "$PHP_BIN" -q "$ENGINE_CTL" configure e2guardian
        echo "E2Guardian configurado. Web Filter permanece desativado e sem redirecionamento."
        ;;
esac
