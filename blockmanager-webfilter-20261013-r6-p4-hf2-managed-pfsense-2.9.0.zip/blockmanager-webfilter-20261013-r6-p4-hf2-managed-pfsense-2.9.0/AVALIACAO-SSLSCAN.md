# Avaliação do rbsec/sslscan

## Conclusão

`sslscan` é uma **ferramenta opcional de diagnóstico TLS**. Não é biblioteca, motor, proxy, filtro de conteúdo nem dependência do E2Guardian. Não deve entrar no payload, no bundle offline obrigatório ou na cadeia de ativação do WebFilter.

## Onde ajuda

- inventariar versões SSL/TLS e conjuntos de cifras expostos por um endpoint;
- observar certificado apresentado e parâmetros de negociação;
- comparar o WebGUI/TLS antes e depois de uma mudança;
- produzir saída textual/XML como evidência complementar de homologação.

## O que não valida

- sintaxe e inicialização do `e2guardian.conf`;
- políticas, grupos, listas, autenticação, categorias ou conteúdo bloqueado;
- redirecionamento PF e escopo do piloto;
- cadeia completa cliente → PF → E2Guardian → destino;
- confiança da CA nos clientes e geração dinâmica de certificados em todos os navegadores;
- dependências nativas ou ABI do E2Guardian.

O projeto removeu a opção `--http`; portanto, `sslscan` não deve ser tratado como teste de proxy HTTP/CONNECT. Uma conexão direta à porta transparente 8443 também pode não reproduzir o contexto de destino original fornecido pelo PF.

## Uso recomendado

Preferir execução a partir de uma estação de homologação separada. Se instalado no próprio firewall de laboratório, mantê-lo fora do bundle de produção e remover depois dos testes.

```sh
# Endpoint TLS normal, por exemplo o WebGUI
sslscan --no-colour --show-certificate ENDERECO:PORTA

# Evidência em XML
sslscan --no-colour --xml=sslscan-webgui.xml ENDERECO:PORTA
```

Para o fluxo E2Guardian, usar testes de ponta a ponta:

```sh
curl -v -x http://127.0.0.1:8080 https://example.com/ --cacert /CAMINHO/CA.pem
openssl s_client -proxy 127.0.0.1:8080 -connect example.com:443 -CAfile /CAMINHO/CA.pem
```

## Decisão de empacotamento

- **Dependência obrigatória:** não.
- **Bundle offline do motor:** não.
- **Ferramenta opcional de homologação:** sim, externa.
- **Instalação em produção:** não recomendada.

O port FreeBSD consultado informa `sslscan 2.1.3_1`, cerca de 5,67 MiB e zero dependências de pacote; o upstream já publica versão 2.2.3. Essa diferença é mais um motivo para não acoplar a ferramenta ao ciclo de vida do WebFilter.
