# Acesso às fontes Git e artefatos

## Disponível

- Cliente Git local: 2.45.4.
- Repositório público upstream identificado: `https://github.com/e2guardian/e2guardian`.
- Release upstream estável identificada: `v5.5.9r`, commit `e9d50c8852891952c7750aa03fcf086267217a7f`.
- Implementação pública específica para pfSense 2.9 identificada: `https://github.com/bootablearg/pfsense-packages-revived/tree/main/e2guardian`, com baseline inicial do pacote no commit `13d8f68f534e251510389e85c338759a8431bba9`.
- Pacote interno base disponível: `blockmanager-webfilter-hotfix-20261008-r5-p2-pfsense-2.9.0.zip`.

## Não disponível no ambiente de preparação

- Nenhum worktree Git local do WebFilter.
- Nenhuma credencial Git, token GitHub/GitLab, agente SSH ou `known_hosts` configurado.
- `git ls-remote`/clone por HTTPS foi bloqueado com HTTP 403 pela política de rede do sandbox.
- Nenhum pacote FreeBSD `.pkg` do E2Guardian, harfbuzz, talloc ou demais dependências transitivas foi encontrado nos materiais internos.
- Nenhuma instância pfSense 2.9.0/FreeBSD 16-CURRENT para executar `pkg fetch -d`, `pkg check`, `pkg audit`, `ldd` ou teste de tráfego.

## Consequência

O pacote inclui adaptador, instalação offline, manifesto e comandos de vendorization. Ele não declara falsamente que o motor nativo está embutido: `--verify-bundle` falha até que os `.pkg` sejam produzidos no ABI alvo.
