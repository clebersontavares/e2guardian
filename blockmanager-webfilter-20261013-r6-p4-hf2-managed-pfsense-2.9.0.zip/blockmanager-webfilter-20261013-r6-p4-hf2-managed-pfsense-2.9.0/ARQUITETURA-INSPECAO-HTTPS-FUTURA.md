# Arquitetura reservada — inspeção profunda HTTPS

## Escopo desta revisão

A inspeção profunda HTTPS **não faz parte da conclusão atual do WebFilter**. A revisão apenas reserva contratos, caminhos, schemas, travas e critérios de validação para uma implementação posterior. O estado atual é invariavelmente:

- `https_inspection.implementation_state=reserved`;
- `https_inspection.enabled=false`;
- `https_inspection.default_action=bypass`;
- `activation.https_profile=off` por padrão;
- nenhuma CA, chave privada, política de descriptografia ou exceção é instalada ou ativada;
- uma solicitação atual de `https_profile=decrypt` deve falhar antes de gerar configuração, iniciar serviço ou aplicar regra PF.

## Separação de domínios

A inspeção futura não compartilhará políticas com bloqueio HTTP/DNS. Ela terá:

- configuração: `https_inspection` no arquivo protegido de settings;
- políticas: `/usr/local/etc/blockmanager/webfilter/https-policies/`;
- exceções: `/usr/local/etc/blockmanager/webfilter/lists/https-inspection-exceptions.json`;
- evidências: `/var/db/blockmanager/webfilter/https-inspection-validation.json`;
- cache de certificados gerados: diretório próprio, modo `0700`;
- chave privada da CA: arquivo externo à WebGUI, modo obrigatório `0600`;
- logs: somente metadados operacionais; nunca conteúdo descriptografado, chaves ou segredos.

A precedência planejada é independente:

1. exceção obrigatória por domínio, categoria ou aplicação;
2. política explícita de bypass por identidade, grupo ou rede;
3. política explícita de inspeção profunda para piloto validado;
4. padrão global `bypass`.

## Autoridade certificadora interna

A etapa futura exigirá uma CA interna dedicada ao WebFilter, sem reutilizar certificados da WebGUI. Antes da ativação serão obrigatórios:

- certificado e chave correspondentes;
- fingerprint SHA-256 registrada;
- chave privada com modo `0600` e sem exposição na interface;
- distribuição e confiança da CA nos clientes piloto;
- plano de rotação, expiração, revogação e recuperação;
- teste de aplicações com pinning, certificate transparency e mTLS;
- comprovação de que exceções deixam o fluxo passar sem MITM.

Nenhum material criptográfico é incluído neste pacote.

## Gate de ativação futuro

Uma versão posterior somente poderá liberar `decrypt` quando todos os estados abaixo forem verdadeiros:

1. `implementation_state=validated` em um schema de versão posterior;
2. `enabled=true` explicitamente;
3. CA interna validada e fingerprint conferida;
4. política separada habilitada para um escopo piloto não crítico;
5. exceções carregadas e testadas;
6. evidência assinada/registrada em `https-inspection-validation.json`;
7. testes de confiança da CA, exceções, aplicações com pinning, fail-open e rollback aprovados;
8. período piloto mínimo de 24 horas concluído;
9. ativação explícita e reversível do redirecionamento HTTPS.

A revisão atual usa schema com `implementation_state` e `enabled` fixados em `reserved` e `false`; portanto, editar somente o JSON não libera a funcionalidade.

## Validação futura mínima

- lint e runtime no PHP alvo;
- validação estrutural e nativa do E2Guardian;
- navegação HTTP e HTTPS sem inspeção como controle;
- cadeia de confiança em Windows, Linux, macOS, Android e navegadores utilizados;
- bloqueio por política de inspeção separada;
- bypass por domínio, categoria, aplicação, grupo, identidade e rede;
- aplicações com pinning, mTLS, WebSocket, HTTP/2 e HTTP/3/QUIC;
- ausência de segredos em logs, backup, WebGUI e pacote;
- carga, latência, memória e estabilidade;
- fail-open, remoção do anchor PF e rollback completo;
- não regressão do DNS Filter, Unbound, monitor de logs e políticas HTTP atuais.

## Critério de conclusão atual

O WebFilter atual continua concluído com E2Guardian, políticas HTTP, catálogo, monitor de logs e ativação piloto reversível. A arquitetura HTTPS reservada não altera o tráfego, não exige certificado e não amplia o escopo operacional desta entrega.
