# Avaliação do testssl.sh v3.3dev-snapshot-2602

## Conclusão

A snapshot é útil como **ferramenta externa e opcional de homologação TLS**, especialmente por oferecer testes de protocolos, cifras, certificados e vulnerabilidades e por aceitar `--proxy`. Não é dependência do E2Guardian e não deve entrar no payload, no bundle offline do motor ou na cadeia de ativação.

## Release avaliada

- tag: `v3.3dev-snapshot-2602`;
- commit: `cdc892e3234b67c8e921f7c2a1eadcb37d044b8c`;
- publicada em 13 de fevereiro de 2026;
- marcada pelo GitHub como **pre-release**;
- descrita pelo projeto como a primeira snapshot de 3.3dev, considerada madura, mas ainda sujeita a mudanças até a próxima versão estável.

## Utilidade para o WebFilter/E2Guardian

- `--proxy HOST:PORT` permite executar verificações pelo proxy HTTP do E2Guardian;
- cobre mais falhas e avaliações criptográficas que o `sslscan`;
- produz evidências de protocolos, cifras, certificados, vulnerabilidades e classificação;
- pode comparar acesso direto ao destino com acesso pelo piloto.

Limitações do modo proxy documentadas pelo projeto: não suporta autenticação de proxy, proxy HTTPS ou SOCKS; OCSP via proxy é limitado; DNS pelo proxy exige configuração própria.

## Compatibilidade pfSense/FreeBSD

O script exige Bash, utilitários Unix e OpenSSL/LibreSSL auxiliar. O port FreeBSD estável consultado é `testssl.sh 3.2.2`, com dependências `bash` e `openssl-unsafe`. A árvore upstream também fornece `openssl.FreeBSD.amd64` baseado em uma árvore OpenSSL antiga com suporte deliberado a criptografia fraca para testes. Isso é adequado para uma bancada de auditoria, mas aumenta a superfície e não deve ser instalado no firewall de produção.

## Comparação com sslscan

| Aspecto | sslscan | testssl.sh snapshot 2602 |
|---|---|---|
| Papel | Scanner rápido de protocolos/cifras/certificado | Auditor TLS amplo, incluindo vulnerabilidades e avaliações |
| Implementação | Binário C | Script Bash + OpenSSL/LibreSSL auxiliar |
| Proxy HTTP | Opção `--http` removida | `--proxy HOST:PORT` disponível |
| FreeBSD | Port 2.1.3_1, zero dependências de pacote informadas | Port estável 3.2.2, depende de Bash e openssl-unsafe |
| Uso recomendado | Inventário rápido de endpoint TLS | Homologação aprofundada e teste pelo proxy |
| Dependência do E2Guardian | Não | Não |

## Uso recomendado

Executar de uma estação externa de homologação, fixando a tag e registrando o hash:

```sh
./testssl.sh --version
./testssl.sh --warnings batch --color 0 --jsonfile-pretty testssl-direto.json example.com:443
./testssl.sh --warnings batch --color 0 --proxy 127.0.0.1:8080 \
  --jsonfile-pretty testssl-e2guardian.json example.com:443
```

Usar um host controlado para testes e comparar os dois relatórios. Confirmar também bloqueio, exceção, CA, PF anchor e fail-open com navegador/curl; o testssl.sh não substitui esses testes.

## Decisão de empacotamento

- dependência obrigatória: **não**;
- bundle offline do E2Guardian: **não**;
- instalação no firewall de produção: **não recomendada**;
- ferramenta externa de homologação: **sim**;
- inclusão futura: somente em um kit separado de diagnóstico, com versão/hash fixos e justificativa formal.
