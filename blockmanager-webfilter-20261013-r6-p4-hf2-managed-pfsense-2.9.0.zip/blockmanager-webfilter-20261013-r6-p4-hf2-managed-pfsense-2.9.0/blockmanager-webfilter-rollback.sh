#!/bin/sh
set -eu

BACKUP=${1:-}
ROOT=/
shift || true
while [ $# -gt 0 ]; do
    case "$1" in
        --root) ROOT=$2; shift 2 ;;
        *) echo "Opção inválida: $1" >&2; exit 64 ;;
    esac
done

[ -n "$BACKUP" ] && [ -f "$BACKUP/blockmanager-webfilter-install-manifest.tsv" ] || {
    echo "Backup/manifest ausente." >&2
    exit 66
}
ROOT=${ROOT%/}
[ -n "$ROOT" ] || ROOT=/

if [ "$ROOT" = / ] && [ -x /usr/local/bin/php ] && [ -f /usr/local/sbin/blockmanager-webfilter-traffic.php ]; then
    /usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-traffic.php remove >/dev/null 2>&1 || true
fi

while IFS='|' read -r rel existed; do
    [ -n "$rel" ] || continue
    dst="$ROOT/$rel"
    src="$BACKUP/rootfs/$rel"
    if [ "$existed" = 1 ]; then
        [ -e "$src" ] || { echo "Backup ausente: $src" >&2; exit 65; }
        mkdir -p "$(dirname "$dst")"
        tmp="$dst.bmwf-rollback.$$"
        cp -Rp "$src" "$tmp"
        mv -f "$tmp" "$dst"
    else
        rm -rf "$dst"
    fi
done <"$BACKUP/blockmanager-webfilter-install-manifest.tsv"

restore_crontab() {
    state_file="$BACKUP/blockmanager-webfilter-crontab.state"
    before_file="$BACKUP/blockmanager-webfilter-crontab.before"
    state=$(cat "$state_file" 2>/dev/null || echo absent)
    crontab_cmd=${BMWF_CRONTAB_CMD:-crontab}

    case "$state" in
        present)
            if [ ! -f "$before_file" ]; then
                echo "AVISO: backup do crontab ausente; restauração ignorada." >&2
                return 0
            fi
            if ! command -v "$crontab_cmd" >/dev/null 2>&1; then
                echo "AVISO: crontab ausente; restauração ignorada." >&2
                return 0
            fi
            # FreeBSD/pfSense: envie o conteúdo por stdin. Não passe o caminho
            # longo do backup ao crontab, evitando truncamento como '.befo'.
            if ! "$crontab_cmd" - <"$before_file"; then
                echo "AVISO: não foi possível restaurar o crontab anterior." >&2
            fi
            ;;
        empty)
            # Não havia crontab antes da instalação: remova o atual em vez de
            # tentar instalar um arquivo vazio.
            if command -v "$crontab_cmd" >/dev/null 2>&1; then
                "$crontab_cmd" -r >/dev/null 2>&1 || true
            fi
            ;;
        absent)
            :
            ;;
        *)
            echo "AVISO: estado de crontab desconhecido; nenhuma alteração." >&2
            ;;
    esac
}

if [ "$ROOT" = / ] || [ "${BMWF_TEST_CRONTAB_ROLLBACK:-0}" = 1 ]; then
    restore_crontab
fi

for d in \
    "$ROOT/usr/local/etc/blockmanager/webfilter/sources" \
    "$ROOT/usr/local/etc/blockmanager/webfilter/categories" \
    "$ROOT/usr/local/etc/blockmanager/webfilter/lists" \
    "$ROOT/usr/local/etc/blockmanager/webfilter/policies" \
    "$ROOT/usr/local/etc/blockmanager/webfilter" \
    "$ROOT/usr/local/www/blockmanager-webfilter"
do
    rmdir "$d" 2>/dev/null || true
done

echo "Rollback incremental concluído a partir de $BACKUP"
