# Homologação segura — WebFilter r6 E2Guardian

## Pré-condições

1. Usar somente firewall de homologação pfSense CE 2.9.0.
2. Tirar backup do `config.xml` e snapshot da VM/appliance quando disponível.
3. Manter `enabled=false`, `mode=audit`, `fail_open=true` e `https_profile=off`.
4. Não executar em produção enquanto o bundle offline e os testes fim a fim não forem concluídos.

## Sequência

```sh
cat /etc/version
uname -a
/usr/local/bin/php -v
./blockmanager-webfilter-update.sh --dry-run
./blockmanager-webfilter-engine-setup.sh --detect || true
```

Se o motor não estiver instalado:

```sh
./blockmanager-webfilter-engine-setup.sh --vendorize ./vendor
./blockmanager-webfilter-engine-setup.sh --verify-bundle
./blockmanager-webfilter-engine-setup.sh --install-offline
```

Instale o WebFilter e configure o driver:

```sh
./blockmanager-webfilter-update.sh
./blockmanager-webfilter-engine-setup.sh --configure
```

Recrie catálogo, compile políticas e gere configuração sem ativar tráfego:

```sh
/usr/local/bin/php -q /usr/local/sbin/blockmanager-identity-catalog-worker.php
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-worker.php --sync-identities
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-engine.php generate
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-engine.php test
```

Valide dependências e segurança:

```sh
pkg check -d e2guardian
pkg audit -F
ldd /usr/local/sbin/e2guardian
/usr/local/sbin/e2guardian -v
```

Valide as sete rotas autenticadas:

```sh
./blockmanager-webfilter-validate.sh --require-engine --require-catalog \
  --webgui-url 'https://ENDERECO:PORTA' \
  --cookie-file /root/pfsense-webgui.cookies --insecure
```

## Teste piloto

1. Defina uma única interface e grupo/rede piloto.
2. Ative em auditoria.
3. Confirme listener HTTP em 8080 e ausência de listener 8443 com HTTPS desligado.
4. Teste navegação HTTP, exceções, fail-open e remoção do anchor.
5. Só depois configure certificados e habilite `sni` ou `decrypt`.
6. Monitore CPU, memória, descritores, logs e estabilidade por janela suficiente para o ambiente.

## Critérios de aprovação

- `pkg check -d`, `pkg audit`, `ldd`, geração e teste sem erros;
- nenhuma regra fora do piloto;
- stop/rollback removem o anchor;
- E2Guardian permanece estável e não reinicia inesperadamente;
- nenhuma regressão nas sete rotas do Block Manager;
- HTTP e HTTPS seguem o perfil configurado;
- bundle offline íntegro e reproduzível para a arquitetura alvo.


## Monitor de HTTP Workers

1. Confirme que o E2Guardian grava `/var/log/e2guardian/dstats.log` no intervalo configurado.
2. Abra `block_manager.php?tab=webfilter_status` e compare **Workers configurados**, **Busy** e **httpwQ** com a última linha do arquivo.
3. Simule somente em fixture: `Busy == workers` deve gerar alerta; `httpwQ > 0` em duas amostras consecutivas deve gerar alerta de fila persistente.
4. Salve uma proposta de workers e confirme que ela fica `pending_validation`.
5. Confirme, por hash, que salvar a proposta não altera `e2guardian.conf`, não recarrega o serviço e não muda o tráfego.
6. Não aplique alteração real sem série histórica, avaliação de CPU/RAM, janela de mudança e rollback.


## Extensão r6-p4 - categorias externas

Validar por grupo os quatro modos (Padrão, Lista branca, Permitir e Negar), persistência de referências, reconstrução do catálogo após aplicar fonte, fluxo Salvar e aplicar, restauração automática em falha e ausência de leitura de categorias DNS.
