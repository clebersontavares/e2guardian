# r6-p4-hf2 — gestão prática sem ativação automática

## Princípios de segurança

- Baseline funcional: r6-p4.
- Mantém a correção do roteador/menu e a separação dos PIDs do E2Guardian e do supervisor `daemon(8)`.
- A instalação e o botão **Salvar sem ativar** nunca iniciam o E2Guardian, nunca criam o PID e nunca aplicam o anchor PF.
- A ativação continua exclusiva de **Web Filter > Status > Ativar piloto**, após confirmação.
- A WAN não aparece na lista essencial de interfaces.

## Interface

A WebGUI lê as interfaces atribuídas do pfSense e grava o **dispositivo físico**, não o nome lógico. Exemplo: `LAN — lan → hn1`. Isso evita enviar `lan` ao `pfctl` quando o dispositivo real é `hn1`.

## SSL / CA

Três modos:

1. **Manter configuração atual**: preserva os caminhos já existentes na r6-p4.
2. **Usar CA do pfSense**: lista apenas CAs que possuem certificado e chave privada; cria cópia protegida para o E2Guardian.
3. **Usar arquivos existentes**: recebe caminhos absolutos e exige arquivos legíveis.

As chaves não são exibidas. A cópia da chave usa modo `0600`.

## Bypass

Aceita um item por linha:

- IPv4;
- CIDR IPv4;
- hostname;
- alias de endereço/rede do pfSense.

Há listas separadas para origem e destino e opção independente para destinos RFC1918. Hostnames e aliases são resolvidos antes do `pfctl -n`; qualquer item não resolvido reprova a ativação.

## Autenticação

A baseline continua com um grupo técnico de piloto, mas gera `authplugin`/`ipmaplist` e o mapa `ipgroups` para autenticação por endereço IP.

## Watchdog

É fail-open e conservador:

- nunca ativa tráfego;
- nunca inicia nem reinicia o motor;
- se o motor cair enquanto houver ativação registrada, remove o redirecionamento;
- respeita o intervalo configurado;
- só roda quando o worker agendado foi instalado explicitamente e a opção foi marcada.

## Blacklists

- **Fontes externas**: URL, formato, agenda, staging, validação, aplicação e rollback da última geração válida.
- **Políticas**: seleção da fonte e das categorias por grupo.
- **Configuração > Avançado**: tamanho máximo, retenção de backups e permissão de URLs privadas.

## Sequência recomendada

1. Instalar com o Web Filter desabilitado.
2. Abrir Configuração, selecionar uma interface interna e manter Auditoria/Fail-open.
3. Selecionar CA somente se HTTPS/SNI for usado.
4. Configurar bypass.
5. Atualizar catálogo e compilar políticas.
6. Cadastrar e aplicar blacklist em Fontes externas.
7. Selecionar categorias por grupo em Políticas usando **Salvar**, não **Salvar e aplicar**.
8. Em Status, executar **Validar**.
9. Iniciar sem direcionar e validar PID/listeners.
10. Somente então usar **Ativar piloto**.
