#!/bin/sh
set -eu
ROOT=/;OUTPUT=;while [ $# -gt 0 ];do case "$1" in --root)ROOT=$2;shift 2;;--output)OUTPUT=$2;shift 2;;*)echo "Opção inválida: $1" >&2;exit 64;;esac;done
ROOT=${ROOT%/};[ -n "$ROOT" ]||ROOT=/;[ -n "$OUTPUT" ]||OUTPUT="${TMPDIR:-/tmp}/blockmanager-webfilter-config-$(date +%Y%m%d-%H%M%S).tar.gz";TMP=${TMPDIR:-/tmp}/bmwf-backup.$$;trap 'rm -rf "$TMP"' 0 1 2 15;mkdir -p "$TMP"
sha_cmd(){ if command -v sha256 >/dev/null 2>&1;then sha256 -q "$1";else sha256sum "$1"|awk '{print $1}';fi;}
for rel in usr/local/etc/blockmanager/webfilter var/db/blockmanager/webfilter/sources/active;do [ -e "$ROOT/$rel" ]||continue;mkdir -p "$TMP/$(dirname "$rel")";cp -Rp "$ROOT/$rel" "$TMP/$rel";done
( cd "$TMP";:>SHA256SUMS;find . -type f ! -name SHA256SUMS -print|sort|while IFS= read -r f;do printf '%s  %s\n' "$(sha_cmd "$f")" "$f">>SHA256SUMS;done;tar -czf "$OUTPUT" . )
echo "$OUTPUT"
