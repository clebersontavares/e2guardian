#!/usr/local/bin/php -q
<?php
/**
 * Read-only exporter of the Block Manager identity model.
 * It only reads current DNS Manager source files and never invokes or reloads Unbound.
 */

$bmicroot = '/';
$bmicValidateOnly = false;
for ($bmici = 1; $bmici < count($argv); $bmici++) {
    if ($argv[$bmici] === '--root' && isset($argv[$bmici + 1])) {
        $bmicroot = rtrim((string)$argv[++$bmici], '/');
        if ($bmicroot === '') $bmicroot = '/';
    } elseif ($argv[$bmici] === '--validate-only') {
        $bmicValidateOnly = true;
    } else {
        fwrite(STDERR, "Uso: blockmanager-identity-catalog-worker.php [--root DIR] [--validate-only]\n");
        exit(64);
    }
}
function bmic_root_path(string $root, string $path): string {
    return $root === '/' ? $path : $root . $path;
}
define('BMIC_STATE_DIR', bmic_root_path($bmicroot, '/var/db/blockmanager/shared'));
define('BMIC_LOG_DIR', bmic_root_path($bmicroot, '/var/log/blockmanager/shared'));
define('BMIC_RUN_DIR', bmic_root_path($bmicroot, '/var/run/blockmanager-shared'));
define('BMIC_CATALOG_FILE', BMIC_STATE_DIR . '/blockmanager-identity-catalog.json');
define('BMIC_USERS_GLOB', bmic_root_path($bmicroot, '/var/unbound/lists/users/*.json'));
define('BMIC_NETWORKS_GLOB', bmic_root_path($bmicroot, '/var/unbound/lists/networks/*.json'));
define('BMIC_GROUPS_GLOB', bmic_root_path($bmicroot, '/var/unbound/lists/groups/*.conf'));
define('BMIC_BINDINGS_GLOB', bmic_root_path($bmicroot, '/var/unbound/lists/device-bindings/*.json'));
define('BMIC_CONNECTORS_FILE', bmic_root_path($bmicroot, '/var/unbound/lists/group-connectors.json'));
define('BMIC_SESSIONS_FILE', bmic_root_path($bmicroot, '/var/unbound/lists/portal/sessions.json'));

function bmic_read(string $file): array {
    if (!is_file($file) || !is_readable($file)) return [];
    $decoded = json_decode((string)file_get_contents($file), true);
    return is_array($decoded) ? $decoded : [];
}
function bmic_is_list(array $value): bool { return array_values($value) === $value; }
function bmic_record_keys(string $kind): array {
    $common = ['id','name','enabled'];
    $specific = [
        'user'=>['username','user','device','device_name','identification_mode','group','group_name','groups','ip','ips','address','addresses','mac','macs','allowed_networks'],
        'binding'=>['username','user','device','device_name','group','groups','ip','ips','address','addresses','mac','macs','status'],
        'network'=>['network_name','cidr','cidrs','network','networks','subnet','address','group','group_name','groups'],
        'session'=>['username','user','identity','ip','group','group_name','groups','expires_at','expires_ts'],
    ];
    return array_merge($common, $specific[$kind] ?? []);
}
function bmic_is_record(array $value, string $kind): bool {
    foreach (bmic_record_keys($kind) as $key) if (array_key_exists($key, $value)) return true;
    return false;
}
function bmic_container_keys(string $kind): array {
    return [
        'user'=>['users','devices','identities','items','data','records'],
        'binding'=>['bindings','device_bindings','devices','items','data','records'],
        'network'=>['networks','network_records','items','data','records'],
        'session'=>['sessions','items','data','records'],
    ][$kind] ?? ['items','data','records'];
}
/** Normalize an object record, a list, a key-indexed map or a known container. */
function bmic_rows(array $data, string $kind, string $sourceKey='', int $depth=0): array {
    if (!$data || $depth > 5) return [];
    foreach (bmic_container_keys($kind) as $container) {
        if (isset($data[$container]) && is_array($data[$container])) {
            $nested=$data[$container];$containsRecord=bmic_is_record($nested,$kind);
            if(!$containsRecord)foreach($nested as$value)if(is_array($value)){$containsRecord=true;break;}
            if($containsRecord)return bmic_rows($nested, $kind, $sourceKey, $depth + 1);
        }
    }
    if (bmic_is_record($data, $kind)) {
        if ($sourceKey !== '' && !isset($data['_source_key'])) $data['_source_key'] = $sourceKey;
        return [$data];
    }
    $rows = [];
    foreach ($data as $key => $value) {
        $mapKey = is_string($key) ? $key : '';
        if (is_array($value)) {
            foreach (bmic_rows($value, $kind, $mapKey !== '' ? $mapKey : $sourceKey, $depth + 1) as $row) $rows[] = $row;
        } elseif ($mapKey !== '' && is_scalar($value)) {
            $scalar = trim((string)$value);
            if ($scalar === '') continue;
            if ($kind === 'network') $rows[] = ['name'=>$mapKey, 'cidr'=>$scalar, '_source_key'=>$mapKey];
            elseif ($kind === 'binding' && filter_var($scalar, FILTER_VALIDATE_IP)) $rows[] = ['device'=>$mapKey, 'ip'=>$scalar, '_source_key'=>$mapKey];
        }
    }
    return $rows;
}
function bmic_values($value): array {
    $out = [];
    $walk = function ($item) use (&$out, &$walk): void {
        if (is_array($item)) { foreach ($item as $nested) $walk($nested); return; }
        if (!is_scalar($item)) return;
        foreach (preg_split('/[\r\n,;]+/', (string)$item) as $part) {
            $part = trim($part);
            if ($part !== '') $out[strtolower($part)] = $part;
        }
    };
    $walk($value);
    return array_values($out);
}
function bmic_first(array $row, array $keys): string {
    foreach ($keys as $key) {
        if (!array_key_exists($key, $row) || !is_scalar($row[$key])) continue;
        $value = trim((string)$row[$key]);
        if ($value !== '') return $value;
    }
    return '';
}
function bmic_group_valid(string $group): bool {
    return $group !== '' && preg_match('/^[\pL\pN][\pL\pN_. @()\/-]{0,127}$/uD', $group) === 1;
}
function bmic_groups(array $row): array {
    $values = [];
    foreach (['group','group_name','dns_group'] as $key) if (isset($row[$key])) $values = array_merge($values, bmic_values($row[$key]));
    if (isset($row['groups'])) $values = array_merge($values, bmic_values($row['groups']));
    $out = [];
    foreach ($values as $value) if (bmic_group_valid($value)) $out[strtolower($value)] = $value;
    $out = array_values($out); natcasesort($out); return array_values($out);
}
function bmic_ips(array $row): array {
    $values=[]; foreach (['ip','ips','address','addresses','resolved_ip','current_ip'] as $key) if(isset($row[$key]))$values=array_merge($values,bmic_values($row[$key]));
    $out=[]; foreach($values as$value)if(filter_var($value,FILTER_VALIDATE_IP))$out[$value]=true;
    $result=array_keys($out); sort($result,SORT_NATURAL); return$result;
}
function bmic_normalize_mac(string $value): string {
    $hex = strtolower((string)preg_replace('/[^0-9a-f]/i', '', $value));
    return strlen($hex) === 12 ? implode(':', str_split($hex, 2)) : '';
}
function bmic_macs(array $row): array {
    $values=[]; foreach(['mac','macs','mac_address','mac_addresses']as$key)if(isset($row[$key]))$values=array_merge($values,bmic_values($row[$key]));
    $out=[]; foreach($values as$value){$mac=bmic_normalize_mac($value);if($mac!=='')$out[$mac]=true;}
    $result=array_keys($out); sort($result,SORT_STRING); return$result;
}
function bmic_cidr(string $value): string {
    $value=trim($value); if($value==='')return'';
    if(strpos($value,'/')===false){if(filter_var($value,FILTER_VALIDATE_IP,FILTER_FLAG_IPV4))return$value.'/32';if(filter_var($value,FILTER_VALIDATE_IP,FILTER_FLAG_IPV6))return$value.'/128';return'';}
    [$ip,$prefix]=array_pad(explode('/',$value,2),2,'');
    if(!ctype_digit($prefix)||!filter_var($ip,FILTER_VALIDATE_IP))return'';
    $max=strpos($ip,':')!==false?128:32;$n=(int)$prefix;return$n>=0&&$n<=$max?$ip.'/'.$n:'';
}
function bmic_cidrs(array $row): array {
    $values=[];foreach(['cidr','cidrs','network','networks','subnet','address']as$key)if(isset($row[$key]))$values=array_merge($values,bmic_values($row[$key]));
    $out=[];foreach($values as$value){$cidr=bmic_cidr($value);if($cidr!=='')$out[$cidr]=true;}
    $result=array_keys($out);sort($result,SORT_NATURAL);return$result;
}
function bmic_strings($value): array {$out=bmic_values($value);natcasesort($out);return array_values($out);}
function bmic_key(string $value): string { return strtolower(trim($value)); }
function bmic_identity_keys(array $row, string $fallback=''): array {
    $keys=[];foreach(['username','user','device','device_name','id','name','_source_key']as$key){$value=bmic_first($row,[$key]);if($value!=='')$keys[bmic_key($value)]=true;}
    if($fallback!=='')$keys[bmic_key($fallback)]=true;return array_keys($keys);
}
function bmic_merge_unique(array $left,array $right):array{$out=[];foreach(array_merge($left,$right)as$value){$value=trim((string)$value);if($value!=='')$out[strtolower($value)]=$value;}$out=array_values($out);natcasesort($out);return array_values($out);}
function bmic_connectors(array $data): array {
    if(isset($data['groups'])&&is_array($data['groups']))$data=$data['groups'];
    $out=[];
    foreach($data as$groupKey=>$entry){
        if(!is_array($entry))continue;
        $group=is_int($groupKey)?bmic_first($entry,['group','group_name','name']):trim((string)$groupKey);
        if(!bmic_group_valid($group))continue;
        $sources=is_array($entry['sources']??null)?$entry['sources']:[];
        $pf=is_array($sources['pfsense']??null)?$sources['pfsense']:[];
        $ldap=is_array($sources['ldap']??null)?$sources['ldap']:[];
        $out[$group]=[
            'pfsense'=>[
                'users'=>bmic_strings($pf['users']??$entry['pfsense_users']??$entry['users']??[]),
                'groups'=>bmic_strings($pf['groups']??$entry['pfsense_groups']??[]),
            ],
            'ldap'=>[
                'server'=>bmic_first($ldap,['server']),
                'containers'=>bmic_strings($ldap['containers']??[]),
                'groups'=>bmic_strings($ldap['groups']??$entry['directory_groups']??[]),
            ],
            'connector_ids'=>bmic_strings($entry['connector_ids']??$entry['connectors']??[]),
            'updated_at'=>$entry['updated_at']??null,
        ];
    }
    uksort($out,'strnatcasecmp');return$out;
}
function bmic_connector_groups_for_identity(array $identity,array $connectors):array{
    $out=[];$username=bmic_key((string)($identity['username']??''));$sourceGroups=array_map('bmic_key',(array)($identity['source_groups']??$identity['groups']??[]));
    foreach($connectors as$dnsGroup=>$entry){$pf=(array)($entry['pfsense']??[]);$users=array_map('bmic_key',(array)($pf['users']??[]));$groups=array_map('bmic_key',(array)($pf['groups']??[]));if(($username!==''&&in_array($username,$users,true))||array_intersect($sourceGroups,$groups))$out[]=$dnsGroup;}
    return bmic_merge_unique([],$out);
}
function bmic_atomic(string $file,array $data):void{$tmp=$file.'.new.'.getmypid();if(file_put_contents($tmp,json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n",LOCK_EX)===false)throw new RuntimeException('Falha ao gravar catálogo.');chmod($tmp,0640);if(!rename($tmp,$file)){@unlink($tmp);throw new RuntimeException('Falha ao promover catálogo.');}}
function bmic_log(string $level,string $message,array $context=[]):void{if(!is_dir(BMIC_LOG_DIR))@mkdir(BMIC_LOG_DIR,0750,true);@file_put_contents(BMIC_LOG_DIR.'/identity-catalog.log',json_encode(['ts'=>date(DATE_ATOM),'level'=>$level,'message'=>$message,'context'=>$context],JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n",FILE_APPEND|LOCK_EX);}
function bmic_validate_catalog(array $catalog):void{
    $artifacts=['groups','ips','macs','allowed_networks'];$seen=[];
    foreach((array)$catalog['identities']as$identity){
        $id=trim((string)($identity['id']??''));$name=trim((string)($identity['name']??''));
        if($id===''||$name==='')throw new RuntimeException('Identidade sem id/name.');
        if(in_array(strtolower($id),$artifacts,true)||in_array(strtolower($name),$artifacts,true))throw new RuntimeException('Identidade estrutural artificial detectada: '.$id);
        $key=bmic_key((string)($identity['username']?:$id));if(isset($seen[$key]))throw new RuntimeException('Identidade duplicada: '.$key);$seen[$key]=true;
    }
    foreach((array)$catalog['networks']as$network){if(empty($network['name'])||empty($network['cidrs']))throw new RuntimeException('Rede sem nome/CIDR válido.');foreach((array)$network['cidrs']as$cidr)if(bmic_cidr((string)$cidr)==='')throw new RuntimeException('CIDR inválido no catálogo: '.$cidr);}
    foreach(['groups','identities','networks','sessions','connector_groups']as$key)if((int)($catalog['counts'][$key]??-1)<0)throw new RuntimeException('Count ausente: '.$key);
}
function bmic_build_catalog():array{
    $hashes=[];$groups=[];
    foreach((array)glob(BMIC_GROUPS_GLOB)as$file){$hashes[$file]=hash_file('sha256',$file);$group=basename($file,'.conf');if(bmic_group_valid($group))$groups[$group]=true;}
    $connectors=bmic_connectors(bmic_read(BMIC_CONNECTORS_FILE));if(is_file(BMIC_CONNECTORS_FILE))$hashes[BMIC_CONNECTORS_FILE]=hash_file('sha256',BMIC_CONNECTORS_FILE);foreach(array_keys($connectors)as$group)$groups[$group]=true;

    $bindingIndex=[];
    foreach((array)glob(BMIC_BINDINGS_GLOB)as$file){
        $hashes[$file]=hash_file('sha256',$file);$fallback=basename($file,'.json');
        foreach(bmic_rows(bmic_read($file),'binding',$fallback)as$row){foreach(bmic_identity_keys($row,$fallback)as$key){if(!isset($bindingIndex[$key]))$bindingIndex[$key]=['ips'=>[],'macs'=>[],'groups'=>[]];$bindingIndex[$key]['ips']=bmic_merge_unique($bindingIndex[$key]['ips'],bmic_ips($row));$bindingIndex[$key]['macs']=bmic_merge_unique($bindingIndex[$key]['macs'],bmic_macs($row));$bindingIndex[$key]['groups']=bmic_merge_unique($bindingIndex[$key]['groups'],bmic_groups($row));}}
    }

    $identityMap=[];
    foreach((array)glob(BMIC_USERS_GLOB)as$file){
        $hashes[$file]=hash_file('sha256',$file);$fallback=basename($file,'.json');
        foreach(bmic_rows(bmic_read($file),'user',$fallback)as$row){
            $username=bmic_first($row,['username','user']);$id=bmic_first($row,['id','username','user','device','device_name','name','_source_key']);if($id==='')$id=$fallback;
            $name=bmic_first($row,['name','device_name','device','username','user','id','_source_key']);if($name==='')$name=$id;
            if(in_array(strtolower($id),['groups','ips','macs','allowed_networks'],true))continue;
            $keys=bmic_identity_keys($row,$fallback);$binding=['ips'=>[],'macs'=>[],'groups'=>[]];foreach($keys as$key)if(isset($bindingIndex[$key])){$binding['ips']=bmic_merge_unique($binding['ips'],$bindingIndex[$key]['ips']);$binding['macs']=bmic_merge_unique($binding['macs'],$bindingIndex[$key]['macs']);$binding['groups']=bmic_merge_unique($binding['groups'],$bindingIndex[$key]['groups']);}
            $sourceGroups=bmic_merge_unique(bmic_groups($row),$binding['groups']);$ips=bmic_merge_unique(bmic_ips($row),$binding['ips']);$macs=bmic_merge_unique(bmic_macs($row),$binding['macs']);$networkNames=bmic_strings($row['allowed_networks']??$row['network_names']??[]);
            $identity=['id'=>$id,'name'=>$name,'username'=>$username,'ip'=>$ips[0]??'','ips'=>$ips,'mac'=>$macs[0]??'','macs'=>$macs,'groups'=>$sourceGroups,'source_groups'=>$sourceGroups,'networks'=>$networkNames,'identification_mode'=>(string)($row['identification_mode']??''),'enabled'=>($row['enabled']??true)!==false,'source_file'=>$file];
            $identity['groups']=bmic_merge_unique($identity['groups'],bmic_connector_groups_for_identity($identity,$connectors));foreach($identity['groups']as$group)$groups[$group]=true;
            $canonical=bmic_key($username!==''?$username:$id);if($canonical==='')continue;
            if(isset($identityMap[$canonical])){$old=$identityMap[$canonical];$identity['ips']=bmic_merge_unique($old['ips'],$identity['ips']);$identity['macs']=bmic_merge_unique($old['macs'],$identity['macs']);$identity['groups']=bmic_merge_unique($old['groups'],$identity['groups']);$identity['networks']=bmic_merge_unique($old['networks'],$identity['networks']);$identity['ip']=$identity['ips'][0]??'';$identity['mac']=$identity['macs'][0]??'';$identity['enabled']=$old['enabled']&&$identity['enabled'];if($identity['username']==='')$identity['username']=$old['username'];}
            $identityMap[$canonical]=$identity;
        }
    }
    uksort($identityMap,'strnatcasecmp');$identities=array_values($identityMap);

    $networkMap=[];
    foreach((array)glob(BMIC_NETWORKS_GLOB)as$file){
        $hashes[$file]=hash_file('sha256',$file);$fallback=basename($file,'.json');
        foreach(bmic_rows(bmic_read($file),'network',$fallback)as$row){$name=bmic_first($row,['name','network_name','id','_source_key']);if($name==='')$name=$fallback;$cidrs=bmic_cidrs($row);if(!$cidrs)continue;$networkGroups=bmic_groups($row);foreach($networkGroups as$group)$groups[$group]=true;$key=bmic_key($name);if(!isset($networkMap[$key]))$networkMap[$key]=['id'=>bmic_first($row,['id'])?:$name,'name'=>$name,'cidr'=>$cidrs[0],'cidrs'=>[],'groups'=>[],'enabled'=>true,'source_files'=>[]];$networkMap[$key]['cidrs']=bmic_merge_unique($networkMap[$key]['cidrs'],$cidrs);$networkMap[$key]['groups']=bmic_merge_unique($networkMap[$key]['groups'],$networkGroups);$networkMap[$key]['enabled']=$networkMap[$key]['enabled']&&(($row['enabled']??true)!==false);$networkMap[$key]['source_files'][]=$file;$networkMap[$key]['source_files']=array_values(array_unique($networkMap[$key]['source_files']));$networkMap[$key]['cidr']=$networkMap[$key]['cidrs'][0];}
    }
    uksort($networkMap,'strnatcasecmp');$networks=array_values($networkMap);

    $sessions=[];$sessionSeen=[];$rawSessions=bmic_read(BMIC_SESSIONS_FILE);if(is_file(BMIC_SESSIONS_FILE))$hashes[BMIC_SESSIONS_FILE]=hash_file('sha256',BMIC_SESSIONS_FILE);
    foreach(bmic_rows($rawSessions,'session')as$row){$ip=bmic_first($row,['ip','address']);if($ip===''&&isset($row['_source_key'])&&filter_var($row['_source_key'],FILTER_VALIDATE_IP))$ip=(string)$row['_source_key'];if(!filter_var($ip,FILTER_VALIDATE_IP))continue;$expires=$row['expires_at']??$row['expires_ts']??null;if(is_numeric($expires)&&(int)$expires>0&&(int)$expires<time())continue;$sessionGroups=bmic_groups($row);$group=$sessionGroups[0]??'';if($group!=='')$groups[$group]=true;$username=bmic_first($row,['username','user']);$key=$ip.'|'.bmic_key($username);if(isset($sessionSeen[$key]))continue;$sessionSeen[$key]=true;$sessions[]=['ip'=>$ip,'username'=>$username,'identity'=>bmic_first($row,['identity','name','username','user']),'group'=>$group,'groups'=>$sessionGroups,'expires_at'=>$expires];}

    $groupNames=array_keys($groups);natcasesort($groupNames);$groupNames=array_values($groupNames);ksort($hashes,SORT_STRING);
    $catalog=['version'=>3,'generated_at'=>date(DATE_ATOM),'source_contract'=>'groups-identities-connectors-read-only','groups'=>$groupNames,'identities'=>$identities,'networks'=>$networks,'sessions'=>$sessions,'connectors'=>$connectors,'source_hashes'=>$hashes,'counts'=>['groups'=>count($groupNames),'identities'=>count($identities),'networks'=>count($networks),'sessions'=>count($sessions),'connector_groups'=>count($connectors)]];
    bmic_validate_catalog($catalog);return$catalog;
}
function bmic_main(bool $validateOnly):int{
    foreach([BMIC_STATE_DIR,BMIC_LOG_DIR,BMIC_RUN_DIR]as$dir)if(!is_dir($dir)&&!@mkdir($dir,0750,true)&&!is_dir($dir)){fwrite(STDERR,"Diretório indisponível: $dir\n");return 1;}
    $lock=@fopen(BMIC_RUN_DIR.'/identity-catalog.lock','c');if(!$lock||!flock($lock,LOCK_EX|LOCK_NB)){fwrite(STDERR,"exportador ocupado\n");return 75;}
    try{$catalog=bmic_build_catalog();if(!$validateOnly)bmic_atomic(BMIC_CATALOG_FILE,$catalog);bmic_log('info',$validateOnly?'Catálogo validado sem gravação.':'Catálogo mestre atualizado sem invocar Unbound.',$catalog['counts']);echo json_encode(['status'=>'ok','validate_only'=>$validateOnly,'catalog'=>BMIC_CATALOG_FILE,'counts'=>$catalog['counts'],'content_validation'=>['artificial_identities'=>0,'duplicates'=>0,'invalid_networks'=>0]],JSON_PRETTY_PRINT|JSON_UNESCAPED_SLASHES|JSON_UNESCAPED_UNICODE)."\n";return 0;}
    catch(Throwable$error){bmic_log('error',$error->getMessage());fwrite(STDERR,$error->getMessage()."\n");return 1;}
    finally{flock($lock,LOCK_UN);fclose($lock);}
}
if(PHP_SAPI!=='cli'){http_response_code(403);exit;}
exit(bmic_main($bmicValidateOnly));
