<?php
/** Regression test for pfSense reserved globals in the integrated page fragment. */
if ($argc !== 2) {
    fwrite(STDERR, "Usage: php blockmanager-webfilter-page-scope-test.php PAGE\n");
    exit(64);
}
$page = $argv[1];
if (!is_file($page)) {
    fwrite(STDERR, "Page not found: {$page}\n");
    exit(66);
}

const BMWF_STATE_DIR = '/nonexistent/bmwf-state';
const BMWF_ACCESS_LOG = '/nonexistent/bmwf-access.log';

function bmwf_tabs(): array {
    return ['webfilter','webfilter_policies','webfilter_lists','webfilter_sources','webfilter_logs','webfilter_status','webfilter_settings'];
}
function bmwf_is_tab(string $tab): bool { return in_array($tab, bmwf_tabs(), true); }
function bmwf_settings(): array {
    return [
        'enabled'=>false,
        'mode'=>'audit',
        'global_default_action'=>'allow',
        'activation'=>[
            'pilot_group'=>'','pilot_networks'=>[],'fail_open'=>true,
            'http_enabled'=>true,'https_profile'=>'off',
        ],
        'https_inspection'=>[
            'implementation_state'=>'reserved','enabled'=>false,
            'policy_mode'=>'separate','default_action'=>'bypass',
        ],
        'logging'=>[
            'webgui_lines'=>25,
            'initial_tail_lines'=>200,
            'max_lines_per_run'=>2000,
            'access_log_rotate_bytes'=>5242880,
        ],
    ];
}
function bmwf_snapshot(): array {
    return [
        'groups'=>['Rede Administrativa','Rede Visitantes'],
        'identities'=>[['id'=>'device-1']],
        'networks'=>[['id'=>'network-1','cidr'=>'192.0.2.0/24']],
    ];
}
function bmwf_status(): array { return ['status'=>'never_run','message'=>'Worker desativado.']; }
function bmwf_sources(): array {
    return ['source-a'=>[
        'name'=>'Source A','description'=>'Fixture','url'=>'https://example.invalid/list.txt',
        'format'=>'domains','schedule'=>'manual','default_category'=>'fixture',
        'last_validation'=>['entries'=>1],'active_sha256'=>'0123456789abcdef',
    ]];
}
function bmwf_json_read(string $file, $default=[]): array { return is_array($default) ? $default : []; }
function bmwf_pfsense_interface_catalog(): array { return []; }
function bmwf_pfsense_ca_catalog(): array { return []; }
function bmwf_valid_group(string $group): bool { return $group !== ''; }
function bmwf_policy(string $group): array {
    return [
        'enabled'=>false,'default_action'=>'inherit','source_ids'=>['source-a'],
        'source_categories'=>[],'use_local_allow'=>true,'use_local_block'=>true,
        'use_ssl_exceptions'=>true,'use_log_only'=>true,
    ];
}
function bmwf_local_list(string $kind): array { return []; }
function bmwf_recent_access(int $limit): array {
    return [[
        'timestamp'=>'2026-10-08T08:18:17-03:00','ip'=>'192.0.2.10','identity'=>'fixture',
        'group'=>'Rede Administrativa','method'=>'GET','domain'=>'example.invalid','url'=>'',
        'category'=>'fixture','action'=>'LOG','reason'=>'test','https_profile'=>'none',
        'inspection_level'=>'domain',
    ]];
}
function bmwf_http_workers_snapshot(?array $settings=null): array {
    return ['status'=>'ok','message'=>'Capacidade dentro dos critérios configurados.','configured_workers'=>100,'configured_source'=>'fixture','busy'=>20,'httpwQ'=>0,'httpwQ_consecutive_samples'=>0,'httpwQ_alert_after_samples'=>2,'sample_time'=>1760221040,'httpw_reported'=>100,'free'=>80,'alerts'=>[],'proposed_workers'=>0,'proposal_status'=>'none','proposal_note'=>''];
}
function csrf_start(): string { return '<input type="hidden" name="__csrf_magic" value="fixture">'; }
function e($value): string { return htmlspecialchars((string)$value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function pfSense_test_g_has(string $key): bool {
    global $g;
    return array_key_exists($key, $g);
}

$g = ['platform'=>'pfSense', 'sentinel'=>true];
$expectedGlobal = $g;
$_SERVER['REQUEST_METHOD'] = 'GET';

foreach (bmwf_tabs() as $route) {
    $tab = $route;
    $_GET = ['tab'=>$route];
    ob_start();
    include $page;
    $html = (string)ob_get_clean();
    if ($g !== $expectedGlobal) {
        fwrite(STDERR, "Reserved global \\$g changed while rendering {$route}\n");
        exit(1);
    }
    if (!pfSense_test_g_has('sentinel')) {
        fwrite(STDERR, "pfSense-style g_has failed after {$route}\n");
        exit(1);
    }
    if (strpos($html, 'data-bmwf-route="'.$route.'"') === false) {
        fwrite(STDERR, "Route marker missing for {$route}\n");
        exit(1);
    }
}

echo "OK: all seven routes preserve pfSense reserved global \\$g\n";
