<?php
/** Functional parser test for the Web Filter log monitor. */
$tmp = sys_get_temp_dir() . '/bmwf-log-monitor-' . getmypid();
putenv('BMWF_ROOT=' . $tmp);
require dirname(__DIR__) . '/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php';

function monitor_assert(bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "ERROR: {$message}\n");
        exit(1);
    }
}

$allow = implode("\t", [
    '1760221040.125', '-', 'alice', '192.0.2.10', 'client-a',
    'https://example.invalid/path?q=1', 'GET', '200', '1024', 'text/html',
    '-', '-', '24', '-', '0', '-', '0', 'business', 'Pilot', '1',
]);
$event = bmwf_normalize_event($allow, 'e2guardian_access');
monitor_assert(is_array($event), 'E2Guardian format 6 line was not parsed');
monitor_assert($event['action'] === 'ALLOW', 'allowed request was not classified as ALLOW');
monitor_assert($event['ip'] === '192.0.2.10', 'client IP was not extracted');
monitor_assert($event['identity'] === 'alice', 'identity was not extracted');
monitor_assert($event['domain'] === 'example.invalid', 'domain was not extracted from URL');
monitor_assert($event['category'] === 'business', 'category was not extracted');
monitor_assert($event['group'] === 'Pilot', 'filter group was not extracted');
monitor_assert($event['response_code'] === 200 && $event['bytes'] === 1024 && $event['duration_ms'] === 24, 'HTTP metrics were not normalized');

$block = implode("\t", [
    '1760221041', '-', 'bob', '198.51.100.20', 'client-b',
    'http://blocked.invalid/', 'GET', '403', '512', 'text/html',
    '-', '-', '10', '-', '403', 'Banned site: policy', '0', 'blocked', 'Pilot', '1',
]);
$event = bmwf_normalize_event($block, 'e2guardian_access');
monitor_assert(is_array($event) && $event['action'] === 'BLOCK', 'blocked request was not classified as BLOCK');
monitor_assert($event['reason'] === 'Banned site: policy', 'block reason was not retained');

$json = bmwf_normalize_event('{"timestamp":"2026-10-11T23:17:20-03:00","ip":"203.0.113.5","domain":"json.invalid","action":"LOG"}', 'json_fixture');
monitor_assert(is_array($json) && $json['source'] === 'json_fixture' && $json['action'] === 'LOG', 'JSONL compatibility regressed');
$keyValue = bmwf_normalize_event('ts="2026-10-11T23:17:20-03:00" ip=203.0.113.6 domain=kv.invalid action=ALLOW', 'kv_fixture');
monitor_assert(is_array($keyValue) && $keyValue['domain'] === 'kv.invalid', 'key-value compatibility regressed');

$source = $tmp . '/var/log/e2guardian/access.log';
@mkdir(dirname($source), 0750, true);
file_put_contents($source, $allow . "\n" . $block . "\n");
$summary = bmwf_collect_logs();
monitor_assert(($summary['written'] ?? 0) === 2, 'cursor collector did not normalize both source events');
$recent = bmwf_recent_access(10);
monitor_assert(count($recent) === 2 && $recent[0]['action'] === 'BLOCK', 'recent-event window is not newest-first');
$delta = bmwf_log_delta(0, 10);
monitor_assert(count($delta['events']) === 2 && $delta['cursor'] > 0, 'incremental monitor delta is invalid');

echo "OK: Web Filter monitor parses E2Guardian format 6, JSONL and key-value events; cursor collection and delta passed\n";
