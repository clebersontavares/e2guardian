<?php
/** Functional test for conservative E2Guardian HTTP Worker monitoring. */
$tmp = sys_get_temp_dir() . '/bmwf-http-workers-' . getmypid();
putenv('BMWF_ROOT=' . $tmp);
require dirname(__DIR__) . '/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php';

function workers_assert(bool $condition, string $message): void {
    if (!$condition) {
        fwrite(STDERR, "ERROR: {$message}\n");
        exit(1);
    }
}

bmwf_ensure_dirs();
$config = $tmp . '/usr/local/etc/blockmanager/webfilter/generated/e2guardian.conf';
@mkdir(dirname($config), 0750, true);
file_put_contents($config, "filterip = '127.0.0.1'\nhttpworkers = 100\n");
$dstats = $tmp . '/var/log/e2guardian/dstats.log';
@mkdir(dirname($dstats), 0750, true);
$now = time();
file_put_contents($dstats,
    "time httpw busy httpwQ logQ conx conx/s reqs reqs/s maxfd LCcnt\n" .
    ($now - 600) . " 100 90 0 0 90 0 90 0 273 1\n" .
    ($now - 300) . " 100 100 1 0 120 0 120 0 273 1\n" .
    $now . " 100 100 1 0 130 0 130 0 273 1\n"
);

$snapshot = bmwf_http_workers_snapshot();
workers_assert($snapshot['configured_workers'] === 100, 'configured httpworkers was not read');
workers_assert($snapshot['busy'] === 100, 'Busy was not read');
workers_assert($snapshot['httpwQ'] === 1, 'httpwQ was not read');
workers_assert($snapshot['httpwQ_consecutive_samples'] === 2, 'persistent httpwQ streak was not detected');
workers_assert(count($snapshot['alerts']) === 2, 'Busy-limit and persistent-queue alerts were not both emitted');
workers_assert($snapshot['auto_adjust'] === false && $snapshot['override_enabled'] === false, 'monitor must never auto-adjust workers');

$before = hash_file('sha256', $config);
$result = bmwf_save_http_workers_proposal(['proposed_workers'=>150,'proposal_note'=>'pico validado manualmente'], 'fixture');
workers_assert($result['ok'] === true, 'worker proposal was not saved');
workers_assert(hash_file('sha256', $config) === $before, 'saving a proposal changed E2Guardian configuration');
$settings = bmwf_json_read(BMWF_SETTINGS_FILE, []);
workers_assert($settings['http_workers']['proposed_workers'] === 150, 'proposal value was not persisted');
workers_assert($settings['http_workers']['proposal_status'] === 'pending_validation', 'proposal was not marked pending validation');
workers_assert($settings['http_workers']['auto_adjust'] === false && $settings['http_workers']['override_enabled'] === false, 'proposal enabled automatic adjustment');

echo "OK: HTTP Workers configured/Busy/httpwQ monitoring and proposal-only management passed\n";
