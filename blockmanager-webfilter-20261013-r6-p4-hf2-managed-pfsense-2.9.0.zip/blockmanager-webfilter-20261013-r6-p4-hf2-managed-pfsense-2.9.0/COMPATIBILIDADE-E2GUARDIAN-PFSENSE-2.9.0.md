# Compatibilidade E2Guardian — pfSense CE 2.9.0

## Incompatibilidades corrigidas

1. O adaptador anterior detectava e configurava **Squid**, não E2Guardian.
2. Os comandos `-k parse`, `-z`, `-k shutdown` e `-k reconfigure` pertencem ao Squid e não são válidos para E2Guardian.
3. As portas padrão anteriores (`3128/3129`) eram de um backend Squid; E2Guardian usa `filterports` (HTTP, 8080 por padrão) e `transparenthttpsport` (8443 nesta revisão).
4. `transparenthttpsport` não pode ser emitido quando HTTPS está desligado: no E2Guardian 5.3.x, a mera presença da diretiva habilita o listener e pode impedir a inicialização.
5. O instalador anterior executava `pkg install squid`, sem inventário ou verificação das dependências do E2Guardian.
6. O pacote não distinguia instalação online de um bundle offline verificável.

## Estratégia aplicada

- Driver explícito `e2guardian`, mantendo `squid-legacy` apenas para migração sem quebra imediata.
- Configuração gerada a partir do arquivo-base instalado pelo pacote nativo do E2Guardian; o WebFilter não tenta recriar os centenas de parâmetros do motor.
- Lista de bloqueio e exceção do piloto gerada em diretório isolado do Block Manager.
- HTTPS transparente só é emitido quando o perfil HTTPS não é `off`.
- Controle do E2Guardian com opções nativas: `-c`, `-N`, `-q`, `-r` e `-s`.
- Dependências instaladas somente por ação explícita e preferencialmente por bundle offline com SHA-256.
- Sem criação de links falsos entre versões de OpenSSL/libsodium e sem alteração permanente de repositórios do pfSense.

## Dependências

O pacote raiz é `e2guardian`. As dependências transitivas devem ser resolvidas pelo `pkg fetch -d` **no próprio pfSense 2.9.0 e na arquitetura correta**. A implementação pública para pfSense 2.9 observou `harfbuzz` e `talloc`, mas esta revisão não fixa versões que não foram recuperadas do ambiente alvo.

ClamAV é opcional e não é habilitado nesta revisão. Squid também é opcional: o E2Guardian 5.5 permite acesso direto quando `proxyip` não é definido.

## Limite atual da autocontenção

O código, os validadores e o instalador offline estão incluídos. Os pacotes FreeBSD nativos não foram encontrados nos materiais internos e não puderam ser baixados no ambiente de preparação. Consequentemente, o artefato permanece **candidato de homologação** até o `--vendorize` gerar o bundle e o `--verify-bundle` aprová-lo.
