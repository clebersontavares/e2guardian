# Catálogo próprio de categorias externas - r6-p4

## Contrato e isolamento

O catálogo pertence exclusivamente ao Web Filter e é gerado em `/var/db/blockmanager/webfilter/categories/category-catalog.json` a partir das gerações ativas em `/var/db/blockmanager/webfilter/sources/active/`. Ele não lê, importa, vincula ou modifica categorias do DNS Manager/Unbound.

Cada referência é estável no formato `source_id:hash16`, calculada a partir do ID da fonte e do nome exato da categoria. O catálogo preserva fonte, nome, contagem de domínios, hash ativo e vínculos por grupo.

## Modos por grupo

- **Padrão (`default`)**: as categorias vinculadas seguem a ação padrão efetiva do grupo.
- **Lista branca (`whitelist`)**: permite as categorias selecionadas e nega as demais categorias das fontes vinculadas.
- **Permitir (`allow`)**: permite explicitamente as selecionadas; as demais seguem a ação padrão.
- **Negar (`deny`)**: nega as selecionadas; as demais seguem a ação padrão.

As listas locais continuam separadas e são aplicadas conforme os flags da política. Permissões explícitas removem sobreposição da lista de bloqueio.

## Salvar e aplicar

O botão executa salvar política v3, reconstruir catálogo/vínculos, compilar, gerar configuração, validar E2Guardian, recarregar ou iniciar o motor e reaplicar o tráfego. Em qualquer falha, a política anterior é restaurada e há tentativa de reaplicação da geração anterior; o fail-open continua removendo o redirecionamento quando necessário.

## Rollback

- Rollback de uma tentativa de aplicação: automático no controlador da WebGUI.
- Rollback do pacote: `./blockmanager-webfilter-rollback.sh /var/backups/blockmanager/webfilter/preinstall-AAAAMMDD-HHMMSS`.
- Os dados ativos das fontes e o catálogo runtime não são tratados como payload descartável; a reversão do pacote não apaga listas do usuário.
