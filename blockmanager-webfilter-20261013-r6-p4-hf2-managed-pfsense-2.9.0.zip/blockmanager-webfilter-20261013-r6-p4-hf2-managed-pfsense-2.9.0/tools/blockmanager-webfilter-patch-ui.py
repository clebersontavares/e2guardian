#!/usr/bin/env python3
"""Integrate Web Filter into the real Block Manager accordion/router without href assumptions."""
from __future__ import annotations
import argparse, os, re
from pathlib import Path

SB_BEGIN="/* BLOCKMANAGER_WEBFILTER_SIDEBAR_BEGIN */"; SB_END="/* BLOCKMANAGER_WEBFILTER_SIDEBAR_END */"
INC_BEGIN="/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_BEGIN */"; INC_END="/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_END */"
TABS_BEGIN="/* BLOCKMANAGER_WEBFILTER_TABS_BEGIN */"; TABS_END="/* BLOCKMANAGER_WEBFILTER_TABS_END */"
PREP_BEGIN="/* BLOCKMANAGER_WEBFILTER_PREPARE_BEGIN */"; PREP_END="/* BLOCKMANAGER_WEBFILTER_PREPARE_END */"
TITLE_BEGIN="/* BLOCKMANAGER_WEBFILTER_TITLES_BEGIN */"; TITLE_END="/* BLOCKMANAGER_WEBFILTER_TITLES_END */"
PAGE_BEGIN="<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->"; PAGE_END="<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->"
OLD_PAGE_BEGIN="/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */"; OLD_PAGE_END="/* BLOCKMANAGER_WEBFILTER_PAGE_END */"
LEGACY_RE=re.compile(r"\s*<!-- BLOCKMANAGER_WEBFILTER_MENU_BEGIN -->.*?<!-- BLOCKMANAGER_WEBFILTER_MENU_END -->",re.S)
SIDEBAR_BLOCK="""\n /* BLOCKMANAGER_WEBFILTER_SIDEBAR_BEGIN */
 'webfilter'=>['label'=>'Web Filter','icon'=>'dns','items'=>[
  ['tab'=>'webfilter','label'=>'Visão geral'],
  ['tab'=>'webfilter_policies','label'=>'Políticas'],
  ['tab'=>'webfilter_lists','label'=>'Listas locais'],
  ['tab'=>'webfilter_sources','label'=>'Fontes externas'],
  ['tab'=>'webfilter_logs','label'=>'Monitor em tempo real'],
  ['tab'=>'webfilter_status','label'=>'Status'],
  ['tab'=>'webfilter_settings','label'=>'Configuração']]],
 /* BLOCKMANAGER_WEBFILTER_SIDEBAR_END */"""
INCLUDE_BLOCK="\n/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_BEGIN */\nrequire_once __DIR__.'/dnsmanager/includes/webfilter.php';\n/* BLOCKMANAGER_WEBFILTER_BOOTSTRAP_END */\n"
TABS_BLOCK="\n/* BLOCKMANAGER_WEBFILTER_TABS_BEGIN */\n$tabs=array_values(array_unique(array_merge($tabs,bmwf_tabs())));\n/* BLOCKMANAGER_WEBFILTER_TABS_END */\n"
PREP_BLOCK="\n/* BLOCKMANAGER_WEBFILTER_PREPARE_BEGIN */\nif(bmwf_is_tab($tab)){ bmwf_prepare($tab); }\n/* BLOCKMANAGER_WEBFILTER_PREPARE_END */\n"
TITLE_BLOCK="/* BLOCKMANAGER_WEBFILTER_TITLES_BEGIN */,'webfilter'=>'Web Filter - Visão geral','webfilter_policies'=>'Web Filter - Políticas','webfilter_lists'=>'Web Filter - Listas locais','webfilter_sources'=>'Web Filter - Fontes externas','webfilter_logs'=>'Web Filter - Monitor em tempo real','webfilter_status'=>'Web Filter - Status','webfilter_settings'=>'Web Filter - Configuração'/* BLOCKMANAGER_WEBFILTER_TITLES_END */"
PAGE_BLOCK="\n<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->\n<?php if(bmwf_is_tab($tab)) require __DIR__.'/dnsmanager/pages/webfilter.php'; ?>\n<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->\n"

def atomic(path:Path,text:str)->None:
    path.parent.mkdir(parents=True,exist_ok=True);tmp=path.with_name(path.name+'.bmwf-new')
    tmp.write_text(text,encoding='utf-8');os.chmod(tmp,(path.stat().st_mode&0o777) if path.exists() else 0o640);os.replace(tmp,path)
def strip(text:str,a:str,b:str)->str:return re.sub(re.escape(a)+r".*?"+re.escape(b)+r"[ \t]*(?:\r?\n)?","",text,flags=re.S)
def matching(text:str,start:int,op='[',cl=']')->int:
    depth=0;quote=None;esc=False;i=start
    while i<len(text):
        c=text[i]
        if quote:
            if esc:esc=False
            elif c=='\\':esc=True
            elif c==quote:quote=None
        elif c in "'\"":quote=c
        elif text.startswith('//',i):
            n=text.find('\n',i);i=len(text) if n<0 else n;continue
        elif text.startswith('/*',i):
            n=text.find('*/',i+2);i=len(text) if n<0 else n+2;continue
        elif c==op:depth+=1
        elif c==cl:
            depth-=1
            if depth==0:return i
        i+=1
    raise RuntimeError('estrutura PHP sem fechamento balanceado')
def patch_sidebar(text:str)->str:
    text=LEGACY_RE.sub('',text);text=strip(text,SB_BEGIN,SB_END)
    m=re.search(r"(['\"]dns['\"]\s*=>\s*\[)",text)
    if not m:
        lab=re.search(r"['\"]label['\"]\s*=>\s*['\"]DNS (?:Manager|Filter)['\"]",text,re.I)
        if not lab:raise RuntimeError('grupo DNS não localizado na estrutura $menuGroups')
        starts=list(re.finditer(r"['\"][A-Za-z0-9_-]+['\"]\s*=>\s*\[",text[:lab.start()]))
        if not starts:raise RuntimeError('início do grupo DNS não localizado')
        m=starts[-1]
    bracket=text.find('[',m.start());end=matching(text,bracket)+1
    while end<len(text) and text[end].isspace():end+=1
    if end<len(text) and text[end]==',':end+=1
    item=text[m.start():end]
    item2=re.sub(r"(['\"]label['\"]\s*=>\s*['\"])DNS Manager(['\"])",r"\1DNS Filter\2",item,count=1,flags=re.I)
    text=text[:m.start()]+item2+text[end:]
    end2=m.start()+len(item2)
    return text[:end2]+SIDEBAR_BLOCK+text[end2:]
def patch_main(text:str)->str:
    for a,b in [(INC_BEGIN,INC_END),(TABS_BEGIN,TABS_END),(PREP_BEGIN,PREP_END),(TITLE_BEGIN,TITLE_END),(PAGE_BEGIN,PAGE_END),(OLD_PAGE_BEGIN,OLD_PAGE_END)]:text=strip(text,a,b)
    inc=list(re.finditer(r"require_once\s+__DIR__\s*\.\s*['\"]/dnsmanager/includes/[^'\"]+['\"]\s*;",text))
    if not inc:raise RuntimeError('bloco de includes do Block Manager não localizado')
    pos=inc[-1].end();text=text[:pos]+INCLUDE_BLOCK+text[pos:]
    mt=re.search(r"\$tabs\s*=\s*\[.*?\]\s*;(?=\s*\$tab\s*=)",text,re.S)
    if not mt:raise RuntimeError('allowlist $tabs não localizada')
    text=text[:mt.end()]+TABS_BLOCK+text[mt.end():]
    mf=re.search(r"if\s*\(\s*fm_firewall_is_tab\(\$tab\)\s*\)\s*\{[^\n]*\}",text)
    if not mf:raise RuntimeError('ponto de preparação de páginas não localizado')
    text=text[:mf.end()]+PREP_BLOCK+text[mf.end():]
    text=re.sub(r"&&\s*!bmwf_is_tab\(\$tab\)","",text)
    text=re.sub(r"&&\s*!dc_native_is_tab\(\$tab\)\s*\)","&&!dc_native_is_tab($tab)&&!bmwf_is_tab($tab))",text,count=1)
    h=text.find('<h1><?=e([')
    if h<0:raise RuntimeError('mapa de títulos da página não localizado')
    title_end=text.find('][$tab])?>',h)
    if title_end<0:raise RuntimeError('fim do mapa de títulos não localizado')
    text=text[:title_end]+TITLE_BLOCK+text[title_end:]
    close=text.find('</main>',title_end)
    if close<0:raise RuntimeError('fechamento do layout principal não localizado')
    text=text[:close]+PAGE_BLOCK+text[close:]
    return text
def check(sidebar:str,main:str)->None:
    for marker in [SB_BEGIN,SB_END]:
        if sidebar.count(marker)!=1:raise RuntimeError('integração nativa da sidebar ausente ou duplicada')
    if not re.search(r"['\"]dns['\"]\s*=>\s*\[\s*['\"]label['\"]\s*=>\s*['\"]DNS Filter['\"]",sidebar):raise RuntimeError('grupo DNS Filter não identificado')
    if sidebar.find(SB_BEGIN)<sidebar.find("'dns'") or sidebar.find(SB_BEGIN)>sidebar.find("'category_manager'"):raise RuntimeError('Web Filter não está imediatamente após DNS Filter')
    for marker in [INC_BEGIN,TABS_BEGIN,PREP_BEGIN,TITLE_BEGIN,PAGE_BEGIN,PAGE_END]:
        if main.count(marker)!=1:raise RuntimeError('integração do roteador ausente ou duplicada: '+marker)
    if OLD_PAGE_BEGIN in main or OLD_PAGE_END in main:raise RuntimeError('marcador de página legado ainda visível')
    if '&&!dc_native_is_tab($tab)&&!bmwf_is_tab($tab))' not in main:raise RuntimeError('POST do Web Filter ainda alcança o roteador genérico')
    if 'blockmanager_web_filter.php' in sidebar or 'blockmanager_web_filter.php' in main:raise RuntimeError('rota standalone legada ainda referenciada')
    if "/dnsmanager/pages/webfilter.php" not in main:raise RuntimeError('página integrada não registrada')
def main()->int:
    ap=argparse.ArgumentParser();ap.add_argument('--root',default='/');ap.add_argument('--check',action='store_true');a=ap.parse_args();root=Path(a.root).resolve();sp=root/'usr/local/www/dnsmanager/templates/sidebar.php';mp=root/'usr/local/www/block_manager.php'
    try:
        if not sp.is_file() or not mp.is_file():raise RuntimeError('sidebar.php ou block_manager.php ausente')
        original_s=sp.read_text(encoding='utf-8');original_m=mp.read_text(encoding='utf-8')
        if a.check:check(original_s,original_m);print('OK: sidebar nativa e roteador integrado sem depender de href');return 0
        try:
            check(original_s,original_m);print('OK: integração r6 já está correta');return 0
        except RuntimeError:
            pass
        s=patch_sidebar(original_s);m=patch_main(original_m);atomic(sp,s);atomic(mp,m);check(s,m);print('OK: Web Filter integrado com marcadores HTML invisíveis');return 0
    except (OSError,UnicodeError,RuntimeError) as e:print('ERRO:',e);return 1
if __name__=='__main__':raise SystemExit(main())
