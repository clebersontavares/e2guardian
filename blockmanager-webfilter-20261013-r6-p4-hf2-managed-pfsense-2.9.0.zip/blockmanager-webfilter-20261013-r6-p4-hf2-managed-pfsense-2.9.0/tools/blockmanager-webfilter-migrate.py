#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path


def merge(current, defaults):
    out = dict(defaults)
    for key, value in current.items():
        out[key] = merge(value, defaults.get(key, {})) if isinstance(value, dict) and isinstance(defaults.get(key), dict) else value
    return out


parser = argparse.ArgumentParser()
parser.add_argument('--root', default='/')
args = parser.parse_args()
root = Path(args.root)
base = root / 'usr/local/etc/blockmanager/webfilter'
settings_file = base / 'blockmanager-webfilter-settings.json'
defaults = json.loads((base / 'blockmanager-webfilter-settings.example.json').read_text())
current = json.loads(settings_file.read_text()) if settings_file.exists() else {}
out = merge(current, defaults)
old_version = int(current.get('version', 0) or 0)
if old_version < 4:
    old_binary = str(current.get('engine', {}).get('binary', ''))
    if 'squid' in old_binary.lower():
        out['engine']['driver'] = 'squid-legacy'
        out['engine']['config_file'] = str(current.get('engine', {}).get('config_file', '/usr/local/etc/blockmanager/webfilter/generated/engine.conf'))
    else:
        out['engine']['driver'] = 'e2guardian'
        out['engine']['binary'] = '/usr/local/sbin/e2guardian'
        out['engine']['config_file'] = '/usr/local/etc/blockmanager/webfilter/generated/e2guardian.conf'
    out['enabled'] = False
out['version'] = 4
future = out.setdefault('https_inspection', {})
future['implementation_state'] = 'reserved'
future['enabled'] = False
future['activation_gate'] = 'future-validated-release'
future['policy_mode'] = 'separate'
future['default_action'] = 'bypass'
future.setdefault('validation', {})['status'] = 'not_validated'
if out.get('activation', {}).get('https_profile') == 'decrypt':
    out['activation']['https_profile'] = 'off'
    out['enabled'] = False
workers = out.setdefault('http_workers', {})
workers['management_mode'] = 'proposal-only'
workers['auto_adjust'] = False
workers['override_enabled'] = False
if current.get('pilot_group') and not out.get('activation', {}).get('pilot_group'):
    out['activation']['pilot_group'] = current['pilot_group']
legacy = root / 'var/db/blockmanager/webfilter/blockmanager-webfilter-status.json'
status = root / 'var/db/blockmanager/webfilter/status.json'
status.parent.mkdir(parents=True, exist_ok=True)
if legacy.exists() and not status.exists():
    status.write_bytes(legacy.read_bytes())
tmp = settings_file.with_name(settings_file.name + '.new')
tmp.write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
os.chmod(tmp, 0o640)
os.replace(tmp, settings_file)
print('OK: configuração v4 preservada; HTTPS profundo reservado e HTTP Workers mantidos em proposal-only sem ajuste automático')
