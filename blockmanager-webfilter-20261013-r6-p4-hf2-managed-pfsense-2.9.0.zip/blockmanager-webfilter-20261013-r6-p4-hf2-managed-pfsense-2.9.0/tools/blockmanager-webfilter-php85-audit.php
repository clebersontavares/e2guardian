#!/usr/local/bin/php -q
<?php
/** Token-aware PHP 8.5 deprecation audit for Blockmanager Web Filter files only. */

$files = array_slice($argv, 1);
if ($files === []) {
    fwrite(STDERR, "Uso: blockmanager-webfilter-php85-audit.php ARQUIVO.php [...]\n");
    exit(64);
}

$deprecatedFunctions = [
    'curl_close' => true,
    'curl_share_close' => true,
    'finfo_close' => true,
    'imagedestroy' => true,
];
$castTokens = array_filter([
    defined('T_BOOL_CAST') ? T_BOOL_CAST : null,
    defined('T_INT_CAST') ? T_INT_CAST : null,
    defined('T_DOUBLE_CAST') ? T_DOUBLE_CAST : null,
    defined('T_STRING_CAST') ? T_STRING_CAST : null,
], static fn($value): bool => $value !== null);
$nonCanonicalCasts = ['(boolean)', '(integer)', '(double)', '(binary)'];
$errors = [];

foreach ($files as $file) {
    if (!is_file($file)) {
        $errors[] = $file . ': arquivo ausente';
        continue;
    }
    $source = file_get_contents($file);
    if ($source === false) {
        $errors[] = $file . ': falha de leitura';
        continue;
    }
    $tokens = token_get_all($source);
    $count = count($tokens);
    for ($i = 0; $i < $count; $i++) {
        $token = $tokens[$i];
        if (!is_array($token)) {
            continue;
        }
        [$id, $text, $line] = $token;
        if ($id === T_STRING && isset($deprecatedFunctions[strtolower($text)])) {
            $j = $i + 1;
            while ($j < $count && is_array($tokens[$j]) && in_array($tokens[$j][0], [T_WHITESPACE, T_COMMENT, T_DOC_COMMENT], true)) {
                $j++;
            }
            if ($j < $count && $tokens[$j] === '(') {
                $errors[] = $file . ':' . $line . ': chamada depreciada no PHP 8.5: ' . $text . '()';
            }
        }
        if (in_array($id, $castTokens, true)) {
            $normalized = strtolower(preg_replace('/\s+/', '', $text));
            if (in_array($normalized, $nonCanonicalCasts, true)) {
                $errors[] = $file . ':' . $line . ': cast não canônico depreciado no PHP 8.5: ' . trim($text);
            }
        }
    }
}

if ($errors !== []) {
    foreach ($errors as $error) {
        fwrite(STDERR, "ERRO: {$error}\n");
    }
    exit(1);
}

echo 'OK: auditoria PHP 8.5 limitada a ' . count($files) . " arquivos do pacote\n";
