# Adaptação r6 para pfSense CE 2.9.0 / FreeBSD 16-CURRENT

A r6 mantém as correções da r5-p2 para PHP 8.5, rollback, UI integrada e catálogo, e substitui o backend padrão incorreto (Squid) por E2Guardian.

## Baseline confirmado

- pfSense CE 2.9.0;
- FreeBSD 16-CURRENT;
- OpenSSL 3.5.7;
- PHP 8.5.7;
- E2Guardian upstream estável revisado: 5.5.9r;
- port público atualmente usado pela implementação comunitária do pfSense 2.9: 5.3.4.

## Decisões de compatibilidade

- mínimo aceito no runtime: E2Guardian 5.3.4;
- `https_profile=off` por padrão;
- `transparenthttpsport` somente quando HTTPS estiver ativo;
- acesso direto por padrão, sem dependência obrigatória do Squid;
- instalação nativa apenas por bundle offline verificado;
- migração de Squid preservada como `squid-legacy`, com ativação desligada;
- nenhuma criação de links entre bibliotecas incompatíveis;
- nenhuma alteração permanente de repositórios.

## Limites

O código foi preparado fora do pfSense. A validação final exige motor e dependências nativos gerados no ABI alvo, PHP 8.5, PF, rc.d, certificados e tráfego real. Consulte `blockmanager-webfilter-homologacao.md`.
