# Avaliação do Netresec PolarProxy

## Decisão

Não integrar o PolarProxy ao WebFilter r6 e não incluí-lo no bundle do E2Guardian. A arquitetura atual permanece E2Guardian-first, com `squid-legacy` somente para migração.

## Disponibilidade real

O repositório público `Netresec/PolarProxy` declara-se como repositório de **assets and resources**. Na árvore observada existem regras, README, `docker-compose.yml` e variáveis de ambiente, mas não o código-fonte do motor nem um projeto compilável do PolarProxy.

O fabricante distribui o motor como binário autocontido. O manifesto oficial 2.0.2 lista somente RIDs Linux (`linux-x64`, `linux-arm`, `linux-arm64`, `linux-musl-x64`, `linux-musl-arm64`). A imagem oficial no GitHub Container Registry é Linux amd64/arm64. Não foi encontrado binário, port ou instrução oficial para FreeBSD/pfSense.

## Container

Container não é a única forma de execução: existem binários autocontidos para Linux, macOS e Windows. Porém, no pfSense 2.9.0 a opção prática seria um host/container Linux separado, pois pfSense/FreeBSD não fornece Docker como componente suportado e os binários Linux não são ABI FreeBSD.

Portanto, adicionar PolarProxy ao firewall implicaria introduzir runtime/container Linux ou uma VM/host lateral, alterando a arquitetura e o modelo de operação.

### Imagem `jonaslejon/polarproxy`

A imagem do Docker Hub foi atualizada há mais de seis anos. Ela expõe 10080 para distribuição manual da CA raiz e 10443 para inspeção TLS, grava `/pcap/polarproxy.pcap` e exige redirecionamento por `iptables`. Isso é uma receita Linux/container antiga, não um componente reutilizável no FreeBSD.

Ela não fornece ABI FreeBSD, port do pfSense, integração com PF, rc.d, catálogo de identidades ou fail-open do WebFilter. Também é anterior às distribuições oficiais PolarProxy 2.x. Portanto, não será usada nem como dependência nem como origem do motor.

## Papel técnico

PolarProxy é um proxy de inspeção TLS que descriptografa/recriptografa sessões e pode exportar tráfego decriptado para PCAP/IDS. Ele oferece modos transparente, HTTP CONNECT, SOCKS, terminação e inline (`--connect`).

Isso pode complementar um laboratório de segurança ou um sensor IDS externo. Não substitui as políticas, grupos, listas, catálogo de identidades, logs normalizados e controle de ativação do E2Guardian/WebFilter.

Usá-lo em cadeia com E2Guardian criaria dois pontos de MITM e exigiria projeto específico para:

- ordem dos proxies e propriedade da CA;
- preservação de IP/identidade;
- PF/NAT e prevenção de loops;
- falha aberta/fechada coordenada;
- portas, certificados e exceções duplicados;
- CPU, memória, latência e armazenamento de PCAP;
- privacidade e retenção de conteúdo descriptografado.

Sem teste de integração e suporte FreeBSD, não há evidência para tratar PolarProxy como alternativa de runtime no pfSense.

## Restrições operacionais confirmadas pelo artigo da APNIC

O artigo do próprio criador confirma que cada instalação gera uma CA raiz própria. Essa CA precisa ser confiada pelo sistema operacional, navegador e aplicações de todos os clientes inspecionados. Também confirma que aplicações com certificate transparency ou public-key pinning não aceitam o certificado gerado pelo proxy, mesmo quando assinado por uma raiz confiável.

O modo transparente exige uma regra DNAT no firewall para redirecionar o TLS de saída ao proxy. O exemplo publicado usa Linux/iptables e deixa a adaptação a outros firewalls por conta do integrador. No pfSense isso exigiria um segundo conjunto de regras PF, bypasses e estado de fail-open concorrendo com o anchor já controlado pelo WebFilter.

Essas características não são exclusivas do PolarProxy — qualquer MITM exige gestão de CA e exceções —, mas no pacote atual elas duplicariam mecanismos que o E2Guardian já coordena com políticas, piloto e rollback.

## Licenciamento

O artigo da APNIC, escrito pelo criador do PolarProxy em 2021, declara CC BY-ND 4.0 e uso gratuito inclusive comercial. A licença BY-ND permite compartilhamento com atribuição, mas não permite distribuir material adaptado/derivado. Ao mesmo tempo, o repositório atual observado não contém o código-fonte do motor nem um arquivo de licença junto aos ativos, e a versão binária atual é posterior ao artigo.

Assim, existe evidência de licença para uso, porém não há base suficiente para modificar, portar para FreeBSD ou redistribuir a versão atual dentro do pacote sem validar os termos que acompanham o binário 2.x e as obrigações de atribuição. A ausência do código-fonte também inviabiliza a adaptação nativa.

## Impacto no pacote autocontido

A inclusão quebraria os critérios atuais:

- artefato não FreeBSD;
- código do motor não auditável/adaptável;
- licenciamento de redistribuição não comprovado;
- possível dependência de container/host Linux;
- aumento relevante de superfície, CA, chaves e PCAPs;
- ausência de validação em pfSense 2.9.0.

## Uso aceitável

Somente fora do firewall, em laboratório ou sensor Linux separado, para capturar PCAP descriptografado e enviar a Wireshark/IDS. Mesmo nesse cenário, manter fora da rota de produção até concluir avaliação legal, segurança de CA/chaves, privacidade, desempenho e recuperação de falhas.

## Resultado

- alternativa direta ao E2Guardian no pfSense: **não**;
- complemento inline no pacote atual: **não**;
- ferramenta/sensor externo de laboratório: **potencialmente sim**;
- dependência do motor: **não**;
- inclusão no pacote principal: **não**.
