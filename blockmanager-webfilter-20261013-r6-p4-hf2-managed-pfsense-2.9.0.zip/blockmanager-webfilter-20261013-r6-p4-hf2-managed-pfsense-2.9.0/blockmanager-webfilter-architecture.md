# Arquitetura r6-p3 — Web Filter integrado ao Block Manager com E2Guardian

Alvo desta adaptação: pfSense CE 2.9.0, FreeBSD 16-CURRENT e PHP 8.5. O código evita APIs depreciadas no PHP 8.5 e mantém a integração por fragmento com o bootstrap existente do Block Manager.

## Interface e escopo PHP

`/usr/local/www/block_manager.php` permanece como único bootstrap autenticado e documento HTML. A sidebar, o CSS e o bootstrap do Block Manager são reutilizados. A página `/usr/local/www/dnsmanager/pages/webfilter.php` renderiza dentro de uma função própria; nenhuma variável de iteração da view alcança o escopo global do pfSense. Em especial, o array reservado `$g` não é reutilizado.

## Catálogo somente leitura

`blockmanager-identity-catalog-worker.php` lê, sem alterar:

- `/var/unbound/lists/users/*.json`;
- `/var/unbound/lists/device-bindings/*.json`;
- `/var/unbound/lists/networks/*.json`;
- `/var/unbound/lists/groups/*.conf`;
- `/var/unbound/lists/portal/sessions.json`;
- `/var/unbound/lists/group-connectors.json`.

O parser diferencia registros de contêineres e listas. Identidades são deduplicadas e recebem todos os IPs, MACs, grupos e nomes de rede associados. Redes preservam todos os CIDRs válidos. Conectores seguem `sources.pfsense` e `sources.ldap`. O catálogo neutro é gravado em `/var/db/blockmanager/shared/blockmanager-identity-catalog.json`.

## Catálogo externo próprio de categorias

As categorias são derivadas exclusivamente das fontes ativas do Web Filter. O arquivo `/var/db/blockmanager/webfilter/categories/category-catalog.json` usa o contrato `webfilter-external-categories-v1`, mantém referências estáveis e vínculos por grupo e declara `dns_category_reuse=false`. Nenhum caminho de categorias do DNS Manager/Unbound é consultado.

## Estado próprio

- Configuração: `/usr/local/etc/blockmanager/webfilter/`
- Configuração técnica gerada: `/usr/local/etc/blockmanager/webfilter/generated/`
- Políticas: `/usr/local/etc/blockmanager/webfilter/policies/`
- Fontes e listas: `/usr/local/etc/blockmanager/webfilter/sources/` e `lists/`
- Estado: `/var/db/blockmanager/webfilter/`
- Status do worker: `/var/db/blockmanager/webfilter/status.json`
- Status do serviço: `/var/db/blockmanager/webfilter/service-status.json`
- Cache: `/var/cache/blockmanager/webfilter/`
- Logs: `/var/log/blockmanager/webfilter/`
- Locks/PID: `/var/run/blockmanager-webfilter/`

## Compilação e ativação

O worker compila regras com precedência: sessão/usuário 400, dispositivo/IP 300, rede/CIDR 200 e padrão global 100. Todos os IPs e CIDRs deduplicados são materializados.

A ativação é separada em quatro camadas:

1. `blockmanager-webfilter-worker.php`: valida catálogo e compila políticas.
2. `blockmanager-webfilter-engine.php`: detecta o E2Guardian, verifica versão/suporte SSL, deriva a configuração a partir do arquivo-base instalado e executa validação estrutural antes do runtime.
3. `blockmanager-webfilter-traffic.php`: gera e valida um anchor de redirecionamento limitado às interfaces e redes piloto.
4. `blockmanager-webfilter-service.php`: coordena iniciar, parar, recarregar, ativar e desativar.
5. `blockmanager-webfilter-engine-setup.sh`: cria/verifica o bundle offline e valida `pkg`, bibliotecas e auditoria de vulnerabilidades.

A atualização não chama nenhuma dessas ações. A primeira ativação exige modo auditoria, grupo/rede piloto e ação administrativa explícita. `start` não direciona tráfego; apenas `activate` aplica o piloto. `stop` remove o direcionamento antes de parar. Em fail-open, qualquer falha de validação ou recarga remove o anchor.

## HTTP e HTTPS

HTTP usa `filterports` e pode ser direcionado apenas para os CIDRs piloto. HTTPS oferece `off`, `sni` (túnel/SNI sem MITM no grupo) e `decrypt` (MITM com CA). `transparenthttpsport` só existe quando HTTPS está ativo. Perfis SSL exigem motor com suporte SSL, CA, chave da CA e chave para os certificados gerados.

## Isolamento do Unbound

Os caminhos históricos de origem sob `/var/unbound/lists` são usados somente como dados mestres. Nenhum componente executa `unbound-control`, recarrega o Unbound, altera arquivos compilados de DNS ou usa o resolver como mecanismo de decisão do Web Filter.


## Fronteira da inspeção profunda HTTPS

A inspeção profunda é um domínio futuro e separado. A revisão atual fixa `implementation_state=reserved`, `enabled=false`, políticas próprias em `https-policies/`, exceções próprias e ação global `bypass`. A função `bmwf_https_inspection_gate()` é aplicada na biblioteca, no motor, no serviço e no gerador de regras PF; qualquer perfil `decrypt` falha antes de gerar configuração ou alterar tráfego. O schema atual também exclui `decrypt` e a WebGUI apresenta a opção somente como etapa posterior desabilitada.

A CA futura será interna e dedicada, sem reutilização do certificado da WebGUI. Certificado, chave, fingerprint, validações e políticas serão armazenados fora das políticas HTTP/DNS. Nenhum material criptográfico é distribuído nesta revisão. Os contratos e critérios completos estão em `ARQUITETURA-INSPECAO-HTTPS-FUTURA.md`.


## HTTP Workers do E2Guardian

O monitor lê o `dstats.log` moderno (`time httpw busy httpwQ logQ conx conx/s reqs reqs/s maxfd LCcnt`) sem alterar o processo. O limite configurado é descoberto em `httpworkers` ou `maxchildren`; se a diretiva não puder ser lida, o campo `httpw` da amostra é usado como referência informativa. O estado é `alert` quando `Busy >= configured_workers` ou quando `httpwQ > 0` por pelo menos duas amostras consecutivas.

A gestão é deliberadamente separada da aplicação: a WebGUI grava apenas `proposed_workers`, justificativa, autor e estado `pending_validation`. `auto_adjust` e `override_enabled` permanecem falsos. O gerador pode configurar o caminho e o intervalo de `dstats`, mas não possui chamada para reescrever `httpworkers`/`maxchildren`, nem faz reload após salvar uma proposta. Qualquer alteração real deve ocorrer posteriormente, após validação de capacidade de CPU/RAM, série histórica, janela de mudança e rollback.
