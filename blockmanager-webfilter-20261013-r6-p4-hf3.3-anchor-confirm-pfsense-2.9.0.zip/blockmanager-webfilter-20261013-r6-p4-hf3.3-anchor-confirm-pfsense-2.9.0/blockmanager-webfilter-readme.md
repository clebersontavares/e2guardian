# Block Manager Web Filter — r6-p4-hf3.1 Production E2Guardian

Esta revisão usa exclusivamente `/usr/local/sbin/e2guardian`, portas padrão HTTP `8080` e HTTPS transparente `8443`. Instalações com valores legados `3128/3129` são migradas automaticamente; demais portas válidas são preservadas. Não há backend operacional alternativo nem fluxo de teste pré-preenchido.

A WebGUI opera com configuração real de interfaces, grupos, redes, políticas, listas, CA, bypass, compilação, validação, ciclo do motor, ativação explícita, monitoramento e rollback. O modo Auditoria é uma opção operacional real.

Salvar, compilar, validar, iniciar e reiniciar não aplicam redirecionamento. Somente **Ativar piloto** aplica o anchor. Se o anchor estiver ativo sem motor ou listeners esperados, a reconciliação fail-open o remove automaticamente.

# r6-p4-hf2 — gestão prática e tela limpa

Baseline: r6-p4 com menu e PID corrigidos. A revisão adiciona seleção segura da interface física, CA do pfSense ou arquivos existentes, bypass, autenticação IP, watchdog fail-open e mantém blacklists/categorias em telas próprias. **Salvar nunca inicia o E2Guardian e nunca aplica redirecionamento.**

# Blockmanager Web Filter — r6-p4 Categorias externas para pfSense 2.9.0

Pacote **1.0.0-rc6-p4**, derivado da r6-p3, com alvo exclusivo **pfSense CE 2.9.0 / FreeBSD 16-CURRENT / PHP 8.5**.

## Manutenção p4 — frontend e catálogo de categorias

- Catálogo próprio de categorias externas com referências estáveis por fonte, metadados e vínculos por grupo.
- Modos Padrão, Lista branca, Permitir e Negar.
- Botões Salvar e Salvar e aplicar; o segundo compila, valida e aplica com restauração da política anterior em falha.
- Proibição testada de reutilizar categorias DNS/Unbound.
- Consulte `CATEGORIAS-EXTERNAS-WEBFILTER.md`.

## Manutenção p3 — HTTP Workers

- Lê `/var/log/e2guardian/dstats.log` e exibe workers configurados, `Busy`, `httpwQ`, workers livres estimados e idade da amostra.
- Gera alerta quando `Busy` atinge ou supera o limite configurado.
- Considera `httpwQ` persistente quando duas ou mais amostras consecutivas permanecem acima de zero; o limite de persistência fica explícito na configuração.
- O valor configurado é lido de `httpworkers` ou, para compatibilidade, `maxchildren`; quando indisponível, usa o `httpw` reportado pelo próprio `dstats.log`.
- A WebGUI permite registrar somente uma proposta pendente de validação. Salvar a proposta não altera a configuração do E2Guardian e não executa reload ou reinício.
- `management_mode=proposal-only`, `auto_adjust=false` e `override_enabled=false` são protegidos por defaults, schema, migração e testes.
- O gerador configura apenas `dstatlocation` e `dstatinterval=300`; ele nunca reescreve `httpworkers` ou `maxchildren`.

## Manutenção p2 — arquitetura HTTPS futura

- A inspeção profunda HTTPS foi separada da conclusão atual do WebFilter e permanece bloqueada.
- O contrato futuro usa CA interna dedicada, políticas e exceções próprias, ação padrão `bypass` e evidências de validação isoladas.
- `decrypt` não é aceito pelo schema, pela WebGUI, pela biblioteca, pelo motor, pelo serviço nem pela camada de tráfego desta revisão.
- Migrações que encontrem `https_profile=decrypt` convertem o perfil para `off` e desabilitam o módulo até revisão administrativa.
- Nenhum certificado, chave privada ou material de CA é incluído no pacote.
- Consulte `ARQUITETURA-INSPECAO-HTTPS-FUTURA.md` para os gates e testes exigidos na etapa posterior.

## Manutenção p1 — coerência do baseline

- Mantém a configuração v4, o driver E2Guardian, as portas 8080/8443 e HTTPS desativado por padrão.
- Rejeita regressões semânticas para Squid, configuração v3, portas 3128/3129 ou SNI implícito.
- A nova verificação cruza release, exemplo e schema JSON, biblioteca compartilhada, controlador e fragmento WebGUI.
- Inclui o monitor de logs do WebFilter com ingestão do `access.log` do E2Guardian, atualização ao vivo, busca, filtros, pausa, métricas e exportação CSV.
- Não altera o comportamento operacional da r6: serviço, worker, cron e redirecionamento continuam desativados após atualização.

## Estado

- Código WebFilter, migração, adaptador E2Guardian, instalador offline, validações e rollback: incluídos.
- Pacotes nativos do E2Guardian e dependências FreeBSD: **não incluídos neste artefato**, pois não estavam nos materiais disponíveis e não puderam ser obtidos no ambiente de preparação.
- Resultado: candidato para homologação; a instalação offline só é liberada quando `--vendorize` criar o bundle e `--verify-bundle` aprová-lo.

## Correções de compatibilidade

1. O backend padrão deixa de ser Squid e passa a ser `e2guardian`.
2. Os comandos de controle usam a CLI do E2Guardian (`-c`, `-N`, `-q`, `-r`, `-s`).
3. HTTP usa `filterports=8080`; HTTPS transparente usa `transparenthttpsport=8443` somente quando HTTPS está habilitado.
4. Quando `https_profile=off`, a diretiva `transparenthttpsport` é removida, evitando a falha de bind conhecida no E2Guardian 5.3.x.
5. O E2Guardian pode operar sem Squid; `proxyip`/`proxyport` só são emitidos quando `engine.upstream.enabled=true`.
6. A configuração é produzida a partir dos arquivos-base instalados pelo pacote nativo do E2Guardian, preservando parâmetros e storyboards da versão instalada.
7. Migrações de uma instalação antiga com Squid mantêm `driver=squid-legacy`, desabilitam a ativação e exigem mudança explícita para E2Guardian.
8. O pacote não cria links de compatibilidade entre SONAMEs de OpenSSL/libsodium e não altera repositórios permanentemente.

## Instalação do WebFilter

```sh
chmod +x blockmanager-webfilter-*.sh tests/blockmanager-webfilter-tests.sh tools/*.py
./blockmanager-webfilter-update.sh --dry-run
./blockmanager-webfilter-update.sh
```

A atualização cria backup em `/var/backups/blockmanager/webfilter/preinstall-AAAAMMDD-HHMMSS`. Nada é ativado automaticamente.

## Monitor de logs do WebFilter

- O gerador do E2Guardian fixa `loglevel=3`, `logfileformat=6`, `logclientnameandip=on`, `usedashforblank=on` e `loglocation=/var/log/e2guardian/access.log`.
- A fonte `e2guardian_access` vem habilitada na configuração v4 e é lida incrementalmente por inode e offset.
- O parser normaliza os 20 campos tabulados do formato 6, incluindo usuário, IP, URL, método, resposta HTTP, bytes, duração, mensagem, categoria e grupo. JSONL e linhas `chave=valor` continuam aceitas para conectores adicionais.
- A rota integrada coleta novos registros com trava e intervalo mínimo de dois segundos, entrega apenas o delta e mantém até 500 linhas na janela do navegador.
- A WebGUI oferece busca textual, filtros por ação e fonte, pausa/retomada, contadores e exportação CSV da visão filtrada.
- O log normalizado permanece em `/var/log/blockmanager/webfilter/access.log`, com rotação por tamanho; o cursor fica isolado em `/var/db/blockmanager/webfilter/cursors/`.

## Motor e dependências

### Inventário

```sh
./blockmanager-webfilter-engine-setup.sh --detect || true
./blockmanager-webfilter-engine-setup.sh --check
```

### Gerar bundle autocontido no próprio pfSense 2.9.0

```sh
./blockmanager-webfilter-engine-setup.sh --vendorize ./vendor
./blockmanager-webfilter-engine-setup.sh --verify-bundle
```

O `--vendorize` usa `pkg fetch -d e2guardian` para obter o pacote raiz e todas as dependências da arquitetura em uso, gerando `packages.tsv`, `SHA256SUMS` e `COMPLETE`.

### Instalar sem rede e configurar

```sh
./blockmanager-webfilter-engine-setup.sh --install-offline
./blockmanager-webfilter-engine-setup.sh --configure
```

Esses comandos não habilitam o WebFilter nem aplicam regras de tráfego.

## Catálogo, políticas e configuração do motor

```sh
/usr/local/bin/php -q /usr/local/sbin/blockmanager-identity-catalog-worker.php
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-worker.php --sync-identities
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-engine.php generate
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-engine.php test
```

A primeira ativação deve permanecer em `mode=audit`, `fail_open=true` e escopo piloto. O padrão de HTTPS é `off`. A inspeção profunda, a CA interna, as exceções e as políticas de descriptografia estão reservadas para uma versão posterior e não devem ser configuradas nesta entrega.

## Validação completa

```sh
./blockmanager-webfilter-validate.sh \
  --require-engine --require-catalog \
  --webgui-url 'https://ENDERECO:PORTA' \
  --cookie-file /root/pfsense-webgui.cookies \
  --insecure
```

Consulte `COMANDOS-VALIDACAO-E2GUARDIAN.txt`, `COMPATIBILIDADE-E2GUARDIAN-PFSENSE-2.9.0.md`, `AVALIACAO-SSLSCAN.md`, `AVALIACAO-TESTSSL.md` e `AVALIACAO-POLARPROXY.md`. As três ferramentas de diagnóstico permanecem fora das dependências e dos drivers.

## Ativação e rollback

```sh
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-service.php activate
/usr/local/bin/php -q /usr/local/sbin/blockmanager-webfilter-service.php stop
./blockmanager-webfilter-rollback.sh /var/backups/blockmanager/webfilter/preinstall-AAAAMMDD-HHMMSS
```

O `activate` gera e testa a configuração, inicia o motor e aplica apenas o anchor do piloto. Qualquer falha remove o anchor em modo fail-open.
