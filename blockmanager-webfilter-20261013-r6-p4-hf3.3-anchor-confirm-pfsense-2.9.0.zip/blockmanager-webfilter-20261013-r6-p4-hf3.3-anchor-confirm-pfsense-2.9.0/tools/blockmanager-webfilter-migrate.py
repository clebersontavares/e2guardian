#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path


def merge(current, defaults):
    out = dict(defaults)
    for key, value in current.items():
        out[key] = merge(value, defaults.get(key, {})) if isinstance(value, dict) and isinstance(defaults.get(key), dict) else value
    return out


parser = argparse.ArgumentParser()
parser.add_argument('--root', default='/')
args = parser.parse_args()
root = Path(args.root)
base = root / 'usr/local/etc/blockmanager/webfilter'
settings_file = base / 'blockmanager-webfilter-settings.json'
defaults = json.loads((base / 'blockmanager-webfilter-settings.example.json').read_text())
current = json.loads(settings_file.read_text()) if settings_file.exists() else {}
out = merge(current, defaults)
old_version = int(current.get('version', 0) or 0)
if old_version < 4:
    out['enabled'] = False
# This product package is E2Guardian-only. Never inherit a stale Squid backend.
engine = out.setdefault('engine', {})
engine['driver'] = 'e2guardian'
engine['binary'] = '/usr/local/sbin/e2guardian'
engine['config_file'] = '/usr/local/etc/blockmanager/webfilter/generated/e2guardian.conf'
engine.pop('upstream', None)
backend = out.setdefault('backend', {})
backend['pid_file'] = '/var/run/blockmanager-webfilter/e2guardian.pid'
activation = out.setdefault('activation', {})
http_port = int(activation.get('http_port', 8080) or 8080)
https_port = int(activation.get('https_port', 8443) or 8443)
activation['http_port'] = 8080 if http_port == 3128 or not 1024 <= http_port <= 65535 else http_port
activation['https_port'] = 8443 if https_port == 3129 or not 1024 <= https_port <= 65535 else https_port
controller = '/usr/local/sbin/blockmanager-webfilter-engine.php'
for action in ('start', 'stop', 'reload', 'status', 'test'):
    backend[action + '_argv'] = ['/usr/local/bin/php', '-q', controller, action]
out['version'] = 4
future = out.setdefault('https_inspection', {})
future['implementation_state'] = 'reserved'
future['enabled'] = False
future['activation_gate'] = 'future-validated-release'
future['policy_mode'] = 'separate'
future['default_action'] = 'bypass'
future.setdefault('validation', {})['status'] = 'not_validated'
if out.get('activation', {}).get('https_profile') == 'decrypt':
    out['activation']['https_profile'] = 'off'
    out['enabled'] = False
workers = out.setdefault('http_workers', {})
workers['management_mode'] = 'proposal-only'
workers['auto_adjust'] = False
workers['override_enabled'] = False
if current.get('pilot_group') and not out.get('activation', {}).get('pilot_group'):
    out['activation']['pilot_group'] = current['pilot_group']
legacy = root / 'var/db/blockmanager/webfilter/blockmanager-webfilter-status.json'
status = root / 'var/db/blockmanager/webfilter/status.json'
status.parent.mkdir(parents=True, exist_ok=True)
if legacy.exists() and not status.exists():
    status.write_bytes(legacy.read_bytes())
tmp = settings_file.with_name(settings_file.name + '.new')
tmp.write_text(json.dumps(out, ensure_ascii=False, indent=2) + '\n')
os.chmod(tmp, 0o640)
os.replace(tmp, settings_file)
print('OK: configuração v4 preservada; HTTPS profundo reservado e HTTP Workers mantidos em proposal-only sem ajuste automático')
