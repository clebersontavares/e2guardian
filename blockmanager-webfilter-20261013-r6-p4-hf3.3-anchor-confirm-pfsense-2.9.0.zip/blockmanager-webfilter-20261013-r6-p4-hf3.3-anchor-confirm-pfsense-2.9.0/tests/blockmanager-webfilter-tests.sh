#!/bin/sh
set -eu

BASE=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
TMP=${TMPDIR:-/tmp}/blockmanager-webfilter-r6-p4-tests.$$
SERVER_PID=
cleanup() {
    [ -z "$SERVER_PID" ] || kill "$SERVER_PID" 2>/dev/null || true
    rm -rf "$TMP"
}
trap cleanup 0 1 2 15

mkdir -p \
    "$TMP/root/etc" \
    "$TMP/root/usr/local/www/dnsmanager/templates" \
    "$TMP/root/usr/local/www/dnsmanager/includes" \
    "$TMP/root/usr/local/www/dnsmanager/pages" \
    "$TMP/root/usr/local/www/blockmanager-webfilter" \
    "$TMP/root/usr/local/etc/blockmanager/webfilter" \
    "$TMP/root/var/unbound/lists/users" \
    "$TMP/root/var/unbound/lists/device-bindings" \
    "$TMP/root/var/unbound/lists/networks" \
    "$TMP/root/var/unbound/lists/groups" \
    "$TMP/root/var/unbound/lists/portal"

printf '%s\n' '2.9.0-RELEASE' >"$TMP/root/etc/version"
cat >"$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" <<'PHP'
<?php
$menuGroups=[
 'dashboard'=>['label'=>'Dashboard','icon'=>'dashboard','items'=>[['tab'=>'dashboard','label'=>'Visão geral']]],
 'dns'=>['label'=>'DNS Manager','icon'=>'dns','items'=>[
  ['tab'=>'categories','label'=>'Políticas'],['tab'=>'infra','label'=>'Infra DNS']]],
 'category_manager'=>['label'=>'Categorias','icon'=>'categories','items'=>[['tab'=>'category_catalog','label'=>'Catálogo']]],
];
$activeGroup='dashboard';foreach($menuGroups as$gid=>$group){foreach($group['items']as$item){if(($item['tab']??'')===($tab??'')){$activeGroup=$gid;break 2;}}}
?><aside class="side"><nav><?php foreach($menuGroups as$gid=>$group):?><section class="forti-group"><button class="forti-group-button"><?=$group['label']?></button><div class="forti-submenu"><?php foreach($group['items']as$item):?><a class="forti-subitem" href="?tab=<?=rawurlencode($item['tab'])?>"><?=$item['label']?></a><?php endforeach;?></div></section><?php endforeach;?></nav></aside>
<!-- BLOCKMANAGER_WEBFILTER_MENU_BEGIN --><?php require '/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-menu.php'; ?><!-- BLOCKMANAGER_WEBFILTER_MENU_END -->
PHP
cat >"$TMP/root/usr/local/www/block_manager.php" <<'PHP'
<?php
require_once("guiconfig.inc");define('DNSM_V1462_BOOTSTRAPPED',true);
require_once __DIR__.'/dnsmanager/includes/core.php';
require_once __DIR__.'/dnsmanager/includes/categories_native.php';
if(isset($_GET['portal']))portal_render();
$tabs=['dashboard','config','category_catalog'];$tab=$_GET['tab']??'dashboard';if(!in_array($tab,$tabs,true))$tab='dashboard';$message='';$message_type='info';
if(dc_native_is_tab($tab)){ dc_native_prepare($tab); }
if(fm_firewall_is_tab($tab)){ fm_firewall_prepare($tab); }
if($_SERVER['REQUEST_METHOD']==='POST'&&!fm_firewall_is_tab($tab)&&!dc_native_is_tab($tab)){$action=$_POST['action']??'';}
$branding=['product_name'=>'Block Manager'];$ui=['theme'=>'classic','mode'=>'dark','language'=>'pt_BR'];
?><!doctype html><html><head><link rel="stylesheet" href="/dnsmanager/assets/css/dnsmanager.css"></head><body><div class="app"><?php require __DIR__.'/dnsmanager/templates/sidebar.php'; ?><main class="main"><div class="top"><h1><?=e(['dashboard'=>'Visão geral','config'=>'Configuração','category_catalog'=>'Categorias'][$tab])?></h1></div>
<?php if($tab==='config') require __DIR__.'/dnsmanager/pages/config.php'; ?>
</main></div><script src="/dnsmanager/assets/js/app.js"></script></body></html>
PHP
cat >"$TMP/root/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" <<'JSON'
{"version":1,"enabled":true,"mode":"audit","pilot_group":"LEGADO","activation":{"https_profile":"decrypt"},"http_workers":{"management_mode":"automatic","auto_adjust":true,"override_enabled":true,"proposed_workers":999},"backend":{"start_argv":[]}}
JSON
mkdir -p "$TMP/root/usr/local/etc/blockmanager/webfilter/policies"
printf '%s\n' '{"id":"rede-filial","scope":{"network_cidrs":["10.20.0.0/16"]},"action":"allow"}' >"$TMP/root/usr/local/etc/blockmanager/webfilter/policies/rede-filial.json"
printf '%s\n' '10.20.0.0/16' >"$TMP/root/var/unbound/lists/groups/filiais.conf"
printf '%s\n' '{"id":"filiais","cidrs":["10.20.0.0/16"]}' >"$TMP/root/var/unbound/lists/networks/filiais.json"
printf '%s\n' '<?php echo "standalone legado";' >"$TMP/root/usr/local/www/blockmanager_web_filter.php"
printf '%s\n' '<?php echo "menu legado";' >"$TMP/root/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-menu.php"

BEFORE_MAIN=$(sha256sum "$TMP/root/usr/local/www/block_manager.php" | awk '{print $1}')
BEFORE_SIDE=$(sha256sum "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | awk '{print $1}')
BEFORE_SETTINGS=$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" | awk '{print $1}')
BEFORE_POLICY=$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/policies/rede-filial.json" | awk '{print $1}')
BEFORE_GROUP=$(sha256sum "$TMP/root/var/unbound/lists/groups/filiais.conf" | awk '{print $1}')
BEFORE_NETWORK=$(sha256sum "$TMP/root/var/unbound/lists/networks/filiais.json" | awk '{print $1}')

for f in "$BASE"/*.sh "$BASE"/tests/*.sh "$BASE"/usr/local/etc/rc.d/*; do sh -n "$f"; done
python3 -m py_compile "$BASE/tools/"*.py "$BASE/tests/blockmanager-webfilter-baseline-test.py"
python3 "$BASE/tests/blockmanager-webfilter-baseline-test.py"
find "$BASE/usr/local/etc/blockmanager/webfilter" -type f -name '*.json' -exec python3 -m json.tool {} \; >/dev/null
! find "$BASE" -type f \( -name '*.pem' -o -name '*.key' -o -name '*.crt' -o -name '*.p12' -o -name '*.pfx' \) | grep -q .
! grep -RIn '2\.8\.1' "$BASE" >/dev/null
grep -Fq '2.9.0*)' "$BASE/blockmanager-webfilter-install.sh"
grep -Fq '2.9.0*)' "$BASE/blockmanager-webfilter-validate.sh"
grep -Fq "'e2guardian'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "transparenthttpsport" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "logfileformat','6'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "'/var/log/e2guardian/access.log'" "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwf_normalize_e2guardian_event' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwf_collect_logs_throttled' "$BASE/usr/local/www/dnsmanager/includes/webfilter.php"
grep -Fq 'bmwfExportCsv' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'bmwf_http_workers_snapshot' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwf_http_workers_parse_dstat' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwf_save_http_workers_proposal' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwfWorkersConfigured' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'bmwfWorkersBusy' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'bmwfWorkersQueue' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq "'dstatlocation'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq "'dstatinterval'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
! grep -Fq "bmwf_engine_set_directive(\$main,'httpworkers'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
! grep -Fq "bmwf_engine_set_directive(\$main,'maxchildren'" "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq 'option value="decrypt" disabled' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'Lista branca' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'Salvar e aplicar' "$BASE/usr/local/www/dnsmanager/pages/webfilter.php"
grep -Fq 'bmwf_save_apply_policy' "$BASE/usr/local/www/dnsmanager/includes/webfilter.php"
! grep -RIn '/var/unbound/lists/categories' "$BASE/usr/local/www/blockmanager-webfilter" "$BASE/usr/local/sbin/blockmanager-webfilter-worker.php" >/dev/null
grep -Fq 'function bmwf_https_inspection_gate' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'bmwf_https_inspection_gate($settings)' "$BASE/usr/local/sbin/blockmanager-webfilter-engine.php"
grep -Fq 'bmwf_https_inspection_gate($settings)' "$BASE/usr/local/sbin/blockmanager-webfilter-service.php"
grep -Fq 'bmwf_https_inspection_gate($settings)' "$BASE/usr/local/sbin/blockmanager-webfilter-traffic.php"
grep -Fq '"implementation_state": "reserved"' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq '"default_action": "bypass"' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq 'offline_bundle_complete' "$BASE/vendor/dependency-lock.json"
! grep -Fq 'BMWF_ENGINE_PACKAGE:-squid' "$BASE/blockmanager-webfilter-engine-setup.sh"
! grep -REq 'curl_(close|share_close)[[:space:]]*\(|finfo_close[[:space:]]*\(|imagedestroy[[:space:]]*\(|\((boolean|integer|double|binary)\)' \
    "$BASE/usr/local/www" "$BASE/usr/local/sbin" \
    "$BASE/tools/blockmanager-webfilter-migrate.php" \
    "$BASE/tools/blockmanager-webfilter-patch-ui.php" \
    "$BASE/tools/blockmanager-webfilter-validate-catalog.php"
if command -v php >/dev/null 2>&1; then
    find "$BASE" -type f -name '*.php' -exec php -l {} \; >/dev/null
    php "$BASE/tests/blockmanager-webfilter-page-scope-test.php" \
        "$BASE/usr/local/www/dnsmanager/pages/webfilter.php" >"$TMP/page-scope.log"
    grep -Fq 'all seven routes preserve pfSense reserved global' "$TMP/page-scope.log"
    php "$BASE/tests/blockmanager-webfilter-log-monitor-test.php" >"$TMP/log-monitor.log"
    grep -Fq 'monitor parses E2Guardian format 6' "$TMP/log-monitor.log"
    php "$BASE/tests/blockmanager-webfilter-http-workers-test.php" >"$TMP/http-workers.log"
    grep -Fq 'configured/Busy/httpwQ monitoring' "$TMP/http-workers.log"
    php "$BASE/tests/blockmanager-webfilter-category-catalog-test.php" >"$TMP/category-catalog.log"
    grep -Fq 'isolated external category catalog' "$TMP/category-catalog.log"
fi

# O instalador deve rejeitar qualquer versão fora do alvo, inclusive em fixture.
printf '%s\n' '2.9.1-RELEASE' >"$TMP/root/etc/version"
if "$BASE/blockmanager-webfilter-update.sh" --root "$TMP/root" --dry-run >"$TMP/version-reject.log" 2>&1; then
    echo 'ERRO: versão fora de 2.9.0 deveria ser rejeitada' >&2
    exit 1
fi
grep -Fq 'validado exclusivamente para pfSense 2.9.0' "$TMP/version-reject.log"
printf '%s\n' '2.9.0-RELEASE' >"$TMP/root/etc/version"

"$BASE/blockmanager-webfilter-update.sh" --root "$TMP/root" --dry-run >"$TMP/dry.log"
grep -Fq 'Plano incremental r6-p4-hf3.3-anchor-confirm' "$TMP/dry.log"
[ "$BEFORE_MAIN" = "$(sha256sum "$TMP/root/usr/local/www/block_manager.php" | awk '{print $1}')" ]
[ "$BEFORE_SIDE" = "$(sha256sum "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | awk '{print $1}')" ]
[ "$BEFORE_SETTINGS" = "$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" | awk '{print $1}')" ]
[ "$BEFORE_POLICY" = "$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/policies/rede-filial.json" | awk '{print $1}')" ]
[ "$BEFORE_GROUP" = "$(sha256sum "$TMP/root/var/unbound/lists/groups/filiais.conf" | awk '{print $1}')" ]
[ "$BEFORE_NETWORK" = "$(sha256sum "$TMP/root/var/unbound/lists/networks/filiais.json" | awk '{print $1}')" ]

"$BASE/blockmanager-webfilter-update.sh" --root "$TMP/root" >"$TMP/install.log"
BACKUP=$(sed -n 's/^Instalação r6-p4-hf3.3-anchor-confirm concluída\. Backup\/rollback: //p' "$TMP/install.log" | tail -1)
[ -d "$BACKUP" ]
[ ! -e "$TMP/root/usr/local/www/blockmanager_web_filter.php" ]
[ ! -e "$TMP/root/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-menu.php" ]
[ -f "$TMP/root/usr/local/etc/blockmanager/webfilter/https-policies/blockmanager-webfilter-https-inspection-policy.schema.json" ]
[ -f "$TMP/root/usr/local/etc/blockmanager/webfilter/lists/blockmanager-webfilter-https-inspection-exceptions.schema.json" ]
grep -Fq "'webfilter'=>['label'=>'Web Filter'" "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php"
[ "$(grep -c BLOCKMANAGER_WEBFILTER_SIDEBAR_BEGIN "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php")" -eq 1 ]
DNS=$(grep -n "'dns'=>" "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | cut -d: -f1)
WEB=$(grep -n BLOCKMANAGER_WEBFILTER_SIDEBAR_BEGIN "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | cut -d: -f1)
CAT=$(grep -n "'category_manager'=>" "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | cut -d: -f1)
[ "$DNS" -lt "$WEB" ] && [ "$WEB" -lt "$CAT" ]
grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->' "$TMP/root/usr/local/www/block_manager.php"
grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->' "$TMP/root/usr/local/www/block_manager.php"
! grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */' "$TMP/root/usr/local/www/block_manager.php"
! grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_END */' "$TMP/root/usr/local/www/block_manager.php"
grep -Fq 'bmwf_tabs()' "$TMP/root/usr/local/www/block_manager.php"
[ "$(grep -Fo '!bmwf_is_tab($tab)' "$TMP/root/usr/local/www/block_manager.php" | wc -l | tr -d ' ')" -eq 1 ]

python3 - <<PY
import json
p='$TMP/root/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json'
x=json.load(open(p))
assert x['version']==4 and x['enabled'] is False and x['pilot_group']=='LEGADO'
assert 'logging' in x and 'blacklists' in x and 'activation' in x and 'engine' in x
assert x['activation']['pilot_group']=='LEGADO'
assert x['engine']['driver']=='e2guardian'
assert x['activation']['https_profile']=='off'
assert x['https_inspection']['implementation_state']=='reserved'
assert x['https_inspection']['enabled'] is False
assert x['https_inspection']['policy_mode']=='separate'
assert x['https_inspection']['default_action']=='bypass'
assert x['https_inspection']['validation']['status']=='not_validated'
assert x['http_workers']['management_mode']=='proposal-only'
assert x['http_workers']['auto_adjust'] is False
assert x['http_workers']['override_enabled'] is False
assert x['http_workers']['dstat_interval_seconds']==300
PY
[ "$BEFORE_POLICY" = "$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/policies/rede-filial.json" | awk '{print $1}')" ]
[ "$BEFORE_GROUP" = "$(sha256sum "$TMP/root/var/unbound/lists/groups/filiais.conf" | awk '{print $1}')" ]
[ "$BEFORE_NETWORK" = "$(sha256sum "$TMP/root/var/unbound/lists/networks/filiais.json" | awk '{print $1}')" ]
[ ! -e "$TMP/root/var/run/blockmanager/webfilter" ]

# Estruturas reais: objeto único, contêiner/lista, binding, rede, sessão e conectores aninhados.
cat >"$TMP/root/var/unbound/lists/users/alice.json" <<'JSON'
{"username":"alice","name":"Alice","identification_mode":"mac","group":"Grupo_A","groups":["Grupo_A"],"ips":["192.0.2.10"],"macs":["00-11-22-33-44-55"],"allowed_networks":["Rede_Local"]}
JSON
cat >"$TMP/root/var/unbound/lists/users/imported.json" <<'JSON'
{"users":[{"username":"alice","name":"Alice Duplicada","ips":["192.0.2.11"],"groups":["Grupo_A"]},{"username":"bob","name":"Bob","ip":"198.51.100.20","group":"Grupo_B"}]}
JSON
cat >"$TMP/root/var/unbound/lists/device-bindings/alice.json" <<'JSON'
{"device":"alice","ip":"192.0.2.12","mac":"00:11:22:33:44:66","status":"active"}
JSON
cat >"$TMP/root/var/unbound/lists/networks/Rede_Local.json" <<'JSON'
{"name":"Rede_Local","cidr":"192.0.2.0/24","group":"Grupo_A"}
JSON
cat >"$TMP/root/var/unbound/lists/networks/Rede_VPN.json" <<'JSON'
{"id":"Rede_VPN","name":"Rede_VPN","cidrs":["198.51.100.0/24"],"groups":["Grupo_B"]}
JSON
cat >"$TMP/root/var/unbound/lists/portal/sessions.json" <<'JSON'
{"192.0.2.50":{"username":"alice","identity":"Alice","group":"Grupo_A","expires_ts":4102444800}}
JSON
printf '# group\n' >"$TMP/root/var/unbound/lists/groups/Grupo_A.conf"
printf '# group\n' >"$TMP/root/var/unbound/lists/groups/Grupo_B.conf"
cat >"$TMP/root/var/unbound/lists/group-connectors.json" <<'JSON'
{"Grupo_A":{"sources":{"pfsense":{"users":[],"groups":[]},"ldap":{"server":"","containers":[],"groups":[]}}},"Grupo_C":{"sources":{"pfsense":{"users":["alice"],"groups":[]},"ldap":{"server":"AD","containers":["OU=Equipe,DC=example,DC=invalid"],"groups":[]}}}}
JSON
if command -v php >/dev/null 2>&1; then
    php -q "$TMP/root/usr/local/sbin/blockmanager-identity-catalog-worker.php" --root "$TMP/root" >"$TMP/catalog-run.json"
    php -q "$BASE/tools/blockmanager-webfilter-validate-catalog.php" \
        --file "$TMP/root/var/db/blockmanager/shared/blockmanager-identity-catalog.json" \
        --expect-groups 4 --expect-identities 2 --expect-networks 2 --expect-sessions 1 --expect-connector-groups 2 >"$TMP/catalog-validation.json"
    python3 - "$TMP/root/var/db/blockmanager/shared/blockmanager-identity-catalog.json" <<'PY'
import json,sys
x=json.load(open(sys.argv[1]))
assert not ({'groups','ips','macs','allowed_networks'} & {i['id'].lower() for i in x['identities']})
alice=next(i for i in x['identities'] if i['username']=='alice')
assert alice['ips']==['192.0.2.10','192.0.2.11','192.0.2.12']
assert alice['macs']==['00:11:22:33:44:55','00:11:22:33:44:66']
assert set(alice['groups'])=={'Grupo_A','Grupo_C'}
assert {n['name'] for n in x['networks']}=={'Rede_Local','Rede_VPN'}
PY
    BMWF_ROOT="$TMP/root" php -q "$TMP/root/usr/local/sbin/blockmanager-webfilter-worker.php" --root "$TMP/root" >"$TMP/worker-run.json"
    [ -f "$TMP/root/var/db/blockmanager/webfilter/status.json" ]
    [ ! -f "$TMP/root/var/db/blockmanager/webfilter/blockmanager-webfilter-status.json" ]
fi
"$BASE/blockmanager-webfilter-validate.sh" --root "$TMP/root" >"$TMP/validate-local.log"

# Um PHP externo e realmente depreciado em /usr/local/sbin não pertence ao
# pacote e não pode reprovar a validação. O PHP falso registra somente os
# arquivos entregues ao lint/auditor para comprovar o escopo fechado.
cat >"$TMP/root/usr/local/sbin/componente-externo.php" <<'PHP'
<?php
curl_close($handle);
PHP
mkdir -p "$TMP/fake-php-bin"
cat >"$TMP/fake-php-bin/php" <<'SH'
#!/bin/sh
set -eu
printf '%s\n' "$*" >>"$BMWF_FAKE_PHP_LOG"
case "${1:-}" in
    -r) printf '%s' 80500 ;;
    -l) : ;;
    -q) : ;;
esac
exit 0
SH
chmod +x "$TMP/fake-php-bin/php"
BMWF_FAKE_PHP_LOG="$TMP/fake-php.log" PATH="$TMP/fake-php-bin:$PATH" \
    "$BASE/blockmanager-webfilter-validate.sh" --root "$TMP/root" >"$TMP/validate-closed-scope.log"
grep -Fq 'blockmanager-webfilter-worker.php' "$TMP/fake-php.log"
grep -Fq 'blockmanager-webfilter-php85-audit.php' "$TMP/fake-php.log"
! grep -Fq 'componente-externo.php' "$TMP/fake-php.log"
grep -Fq 'sem construções realmente depreciadas do PHP 8.5 no payload' "$TMP/validate-closed-scope.log"

# Simula uma instalação r3 já aplicada e confirma a migração automática do marcador visível.
python3 - "$TMP/root/usr/local/www/block_manager.php" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
s=s.replace('<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->','/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */')
s=s.replace('<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->','/* BLOCKMANAGER_WEBFILTER_PAGE_END */')
p.write_text(s)
PY
sleep 1
"$BASE/blockmanager-webfilter-update.sh" --root "$TMP/root" >"$TMP/upgrade-r3.log"
grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->' "$TMP/root/usr/local/www/block_manager.php"
! grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */' "$TMP/root/usr/local/www/block_manager.php"
[ "$(grep -Fo '!bmwf_is_tab($tab)' "$TMP/root/usr/local/www/block_manager.php" | wc -l | tr -d ' ')" -eq 1 ]

# Confirma equivalência do patcher PHP usado no pfSense.
if command -v php >/dev/null 2>&1; then
    cp -Rp "$TMP/root" "$TMP/root-php"
    python3 - "$TMP/root-php/usr/local/www/block_manager.php" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]);s=p.read_text()
s=s.replace('<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->','/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */')
s=s.replace('<!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->','/* BLOCKMANAGER_WEBFILTER_PAGE_END */')
p.write_text(s)
PY
    php -q "$BASE/tools/blockmanager-webfilter-patch-ui.php" --root "$TMP/root-php" >/dev/null
    grep -Fq '<!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN -->' "$TMP/root-php/usr/local/www/block_manager.php"
    ! grep -Fq '/* BLOCKMANAGER_WEBFILTER_PAGE_BEGIN */' "$TMP/root-php/usr/local/www/block_manager.php"
fi

SUM1=$(sha256sum "$TMP/root/usr/local/www/block_manager.php" "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php")
sleep 1
"$BASE/blockmanager-webfilter-update.sh" --root "$TMP/root" >/dev/null
SUM2=$(sha256sum "$TMP/root/usr/local/www/block_manager.php" "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php")
[ "$SUM1" = "$SUM2" ]

# WebGUI em porta e prefixo de caminho não padrão.
if command -v curl >/dev/null 2>&1; then
    PORT_FILE="$TMP/http.port"
    REQUEST_FILE="$TMP/http.request"
    python3 - "$PORT_FILE" "$REQUEST_FILE" <<'PY' &
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
import sys
port_file, request_file = map(Path, sys.argv[1:])
class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        with request_file.open('a') as fh:
            fh.write(self.path + '\n')
        route = self.path.partition('?tab=')[2]
        routes = {'webfilter','webfilter_policies','webfilter_lists','webfilter_sources','webfilter_logs','webfilter_status','webfilter_settings'}
        if self.path.startswith('/pfsense/block_manager.php?tab=') and route in routes:
            body = ('<!doctype html><!-- BLOCKMANAGER_WEBFILTER_PAGE_BEGIN --><div data-bmwf-integrated="1" data-bmwf-route="%s">ok</div><!-- BLOCKMANAGER_WEBFILTER_PAGE_END -->' % route).encode()
            self.send_response(200)
            self.send_header('Content-Type','text/html; charset=utf-8')
            self.send_header('Content-Length',str(len(body)))
            self.end_headers(); self.wfile.write(body)
        else:
            self.send_response(404); self.end_headers()
    def log_message(self, *args): pass
server=HTTPServer(('127.0.0.1',0),Handler)
port_file.write_text(str(server.server_port))
server.serve_forever()
PY
    SERVER_PID=$!
    i=0
    while [ ! -s "$PORT_FILE" ]; do i=$((i+1)); [ "$i" -lt 100 ] || exit 1; sleep 0.05; done
    PORT=$(cat "$PORT_FILE")
    "$BASE/blockmanager-webfilter-validate.sh" \
        --root "$TMP/root" \
        --webgui-url "http://127.0.0.1:$PORT/pfsense" \
        --webgui-path '/block_manager.php' \
        --cookie 'PHPSESSID=test' >"$TMP/validate-webgui.log"
    for route in webfilter webfilter_policies webfilter_lists webfilter_sources webfilter_logs webfilter_status webfilter_settings; do
        grep -Fq "/pfsense/block_manager.php?tab=$route" "$REQUEST_FILE"
        grep -Fq "HTTP 200 na rota $route" "$TMP/validate-webgui.log"
        grep -Fq "rota $route sem erro PHP/CSRF" "$TMP/validate-webgui.log"
    done
    kill "$SERVER_PID" 2>/dev/null || true
    wait "$SERVER_PID" 2>/dev/null || true
    SERVER_PID=

    if "$BASE/blockmanager-webfilter-validate.sh" \
        --root "$TMP/root" \
        --webgui-url "http://127.0.0.1:$PORT/pfsense/block_manager.php?tab=webfilter" \
        --cookie 'PHPSESSID=test' >"$TMP/validate-curl-fail.log" 2>&1; then
        echo 'ERRO: falha curl deveria reprovar a validação' >&2
        exit 1
    fi
    grep -Fq 'falha de conexão WebGUI' "$TMP/validate-curl-fail.log"
    ! grep -Eq 'grep: .*body.*(No such file|não existe)' "$TMP/validate-curl-fail.log"
fi

"$BASE/blockmanager-webfilter-rollback.sh" "$BACKUP" --root "$TMP/root" >/dev/null
[ "$BEFORE_MAIN" = "$(sha256sum "$TMP/root/usr/local/www/block_manager.php" | awk '{print $1}')" ]
[ "$BEFORE_SIDE" = "$(sha256sum "$TMP/root/usr/local/www/dnsmanager/templates/sidebar.php" | awk '{print $1}')" ]
[ "$BEFORE_SETTINGS" = "$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.json" | awk '{print $1}')" ]
[ "$BEFORE_POLICY" = "$(sha256sum "$TMP/root/usr/local/etc/blockmanager/webfilter/policies/rede-filial.json" | awk '{print $1}')" ]
[ "$BEFORE_GROUP" = "$(sha256sum "$TMP/root/var/unbound/lists/groups/filiais.conf" | awk '{print $1}')" ]
[ "$BEFORE_NETWORK" = "$(sha256sum "$TMP/root/var/unbound/lists/networks/filiais.json" | awk '{print $1}')" ]
[ -f "$TMP/root/usr/local/www/blockmanager_web_filter.php" ]

# Regressão do rollback do crontab: restauração via stdin evita truncamento
# do caminho "blockmanager-webfilter-crontab.before" para ".befo".
FAKE_CRONTAB="$TMP/fake-crontab"
cat >"$FAKE_CRONTAB" <<'SH'
#!/bin/sh
set -eu
printf '%s\n' "$*" >"$BMWF_CRONTAB_ARGS"
if [ "${1:-}" = - ]; then cat >"$BMWF_CRONTAB_STDIN"; fi
exit 0
SH
chmod +x "$FAKE_CRONTAB"
CRON_BACKUP="$TMP/cron-backup-with-a-deliberately-long-directory-name-for-pfsense"
mkdir -p "$CRON_BACKUP/rootfs" "$TMP/cron-root"
: >"$CRON_BACKUP/blockmanager-webfilter-install-manifest.tsv"
printf '%s\n' present >"$CRON_BACKUP/blockmanager-webfilter-crontab.state"
printf '%s\n' '17 * * * * /usr/local/bin/existing-job' >"$CRON_BACKUP/blockmanager-webfilter-crontab.before"
BMWF_TEST_CRONTAB_ROLLBACK=1 \
BMWF_CRONTAB_CMD="$FAKE_CRONTAB" \
BMWF_CRONTAB_ARGS="$TMP/crontab.args" \
BMWF_CRONTAB_STDIN="$TMP/crontab.stdin" \
    "$BASE/blockmanager-webfilter-rollback.sh" "$CRON_BACKUP" --root "$TMP/cron-root" >"$TMP/cron-present.log" 2>&1
[ "$(cat "$TMP/crontab.args")" = '-' ]
cmp "$CRON_BACKUP/blockmanager-webfilter-crontab.before" "$TMP/crontab.stdin"
! grep -Fq 'No such file or directory' "$TMP/cron-present.log"
! grep -Fq '.befo' "$TMP/cron-present.log"

printf '%s\n' empty >"$CRON_BACKUP/blockmanager-webfilter-crontab.state"
rm -f "$CRON_BACKUP/blockmanager-webfilter-crontab.before" "$TMP/crontab.stdin"
BMWF_TEST_CRONTAB_ROLLBACK=1 \
BMWF_CRONTAB_CMD="$FAKE_CRONTAB" \
BMWF_CRONTAB_ARGS="$TMP/crontab.args" \
BMWF_CRONTAB_STDIN="$TMP/crontab.stdin" \
    "$BASE/blockmanager-webfilter-rollback.sh" "$CRON_BACKUP" --root "$TMP/cron-root" >"$TMP/cron-empty.log" 2>&1
[ "$(cat "$TMP/crontab.args")" = '-r' ]
[ ! -e "$TMP/crontab.stdin" ]
! grep -Fq 'No such file or directory' "$TMP/cron-empty.log"
! grep -RInE 'crontab[[:space:]]+"?\$BACKUP/blockmanager-webfilter-crontab\.before' "$BASE" >/dev/null
grep -Fq '"$crontab_cmd" - <"$before_file"' "$BASE/blockmanager-webfilter-rollback.sh"
grep -Fq '"$crontab_cmd" -r' "$BASE/blockmanager-webfilter-rollback.sh"

! grep -Rni 'blockmanager_web_filter.php' "$BASE/usr/local/www/dnsmanager" >/dev/null
! grep -Eiq 'unbound-control|unbound-checkconf|dnsmanager-worker\.php|resolver\.log|/var/log/dnsfilter' "$BASE/usr/local/sbin/blockmanager-webfilter-worker.php" "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq "'timestamp'" "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'BMWF_CURSOR_DIR' "$BASE/usr/local/www/blockmanager-webfilter/blockmanager-webfilter-lib.php"
grep -Fq 'network_cidr' "$BASE/usr/local/sbin/blockmanager-webfilter-worker.php"
grep -Fq 'session_or_identified_user' "$BASE/usr/local/sbin/blockmanager-webfilter-worker.php"
grep -Eq '"enabled"[[:space:]]*:[[:space:]]*false' "$BASE/usr/local/etc/blockmanager/webfilter/blockmanager-webfilter-settings.example.json"
grep -Fq ': ${blockmanager_webfilter_enable:="NO"}' "$BASE/usr/local/etc/rc.d/blockmanager_webfilter"
grep -Fq '"cron_installed": false' "$BASE/blockmanager-webfilter-release.json"
grep -Fq '"service_started": false' "$BASE/blockmanager-webfilter-release.json"
grep -Fq '"worker_started": false' "$BASE/blockmanager-webfilter-release.json"
grep -Fq '"traffic_redirected": false' "$BASE/blockmanager-webfilter-release.json"

echo 'OK: r6-p4-hf3.3-anchor-confirm para pfSense 2.9.0 validada estaticamente com guarda de coerência: migração segura, driver E2Guardian, bundle offline com trava de completude, frontend preservado e ativação desabilitada'
